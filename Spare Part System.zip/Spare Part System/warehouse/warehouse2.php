<?php
include '../db.php';
session_start();

// // CSRF Token Generate
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['csrf_token'];
$today = date('Y-m-d');

// Fetch notification count
$countResult = $conn->query("SELECT COUNT(*) as count FROM orders WHERE is_seen = 0 AND account_type IN ('admin', 'customer', 'member')");
$countRow = $countResult->fetch_assoc();
$notificationCount = $countRow['count'];

// Fetch all orders for main table (normal)
$orderQuery = "SELECT * FROM orders WHERE account_type IN ('admin', 'customer', 'member') ORDER BY created_at DESC";
$orderResult = $conn->query($orderQuery);

// Highlight specific order if set
$highlight_submit_id = isset($_GET['submit_id']) ? $_GET['submit_id'] : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <title>Unique Orders Summary</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            background-color: #EEF2FE; /* Light teal */
        }
        .logout-btn {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 55px;
          height: 55px;
          background: linear-gradient(135deg, #ff4e50, #f9d423);
          border-radius: 50%;
          color: white;
          font-size: 24px;
          box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
          transition: transform 0.3s ease, box-shadow 0.3s ease;
          text-decoration: none;
          position: fixed;
          top: 20px;
          left: 20px;
          z-index: 1000;
        }
        
        .logout-btn:hover {
          transform: scale(1.1);
          box-shadow: 0 6px 14px rgba(0, 0, 0, 0.3);
          color: #fff;
        }
        .cursor-pointer { 
            cursor: pointer; 
        }
        .collapse-table { 
            margin-top: 10px; 
        }
        #notification-btn {
            padding: 10px;
            font-size: 18px;
            position: relative;
        }

        #notification-count {
            font-size: 0.6rem;
            padding: 4px 6px;
            transform: translate(-50%, -50%);
        }
        .highlight {
            background-color: #ffff99 !important; /* Light yellow highlight */
            font-weight: bold;
        }
        .late-order { 
            background-color: #f8d7da !important; 
        }
        .red-square {
            width: 20px;
            height: 20px;
            background-color: red;
            display: inline-block;
            margin-bottom: 10px;
            cursor: pointer;
            border: 1px solid #000;
        }
        .filter-section {
            margin-bottom: 20px;
        }
        .print-btn {
            color: #fff;
            background-color: #17a2b8; 
            border-color: #17a2b8; 
            font-size: 14px;
            padding: 6px 12px;
            border-radius: 5px;
            transition: all 0.3s ease-in-out;
        }
        .print-btn:hover {
            background-color: #138496; 
            border-color: #117a8b; 
            cursor: pointer;
        }
        .print-btn:active {
            background-color: #117a8b; 
            border-color: #0e5f6b; 
        }
        .print-btn:focus {
            box-shadow: 0 0 0 0.2rem rgba(23, 162, 184, 0.5); 
        }
        /* Print Styles */
        @media print {
            body * {
                visibility: hidden;
            }
            .printable-content, .printable-content * {
                visibility: visible;
            }
            .printable-content {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
            }
        }
    </style>
</head>
<body>
<a href="warehouse_logout.php" class="logout-btn" title="Logout">  <i class="bi bi-box-arrow-right"></i></a>
<div class="container mt-4">
    <div class="d-flex justify-content-end mb-3">
        <button class="btn btn-secondary position-relative" onclick="window.location.href='notification.php';">
            <i class="fas fa-bell"></i>
            <?php if ($notificationCount > 0): ?>
                <span id="notification-count" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                    <?= $notificationCount ?>
                </span>
            <?php endif; ?>
        </button>
    </div>
<div class="container mt-4">
    <h2 class="mb-4 text-center">Orders Summary</h2>
    <a href='submitted_orders_report2.php'><button class='btn btn-dark fw-bold px-3 py-2 text-light' style='float: left; margin-bottom: 20px;'>
        <i class='fas fa-database'></i> Check Order Reports</button></a>
        <input type="text" id="searchInput" class="form-control w-50" placeholder="Search by Customer Name or Order Date (dd-mm-yyyy)..." />
    <div class="filter-section d-flex justify-content-end">
        <div class="red-square" id="show-late-orders" title="Show Late Orders Only"><br><b>Pending</b></div>
    </div>
    <table class="table table-bordered table-striped" id="ordersTable">
        <thead class="table-dark">
            <tr>
                <th>Sr.No</th>
                <th>Party Name</th>
                <th>Order Date</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $allowedTypes = ['admin', 'customer', 'member'];
        $placeholders = implode(',', array_fill(0, count($allowedTypes), '?'));
        
        $query = "SELECT DISTINCT customer_fullname, DATE(order_date) as order_date 
                  FROM orders 
                  WHERE account_type IN ($placeholders)
                  ORDER BY order_date DESC, customer_fullname ASC";
        
        $stmt = $conn->prepare($query);
        $stmt->bind_param(str_repeat('s', count($allowedTypes)), ...$allowedTypes);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();
        $sr = 1;

        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $customer = htmlspecialchars($row['customer_fullname']);
                $date = htmlspecialchars($row['order_date']);
                $collapseId = "collapse_" . md5($customer . $date); // Unique ID

                // Calculate days difference
                $date1 = new DateTime($date);
                $date2 = new DateTime($today);
                $interval = $date1->diff($date2);
                $daysDifference = $interval->days;

                $lateClass = ($daysDifference > 5) ? "late-order" : "";
 
                echo "<tr class='cursor-pointer $lateClass main-row' data-bs-toggle='collapse' data-bs-target='#$collapseId'>";
                echo "<td>{$sr}</td>";
                echo "<td>{$customer}</td>";
                echo "<td>" . date("d-m-Y", strtotime($date)) . "</td>";
                echo "</tr>";

                // Collapsible row
                echo "<tr class='collapse $lateClass detail-row' id='$collapseId'>";
                echo "<td colspan='3'>";
                echo "<div class='collapse-table'>";
                echo "<strong class='customer-title'>Orders for {$customer} on " . date("d-m-Y", strtotime($date)) . ":</strong>";

                // Fetch related orders
                $orderStmt = $conn->prepare("SELECT submit_id, product, company, quantity, partNo, remark, admin_remark 
                FROM orders 
                WHERE customer_fullname = ? AND DATE(order_date) = ? 
                AND account_type IN ('admin', 'customer', 'member')");
                $orderStmt->bind_param("ss", $customer, $date);
                $orderStmt->execute();
                $orderResult = $orderStmt->get_result();
                $orderStmt->close();

                if ($orderResult->num_rows > 0) {
                    echo "<div id='orderData'>
                    <div class='table-responsive'>
                    <table class='table table-sm table-bordered mt-2'>
                            <thead class='table-light'>
                                <tr>
                                    <th><input type='checkbox' id='selectAll'></th>
                                    <th>Sr. No</th>
                                    <th>Product</th>
                                    <th>Company</th>
                                    <th>Part No</th>
                                    <th>Quantity</th>
                                    <th>Remark</th>
                                    <th>Admin Remark</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>";
                            $innerSr = 1;
                        while ($order = $orderResult->fetch_assoc()) {
                        // Highlight this row if submit_id matches
                        $highlightClass = ($highlight_submit_id && $highlight_submit_id == $order['submit_id']) ? 'highlight' : '';
                        echo "<tr class='{$highlightClass}' data-order-id='{$order['submit_id']}'>
                                <td><input type='checkbox' class='order-checkbox' data-submit_id='{$order['submit_id']}'></td>
                                <td>{$innerSr}</td>
                                <td>" . htmlspecialchars($order['product']) . "</td>
                                <td>" . htmlspecialchars($order['company']) . "</td>
                                <td>" . htmlspecialchars($order['partNo']) . "</td>
                                <td><span class='editable'>" . htmlspecialchars($order['quantity']) . "</span>
                                    <input class='form-control edit-input' data-column='quantity' value='" . htmlspecialchars($order['quantity']) . "' style='display:none;'></td>
                                <td><span class='remark-text'>" . htmlspecialchars($order['remark']) . "</span>
                                    <input type='text' class='form-control editable-input' value='" . htmlspecialchars($order['remark']) . "'></td>
                                <td>" . htmlspecialchars($order['admin_remark']) . "</td>
                                <td><button type='button' class='btn btn-outline-success btn-sm rounded-pill px-3 edit-btn'>Edit</button></td>
                                <td><button type='button' class='btn btn-outline-warning btn-sm rounded-pill px-3 remark-btn'>Remark</button></td>
                              </tr>";
                              $innerSr++;
                    }  
                echo "</tbody></table></div></div>";

                echo "<button class='btn print-btn px-3 py-2 float-end' style='float: right; margin-bottom: 20px; margin-right: 20px; margin-top: 10px;' onclick='printTableData(this)'>
                    <i class='fas fa-print'></i> Print</button>";
                echo "<button class='btn btn-danger btn-sm px-3 py-2 deleteOrders' style='float: right; margin-bottom: 20px; margin-right: 20px;position:relative; margin-top: 10px;'>
                    <i class='fas fa-trash'></i> Delete Orders</button>";
                echo "<button class='btn btn-success submit-orders-btn px-3 py-2' id='submitAllOrders' style='float: right; margin-bottom: 20px; margin-right: 20px; margin-top: 10px;' data-csrf='$csrfToken'>
                    <i class='fa fa-check-circle'></i> Submit Orders</button>";
                
                } else {
                    echo "<p>No orders found for this customer on this date.</p>";
                }

                echo "</div></td></tr>";
                $sr++;
            }
        } else {
            echo "<tr class='cursor-pointer' style='cursor:pointer;' data-bs-toggle='collapse' data-bs-target='#$collapseId'>";
        }
        ?>
        </tbody>
    </table>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
$(document).ready(function() {
    
    // Remark button click - Show input
    $(document).on('click', '.remark-btn', function() {
        var row = $(this).closest('tr');
        row.find('.remark-text').hide();
        row.find('.editable-input').show().focus();
    });

    // Press ENTER inside editable input
    $(document).on('keypress', '.editable-input', function(e) {
        if (e.which == 13) { // Enter key
            var input = $(this);
            var newRemark = input.val().trim();
            var row = input.closest('tr');
            var submitId = row.data('order-id');

            if (newRemark !== "") {
                // AJAX call to update remark
                $.ajax({
                    url: 'update_remark.php',
                    type: 'POST',
                    data: {
                        submit_id: submitId,
                        remark: newRemark
                    },
                    success: function(response) {
                        if (response == "success") {
                            input.hide();
                            row.find('.remark-text').text(newRemark).show();
                        } else {
                            alert('Failed to update remark!');
                        }
                    },
                    error: function() {
                        alert('Error while updating.');
                    }
                });
            }
        }
    });

});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        // On Edit button click: show input box
        $(".edit-btn").click(function () {
            let row = $(this).closest("tr");
            row.find(".editable").hide();
            row.find(".edit-input").show().focus();
        });

        // On Enter key inside input field
        $(".edit-input").keypress(function (e) {
            if (e.which === 13) {
                let inputField = $(this);
                let newValue = inputField.val().trim();
                let columnName = inputField.data("column");
                let submitId = inputField.closest("tr").data("order-id");

                if (newValue === "") {
                    alert("Quantity cannot be empty.");
                    return;
                }

                $.ajax({
                    url: "order_update.php",
                    method: "POST",
                    data: {
                        id: submitId,
                        column: columnName,
                        value: newValue
                    },
                    success: function (response) {
                        if (response.trim() === "success") {
                            inputField.hide();
                            inputField.siblings(".editable").text(newValue).show();
                        } else {
                            alert("Update failed. Please try again.");
                        }
                    }
                });
            }
        });

        // Hide input on blur
        $(".edit-input").blur(function () {
            $(this).hide();
            $(this).siblings(".editable").show();
        });
    });
    
    // Select All inside sub-table
    $(document).on('change', '.selectAll', function () {
        const table = $(this).closest('table');
        table.find('.order-checkbox').prop('checked', this.checked);
    });

    // Individual uncheck check/uncheck selectAll
    $(document).on('change', '.order-checkbox', function () {
        const table = $(this).closest('table');
        const all = table.find('.order-checkbox').length;
        const checked = table.find('.order-checkbox:checked').length;
        table.find('.selectAll').prop('checked', all === checked);
    });

    // Submit only current sub-table orders
    $(document).on('click', '.submit-orders-btn', function () {
        const parentDiv = $(this).closest('.collapse-table');
        const checkedBoxes = parentDiv.find('.order-checkbox:checked');
        let selectedOrders = [];

        checkedBoxes.each(function () {
            selectedOrders.push($(this).data('submit_id'));
        });

        if (selectedOrders.length > 0) {
            $.ajax({
                url: 'submit_orders.php',
                type: 'POST',
                data: { 
                    orderIds: selectedOrders,
                    csrf_token: $(this).data('csrf') 
                },
                dataType: 'json',
                success: function(response) {
                    alert(response.message || (response.success ? "Orders submitted successfully" : "Submission failed"));
                    if (response.success) location.reload();
                },
                error: function(xhr, status, error) {
                    console.error("AJAX Error:", status, error);
                    alert("An error occurred while submitting orders.");
                }
            });
        } else {
            alert("Please select at least one order.");
        }
    });    

    //Late Order Display In Red Color
    // Late orders show/hide toggle
    $(document).ready(function() {
        let showLateOnly = false;
    
        $('#show-late-orders').click(function() {
            showLateOnly = !showLateOnly;
        
            if (showLateOnly) {
                $('.main-row').hide();
                $('.detail-row').hide();
                $('.late-order').show();
            } else {
                $('.main-row').show();
                $('.detail-row').show();
            }
        });
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Select All functionality
    $(document).on('change', '.selectAll', function () {
        const table = $(this).closest('table');
        table.find('.order-checkbox').prop('checked', this.checked);
    });

    $(document).on('change', '.order-checkbox', function () {
        const table = $(this).closest('table');
        const all = table.find('.order-checkbox').length;
        const checked = table.find('.order-checkbox:checked').length;
        table.find('.selectAll').prop('checked', all === checked);
    });

    // Print only related table
    function printTableData(button) {
        const orderContainer = button.closest(".collapse-table");
        const customerTitle = orderContainer.querySelector(".customer-title").innerText;
        const table = orderContainer.querySelector("table");

        const selectedCheckboxes = table.querySelectorAll(".order-checkbox:checked");
        const rowsToPrint = selectedCheckboxes.length > 0 ? 
                            Array.from(selectedCheckboxes).map(cb => cb.closest("tr")) :
                            Array.from(table.querySelectorAll("tbody tr"));

        let printContent = `
        <div style="text-align:center;">
            <img src="../image/RJ logo.png" height="80">
            <div class="contact">
                <h3>Yogesh Patil</h3>
                <p>📞 9834530051</p>
                <p><img src="../image/logo/whatsapp.png"> 9766950925</p>
            </div>
            <hr>
            <div class="company-details">
                <p><strong>Office:</strong> PUNE-SOLAPUR ROAD, NH-65, MOHOL-413 213, DIST. SOLAPUR.</p>
                <p><strong>Warehouse:</strong> GATE NO. 280, PLOT NO. 2, A/P. KONDI, TQ. NORTH SOLAPUR, DIST. SOLAPUR.</p>
                <p><strong>GSTIN:</strong> 27AAZFR2504H1ZV | <strong>Email:</strong> rjautoheaven@gmail.com</p>
            </div>
        </div>
        <h5 style="text-align:center;">${customerTitle}</h5>
        <table border="1" style="width:100%; border-collapse:collapse;">
            <thead>
                <tr><th>Sr.No</th><th>Product</th><th>Company</th><th>Part No</th><th>Quantity</th></tr>
            </thead><tbody>`;

        rowsToPrint.forEach((row, idx) => {
            const cells = row.querySelectorAll("td");
            printContent += `<tr>
                <td>${idx + 1}</td>
                <td>${cells[2].innerText}</td>
                <td>${cells[3].innerText}</td>
                <td>${cells[4].innerText}</td>
                <td>${cells[5].innerText}</td>
            </tr>`;
        });

        printContent += `</tbody></table>`;

                const win = window.open('', '', 'width=900,height=600');
        win.document.write(`<html><head><title>Print Orders</title>
                <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css">
                <style>
                            table { border-collapse: collapse; width: 100%; }
                            th, td { border: 1px solid black; padding: 8px; text-align: left; }
                            .table td:nth-child(2) { min-width: 150px; max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
                            .table td:nth-child(3), .table td:nth-child(4) { min-width: 70px; max-width: 100px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
                            .order-form { width: 90%; margin: 20px auto; padding: 10px; border: 2px solid #000; border-radius: 8px; font-family: Arial, sans-serif; }
                            .header { display: flex; justify-content: space-between; align-items: center; }
                            .logo { width: 20%; margin-top: -10px; }
                            p img { width: 3%; height: auto; }
                            .contact { text-align: right; font-size: 14px; margin-top: -10px; line-height: 0.5; font-weight: bold; }
                            .contact h3 { text-align: right; font-size: 14px; font-weight: bold; }
                            .contact p { line-height: 0.5; }
                            .company-details { text-align: center; font-size: 14px; margin-top: -55px; }
                            .order-details { font-size: 16px; line-height: 0.5; }
                            .order-details h3 { display: inline-block; margin-right: 20px; line-height: 0.5; }
                            .order-header, .order-footer { display: flex; justify-content: space-between; align-items: center; }
                            .order-row { display: flex; justify-content: space-between; margin: 5px 0; width: 100%; }
                            .order-row p { width: 50%; line-height: 0.5; }
                </style>
                </head>
            <body>${printContent}</body></html>`);
        win.document.close();
        win.print();
    }

    // Ctrl + P for printing open collapse
    document.addEventListener("keydown", function (e) {
        if ((e.ctrlKey || e.metaKey) && e.key === "p") {
            e.preventDefault();
            const openCollapse = document.querySelector(".collapse.show");
            if (openCollapse) {
                const printBtn = openCollapse.querySelector(".print-btn");
                if (printBtn) {
                    printTableData(printBtn);
                }
            }
        }
    });

    //Delete Selected Orders
    $(document).ready(function () {
    // Select All inside specific table
    $(document).on('change', '#selectAll', function () {
        const table = $(this).closest('table');
        const isChecked = $(this).is(':checked');
        table.find('.order-checkbox').prop('checked', isChecked);
    });

    $(document).on('change', '.order-checkbox', function () {
        const table = $(this).closest('table');
        const allCheckboxes = table.find('.order-checkbox');
        const checkedCheckboxes = allCheckboxes.filter(':checked');
        const selectAll = table.find('#selectAll');

        if (checkedCheckboxes.length === allCheckboxes.length) {
            selectAll.prop('checked', true);
        } else {
            selectAll.prop('checked', false);
        }
    });

    // DELETE Orders inside specific table
    $(document).on('click', '.deleteOrders', function() {
        let selectedOrders = [];

        // find closest collapse div
        const collapseDiv = $(this).closest('.collapse-table');

        // find selected checkboxes only inside that collapse div
        collapseDiv.find('.order-checkbox:checked').each(function() {
            selectedOrders.push($(this).data("submit_id"));
        });

        if (selectedOrders.length > 0) {
            if (confirm("Are you sure you want to delete the selected orders?")) {
                $.ajax({
                    url: 'delete_orders.php',
                    type: 'POST',
                    data: { orderIds: selectedOrders },
                    success: function(response) {
                        alert(response);
                        location.reload();
                    },
                    error: function() {
                        alert("Error occurred while deleting orders.");
                    }
                });
            }
        } else {
            alert("Please select at least one order to delete.");
        }
    });

    });

    //Notification Count JS
    document.getElementById("notification-btn").addEventListener("click", function() {
    window.location.href = "../admin folders/notification.php";
    });

    function updateNotificationCount() {
        $.ajax({
            url: '../admin folders/notification_count.php',
            method: 'GET',
            success: function(count) {
                if (count > 0) {
                    $("#notification-count").text(count).show();
                } else {
                    $("#notification-count").hide();
                }
            }
        });
    }
    setInterval(updateNotificationCount, 2000);
    updateNotificationCount();

    //Highlight Notified Orders
    document.addEventListener('DOMContentLoaded', function() {
        const urlParams = new URLSearchParams(window.location.search);
        const submitId = urlParams.get('submit_id');

        if (submitId) {
            const row = document.querySelector(`[data-order-id='${submitId}']`);
            if (row) {
                // Find the parent collapsible row
                let collapseRow = row.closest('.collapse-table');
                if (!collapseRow) {
                    // If not found directly, search higher
                    collapseRow = row.closest('tr.collapse');
                }

                if (collapseRow) {
                    const collapseId = collapseRow.id;
                    const targetCollapse = document.getElementById(collapseId);

                    if (targetCollapse && !targetCollapse.classList.contains('show')) {
                        // If not open, open the collapse
                        const triggerRow = document.querySelector(`[data-bs-target="#${collapseId}"]`);
                        if (triggerRow) {
                            triggerRow.classList.add('show');
                            new bootstrap.Collapse(targetCollapse, {
                                toggle: true
                            });
                        }
                    }

                    // Scroll into view nicely
                    setTimeout(() => {
                        row.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        row.classList.add('highlight');
                    }, 50000); // Wait a bit for collapse animation
                }
            }
        }
    });
</script>
<script>
document.getElementById("searchInput").addEventListener("keyup", function () {
    var searchValue = this.value.toLowerCase().trim();
    var anyMatchFound = false;

    document.querySelectorAll("tr.main-row").forEach(function (mainRow) {
        var collapseId = mainRow.getAttribute("data-bs-target").substring(1); // remove #
        var detailRow = document.getElementById(collapseId);
        
        var customer = mainRow.children[1].innerText.toLowerCase();
        var orderDate = mainRow.children[2].innerText.toLowerCase();

        if (searchValue === "" || customer.includes(searchValue) || orderDate.includes(searchValue)) {
            mainRow.style.display = "";
            detailRow.style.display = "";
            detailRow.classList.add("show"); // Expand
            anyMatchFound = true;
        } else {
            mainRow.style.display = "none";
            detailRow.style.display = "none";
            detailRow.classList.remove("show"); // Collapse
        }
    });

    // Optional: Show message if nothing is found
    if (!anyMatchFound && searchValue !== "") {
        console.log("No match found");
    }
});
</script>
<script>
    // Check if login was successful
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('login') === 'success') {
        // Speak login success in a woman's voice
        const utterance = new SpeechSynthesisUtterance("Login successful");
        utterance.lang = 'en-US';

        // Set voice to female if available
        const voices = window.speechSynthesis.getVoices();
        const femaleVoice = voices.find(voice => voice.name.includes('Female') || voice.name.includes('Samantha') || voice.gender === 'female');
        if (femaleVoice) {
            utterance.voice = femaleVoice;
        }

        window.speechSynthesis.speak(utterance);

        // Remove the URL parameter to prevent repeated play
        if (window.history.replaceState) {
            const cleanUrl = window.location.origin + window.location.pathname;
            window.history.replaceState({}, document.title, cleanUrl);
        }
    }
</script>
</body>
</html>
