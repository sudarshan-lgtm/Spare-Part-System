<?php
session_start();
include '../db.php';

// Check if submit_id is given
if (isset($_GET['submit_id'])) {
    $submit_id = $_GET['submit_id'];

    // Mark that order as seen
    $stmt = $conn->prepare("UPDATE orders SET is_seen = 1 WHERE submit_id = ?");
    $stmt->bind_param("s", $submit_id);
    $stmt->execute();
    $stmt->close();

    // Redirect back to warehouse2.php and highlight the row
    header("Location: warehouse2.php?highlight_submit_id=" . urlencode($submit_id));
    exit();
} else {
    // If submit_id not found
    header("Location: notification.php");
    exit();
}
?>
