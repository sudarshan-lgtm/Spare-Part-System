<?php
session_start();
include '../db.php';

// Fetch only unseen (new) orders
$query = "SELECT id, submit_id, product, totalSaleRate, quantity, created_at 
          FROM orders 
          WHERE is_seen = 0 
          AND account_type IN ('admin', 'customer', 'member') 
          ORDER BY created_at DESC";
$result = $conn->query($query);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <title>Notifications</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    body {
        background-color: #EEF2FE; /* Light teal */
    }
    </style>
</head>
<body>
<div class="container mt-5">
    <h3>New Order Notifications</h3>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Product</th>
                <th>Sale Rate</th>
                <th>Quantity</th>
                <th>Created At</th>
                <th>View Order</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['product']) ?></td>
                        <td>₹<?= number_format($row['totalSaleRate'], 2) ?></td>
                        <td><?= htmlspecialchars($row['quantity']) ?></td>
                        <td><?= date('d M Y, h:i A', strtotime($row['created_at'])) ?></td>
                        <td>
                            <a href="view_order.php?submit_id=<?= urlencode($row['submit_id']) ?>" class="btn btn-info btn-sm">View Order</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="5" class="text-center">No new notifications</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>
