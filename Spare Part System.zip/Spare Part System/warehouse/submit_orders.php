<?php
// Disable error display in production; log errors instead
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Start session for CSRF token and other session data
session_start();

// Include database connection
include '../db.php';

// Enable strict MySQL error reporting for better exception handling
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// Set timezone to IST (adjust as needed)
date_default_timezone_set("Asia/Kolkata");

// Handle POST request for order submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        echo json_encode(["success" => false, "error" => "Invalid CSRF token"]);
        exit;
    }

    // Check if orderIds is provided and valid
    if (isset($_POST['orderIds']) && is_array($_POST['orderIds']) && !empty($_POST['orderIds'])) {
        // Filter orderIds to ensure they are non-empty strings
        $orderIds = array_filter($_POST['orderIds'], fn($id) => is_string($id) && !empty($id));


        if (empty($orderIds)) {
            echo json_encode(["success" => false, "error" => "Invalid order IDs provided"]);
            exit;
        }

        $idsString = implode(",", array_map(fn($id) => "'" . $conn->real_escape_string($id) . "'", $orderIds));
        $currentDateTime = date("Y-m-d H:i:s");
        $conn->begin_transaction();

        try {
            // Insert selected orders into submitted_orders table
            $insertQuery = "INSERT INTO submitted_orders (
                submit_id, customer_id, customer_fullname, account_type, product, batch, company, partNo, 
                purchaseRate, gst, exp, margin, totalSaleRate, enterSaleRate, updatedSaleRate, 
                closingQty, location, quantity, feedback, order_date, submit_order_date) 
                SELECT submit_id, customer_id, customer_fullname, account_type, product, batch, company, partNo, 
                purchaseRate, gst, exp, margin, totalSaleRate, enterSaleRate, updatedSaleRate, 
                closingQty, location, quantity, feedback, created_at, '$currentDateTime'
            FROM orders WHERE submit_id IN ($idsString) AND account_type IN ('admin', 'customer', 'member')";

            if (!$conn->query($insertQuery)) {
                throw new Exception("Insert into submitted_orders failed: " . $conn->error);
            }

            // Delete from orders table
            $deleteQuery = "DELETE FROM orders WHERE submit_id IN ($idsString)";
            if (!$conn->query($deleteQuery)) {
                throw new Exception("Delete from orders failed: " . $conn->error);
            }

            // Delete from customer_orders table
            $deleteQuery = "DELETE FROM customer_orders WHERE submit_id IN ($idsString)";
            if (!$conn->query($deleteQuery)) {
                throw new Exception("Delete from customer_orders failed: " . $conn->error);
            }

            // Delete from member_orders table
            $deleteQuery = "DELETE FROM member_orders WHERE submit_id IN ($idsString)";
            if (!$conn->query($deleteQuery)) {
                throw new Exception("Delete from member_orders failed: " . $conn->error);
            }

            // If all queries succeed, commit the transaction
            $conn->commit();

            // Return success response
            echo json_encode(["success" => true, "message" => "Orders submitted successfully"]);
        } catch (Exception $e) {
            // Roll back transaction on failure
            $conn->rollback();

            // Log the error to a file for debugging
            file_put_contents('error_log.txt', date('Y-m-d H:i:s') . " - " . $e->getMessage() . "\n", FILE_APPEND);

            // Return failure response with error details
            echo json_encode(["success" => false, "error" => $e->getMessage()]);
        }
 } else {
        // Invalid or missing order selection
        echo json_encode(["success" => false, "error" => "Invalid order selection"]);
    }
    exit; // Ensure no further output
}

// Function to generate dropdown options (used elsewhere, e.g., in warehouse.php)
function getDropdownOptions($conn, $accountType) {
    $query = "SELECT DISTINCT fullname FROM submitted_orders WHERE account_type IN ('admin', 'customer', 'member') AND account_type = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $accountType);
    $stmt->execute();
    $result = $stmt->get_result();
    $options = "<option value=''>Select " . ucfirst(str_replace('_', ' ', $accountType)) . "</option>";
    while ($row = $result->fetch_assoc()) {
        $options .= "<option value='" . htmlspecialchars($row['fullname']) . "'>" . htmlspecialchars($row['fullname']) . "</option>";
    }
    $stmt->close();
    return $options;
}
?>