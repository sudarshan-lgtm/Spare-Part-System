<?php
session_start();
include '../db.php'; // Ensure your database connection file is included

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['verify_number'])) {
        $mobile = $_POST['mobile'];
        $_SESSION['mobile'] = $mobile; // Store mobile number in session
        
        // Check if mobile number exists
        $query = "SELECT * FROM warehouse WHERE mobile = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $mobile);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            echo json_encode(["status" => "exists"]);
        } else {
            echo json_encode(["status" => "not_exists"]);
        }
        $stmt->close();
        exit;
    }

    if (isset($_POST['update_password'])) {
        $mobile = $_SESSION['mobile'];
        $new_password = $_POST['new_password'];
        $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);

        // Update password in database
        $updateQuery = "UPDATE warehouse SET password = ? WHERE mobile = ?";
        $stmt = $conn->prepare($updateQuery);
        $stmt->bind_param("ss", $hashed_password, $mobile);
        
        if ($stmt->execute()) {
            echo json_encode(["status" => "success"]);
        } else {
            echo json_encode(["status" => "error"]);
        }
        $stmt->close();
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forget Password</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #EEF2FE;
            padding: 20px;
        }

        .container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            width: 90%;
            max-width: 400px;
        }

        input {
            width: 100%;
            padding: 12px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 6px;
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #2c5364;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }

        button:hover {
            background-color: #1a2e3b;
        }

        #password-container {
            display: none; /* Initially hidden */
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            .container {
                width: 90%;
                padding: 25px;
            }
            input, button {
                font-size: 14px;
                padding: 10px;
            }
            input {
                font-size: 14px;
                padding: 10px;
                width: 90%;
            }
        }

        @media (max-width: 480px) {
            .container {
                width: 95%;
                padding: 20px;
            }
            button {
                font-size: 12px;
                padding: 8px;
            }
            input {
                font-size: 12px;
                padding: 8px;
                width: 90%;
            }
        }

        @media (min-width: 1024px) {
            .container {
                width: 50%;
                max-width: 450px;
            }
        }

        @media screen and (orientation: landscape) and (max-width: 768px) {
            .container {
                width: 70%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Verify mobile Number</h2>
        <form id="verify-form">
            <label>Enter Registered mobile Number:</label>
            <input type="text" id="mobile" name="mobile" placeholder="Enter 10-digit mobile number" required oninput="validateNumbers(this)">
            <button type="submit" id="verify-btn">Verify Number</button>
        </form>

        <div id="password-container">
            <h2>Reset Password</h2>
            <form id="reset-form">
                <label>Enter New Password:</label>
                <input type="password" id="new_password" name="new_password" required placeholder="Enter new password">
                <button type="submit" id="update-btn">Update Password</button>
            </form>
        </div>
    </div>

    <script>
        $(document).ready(function(){
            // Verify mobile number
            $("#verify-form").submit(function(e){
                e.preventDefault();
                var mobile = $("#mobile").val();

                $.ajax({
                    type: "POST",
                    url: "warehouse_forget_password.php",
                    data: { verify_number: true, mobile: mobile },
                    dataType: "json",
                    success: function(response) {
                        if (response.status === "exists") {
                            $("#password-container").show(); // Show password input
                            $("#verify-btn").hide(); // Hide Verify button
                        } else {
                            alert("Oops! This phone number isn't registered. Please check and try again!");
                        }
                    }
                });
            });

            // Update password
            $("#reset-form").submit(function(e){
                e.preventDefault();
                var new_password = $("#new_password").val();

                $.ajax({
                    type: "POST",
                    url: "warehouse_forget_password.php",
                    data: { update_password: true, new_password: new_password },
                    dataType: "json",
                    success: function(response) {
                        if (response.status === "success") {
                            alert("Password updated successfully!");
                            window.location.href = "warehouse_login.php"; // Redirect to login page
                        } else {
                            alert("Error updating password.");
                        }
                    }
                });
            });
        });
    </script>
    <script>
        function validateNumbers(input)  {
            input.value = input.value.replace(/[^0-9]/g, '').substring(0,10);
        }
    </script>
</body>
</html>