<?php
session_start();
include '../db.php';

if (!isset($_SESSION["id"])) {
    exit("Session expired. Please login again.");
}

if (isset($_POST['submit_ids']) && is_array($_POST['submit_ids'])) {
    $ids = $_POST['submit_ids'];

    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $conn->prepare("DELETE FROM submitted_orders WHERE submit_id IN ($placeholders)");

    if ($stmt) {
        $stmt->bind_param(str_repeat('s', count($ids)), ...$ids);
        if ($stmt->execute()) {
            echo "Selected orders deleted successfully.";
        } else {
            echo "Error deleting orders.";
        }
        $stmt->close();
    } else {
        echo "Failed to prepare statement.";
    }
} else {
    echo "Invalid request.";
}
?>
