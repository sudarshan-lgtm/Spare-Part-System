<?php
include '../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT); // Encrypt password
    $fullname = $_POST["fullname"];
    $email = $_POST["email"];
    $mobile = $_POST["mobile"];
    $address = $_POST["address"];
    $city = $_POST["city"];
    $area = $_POST["area"];
    $gstin = $_POST["gstin"];
    $dob = $_POST["dob"];
    $account_type = $_POST["account_type"];

    
    // Check if username already exists
    $checkSql = "SELECT username, email, mobile FROM warehouse WHERE username = ? OR email = ? OR mobile = ?";
    $checkStmt = $conn->prepare($checkSql);
    $checkStmt->bind_param("sss", $username, $email, $mobile);
    $checkStmt->execute();
    $checkStmt->store_result();
    $checkStmt->close();
 
    if ($checkStmt->num_rows > 0) {
        // Fetch existing values
        $checkStmt->bind_result($existing_username, $existing_email, $existing_mobile);
        $checkStmt->fetch();
        
        $message = "";

        if ($existing_username == $username) {
            $message .= "Oops! This username is already taken. Try a unique one!\\n";
        }
        if ($existing_email == $email) {
            $message .= "This email is already linked to an account. Try another one!\\n";
        }
        if ($existing_mobile == $mobile) {
            $message .= "This mobile number is already registered. Use a different one!\\n";
        }

        echo "<script>
                alert('$message');
                window.history.back();
              </script>";
    } else {

    $sql = "INSERT INTO requests (username, password, fullname, email, mobile, address, city, area, gstin, dob, account_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssssss" , $username, $password, $fullname, $email, $mobile, $address, $city, $area, $gstin, $dob, $account_type);

    if ($stmt->execute()) {
        echo "<script>
                    alert('Request submitted successfully. Awaiting admin approval.');
                    window.location.href = 'warehouse_login.php'; // Redirect to a success page
                  </script>";
    } else {
        echo "<script>
                    alert('Error: " . $stmt->error . "');
                  </script>";
    }
    $stmt->close();
}
    $checkStmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Warehouse Register</title>
    <style>
        /* General Styles */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #EEF2FE;
        }
        form {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin-top: 15%;
            margin-bottom: 15%;
        }
        .register-form {
            background: #fff;
            padding: 20px 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }
        .register-form h2 {
            text-align: center;
            margin-bottom: 20px;
            margin-top: 10px;
            color: #333;
        }
        .input-field {
            margin-bottom: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        }
        .input-field input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }
        .input-field select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            transition: all 0.3s ease;
        }
        .input-field select:focus {
            border-color: #007bff;
            outline: none;
            box-shadow: 0px 0px 5px rgba(0, 123, 255, 0.5);
        }
        /* Password Requirements */
        #password-requirements {
            text-align: left;
            margin-left: 10px;
            padding: 5px;
            border: 1px solid #ccc;
            background-color: transparent;
            margin-top: -5px;
            margin-bottom: 5px;
        }

        #password-requirements label {
            display: block;
            color: red;
            font-size: 14px;
        }

        #password-requirements label.valid {
            color: green;
        }
        .error {
            color: red;
            text-align: left;
            margin-left: 12px;
            font-size: 14px;
        }
        .button:disabled {
            background: gray;
            cursor: not-allowed;
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: #2c5364;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #1a2e3b;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        }
        p {
            text-align: center;
            margin-top: 15px;
        }
        p a {
            color: #007bff;
            text-decoration: none;
        }
        p a:hover {
            text-decoration: underline;
        }
        /* Media Queries for Responsiveness */
        /* For large devices (desktops, laptops) */
        @media (min-width: 1024px) {
            .register-form {
                width: 40%;
                padding: 30px 50px;
            }
        }
        /* For tablets and medium screens */
        @media (min-width: 768px) and (max-width: 1023px) {
            .register-form {
                width: 60%;
            }
            .input-field input {
                font-size: 14px;
            }
            button {
                font-size: 14px;
            }
        }
        /* For small devices (smartphones) */
        @media (max-width: 767px) {
            .register-form {
                width: 90%;
                padding: 20px;
            }
            .input-field input {
                font-size: 14px;
            }
            button {
                font-size: 14px;
            }
        }
        @media (max-width: 480px) {
            form {
                margin-top: 40%;
            }
        }
    </style>
</head>
<body>
    <form action="warehouse_register.php" method="POST">
        <div class="register-form">
            <h2>Registration Form</h2>
            <div class="input-field">
            <label>Username :</label>
                <input type="text" name="username" placeholder="Your Username" required oninput="validateUsername(this)" maxlength="20"  title="Username should be 5-20 characters long and may include letters, numbers, and underscores only.">
            </div>
            <div class="input-field">
            <label>Password :</label>
            <input type="text" name="password" id="password" placeholder="Your Password" required pattern="[A-Za-z0-9@#$%^&*()_+!]+" minlength="8" maxlength="20" title="Password can include letters, numbers, and special characters (@#$%^&*()_+=!).">
            <span id="passwordError" class="error" style="display: none; margin-top: 5px;">This field is required</span>
            </div>
            <!-- Password Validation Messages -->
                <div id="password-requirements">
                    <label><input type="checkbox" id="length-check" disabled> Minimum 8 characters</label>
                    <label><input type="checkbox" id="uppercase-check" disabled> At least one uppercase letter</label>
                    <label><input type="checkbox" id="number-check" disabled> At least one number</label>
                    <label><input type="checkbox" id="special-check" disabled> At least one special character (~!@#$%^&*()_+)</label>
                </div>
            <div class="input-field">
            <label>Full Name :</label>
                <input type="text" name="fullname" placeholder="Your Full Name" required oninput="validateLetters(this)" maxlength="40">
            </div>
            <div class="input-field">
            <label>Email :</label>
            <input type="email" name="email" id="email" placeholder="Your Email" required>
            <span id="emailError" class="error" style="color:red; text-align: left; margin-left:12px; margin-top: 5px;">Enter a valid email address</span>
            </div>
            <div class="input-field">
            <label>Mobile Number :</label>
            <input type="text" name="mobile" placeholder="Your Mobile Number" required oninput="validateNumbers(this)" maxlength="10">
            </div>
            <div class="input-field">
            <label>Address :</label>
            <input type="text" name="address" placeholder="Your Address" required>
            </div>
            <div class="input-field">
            <label>City :</label>
            <input type="text" name="city" placeholder="Your City" required>
            </div>
            <div class="input-field">
            <label>Area :</label>
            <input type="text" name="area" placeholder="Your Area" required>
            </div>
            <div class="input-field">
            <label>GSTIN :</label>
            <input type="text" name="gstin" id="gstin" placeholder="Your GSTIN Number" maxlength="15" oninput="this.value = this.value.toUpperCase()" onblur="validateGSTIN(this)" required>
            </div>
            <div class="input-field">
            <label>Date Of Birth :</label>
            <input type="date" name="dob" id="dob" placeholder="date of birth" required maxlength="10">
            </div>
            <div class="input-field">
            <label>Account Type :</label>
                <select name="account_type" required>
                    <option value="">Select Account Type</option>
                    <option value="Warehouse">Warehouse</option>
                </select>
            </div>
            <p><a href="warehouse_login.php">Already Register</a></p>
            <a href="warehouse_login.php"><button type="submit">Register</button></a>
        </div>
    </form>
    <script>
        function validateLetters(input) {
            input.value = input.value.replace(/[^a-zA-Z\s]/g, '');
        }
        function validateNumbers(input)  {
            input.value = input.value.replace(/[^0-9]/g, '').substring(0,10);
        }
        function validateUsername(input) {
            input.value = input.value.replace(/[^a-zA-Z0-9_]/g, '');
        }
        function validateGSTIN(input) {
            input.value = input.value.toUpperCase(); // Convert to uppercase

            const gstin = input.value;
            const gstinRegex = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;

            if (!gstinRegex.test(gstin)) {
                alert("Invalid GSTIN Number Format");
                input.value = '';
            }
        }
//Email Validation
        document.addEventListener("DOMContentLoaded", function () {
            let container = document.getElementById("container");

            let form = document.querySelector("form");
            let emailInput = document.getElementById("email");
            let emailError = document.getElementById("emailError");

            emailError.style.display = "none"; // Hide error message initially

            emailInput.addEventListener("input", function () {
                validateEmail();
            });

            form.addEventListener("submit", function (event) {
                if (!validateEmail()) {
                    event.preventDefault(); // Stop form submission if email is invalid
                }
            });

            function validateEmail() {
                let emailPattern = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;

                if (!emailPattern.test(emailInput.value)) {
                    emailError.style.display = "block";
                    return false;
                } else {
                    emailError.style.display = "none";
                    return true;
                }
            }
        });
//Password Validation
        document.addEventListener("DOMContentLoaded", function () {
            let passwordInput = document.getElementById("password");
            let submitButton = document.getElementById("submitButton");
            let passwordError = document.getElementById("passwordError");

            // Checkboxes for password validation
            let lengthCheck = document.getElementById("length-check");
            let uppercaseCheck = document.getElementById("uppercase-check");
            let numberCheck = document.getElementById("number-check");
            let specialCheck = document.getElementById("special-check");

            function validatePassword() {
                let password = passwordInput.value;
                let isValid = true;

                // Check Length (Minimum 8 characters)
                if (password.length >= 8) {
                    lengthCheck.checked = true;
                    lengthCheck.parentElement.classList.add("valid");
                } else {
                    lengthCheck.checked = false;
                    lengthCheck.parentElement.classList.remove("valid");
                    isValid = false;
                }

                // Check Uppercase Letter
                if (/[A-Z]/.test(password)) {
                    uppercaseCheck.checked = true;
                    uppercaseCheck.parentElement.classList.add("valid");
                } else {
                    uppercaseCheck.checked = false;
                    uppercaseCheck.parentElement.classList.remove("valid");
                    isValid = false;
                }

                // Check Number
                if (/[0-9]/.test(password)) {
                    numberCheck.checked = true;
                    numberCheck.parentElement.classList.add("valid");
                } else {
                    numberCheck.checked = false;
                    numberCheck.parentElement.classList.remove("valid");
                    isValid = false;
                }

                // Check Special Character
                if (/[~!@#$%^&*()_+]/.test(password)) {
                    specialCheck.checked = true;
                    specialCheck.parentElement.classList.add("valid");
                } else {
                    specialCheck.checked = false;
                    specialCheck.parentElement.classList.remove("valid");
                    isValid = false;
                }

                // If any condition is false, show error, else hide it
                if (!isValid) {
                    passwordError.style.display = "block";
                    passwordInput.style.border = "1px solid red";
                    submitButton.disabled = true;
                } else {
                    passwordError.style.display = "none";
                    passwordInput.style.border = "1px solid green";
                    submitButton.disabled = false;
                }
            }

            passwordInput.addEventListener("input", validatePassword);

            // Prevent form submission if password is invalid
            document.getElementById("registrationForm").addEventListener("submit", function (event) {
                if (submitButton.disabled) {
                    event.preventDefault();
                    passwordError.style.display = "block";
                    passwordInput.style.border = "1px solid red";
                }
            });
        });
    </script>
</body>
</html>