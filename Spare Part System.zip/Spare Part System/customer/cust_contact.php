<?php
session_start();
require_once ("../db.php");

if (!isset($_SESSION['id'])) {
    header("Location: customer_login.php"); 
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = $_POST["fullname"];
    $email = $_POST["email"];
    $subject = $_POST["subject"];
    $message = $_POST["message"];
    $account_type = $_POST["account_type"]; // Get account type from form
    
    // Insert user data into the database
    $sql = "INSERT INTO contact (fullname, email, subject, message, account_type) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $fullname, $email, $subject, $message, $account_type);
    
    if($stmt->execute()) {
        echo "<script>
                alert('Data submitted successfully!');
                window.location.href = 'cust_contact.php';
            </script>";
            $stmt->close();
            $conn->close();
        exit();
    }else {
        echo 
        "<script>alert('Data submission failed! Please try again.');</script>";
        $stmt->close();
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../customer/css/contact.css">
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playwrite+AU+SA:wght@100..400&display=swap" rel="stylesheet">
    <title>Contact Us</title>
</head>
<body> 
<?php include("preloader.html"); ?>
    <nav class="navbar">
    <a href='customer_dashboard.php' class='back-button'><img src="../image/h1.png" class="home" alt="ok"></a>
        <img src="../image/RJ bg.png" class="logo" alt="RJ">
    </nav>
    <h1 >RJ AUTO HEAVEN</h1>
    <h3>Gat No. 288/2, Plot No.2, A/P-kondi, TQ, <br> North Solapur, Dist: Solapur</h3>
    <p style="margin-top:50px;">Customer Care <strong>:<a href="tel: 9834530051" style="color: red; text-decoration: none;"> 9834530051</a></strong></p>
    <p>E-mail <strong>:<a href="mailto: rjautoheaven@gmail.com" style="color: red; text-decoration: none;"> rjautoheaven@gmail.com</a></strong></p>
    <p style="margin-bottom: 10px;">Website <strong>:<a href="https://rjautoheaven.com/" style="color: red; text-decoration: none;"> rjautoheaven.com</a> </strong></p>
    <div class="contact-container">
        <h2 class="contact-title">Contact For Any Query</h2>
        <div class="contact-content">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3798.6478102433166!2d75.63898125368104!3d17.80824179157626!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc435ba5d852121%3A0xca1a95cdf38e213f!2sDALAVE%20PATIL%20SPARES%20%26%20ACCESSORIES!5e0!3m2!1sen!2sin!4v1741495407806!5m2!1sen!2sin" 
             style="border:0;" 
                allowfullscreen="" 
                loading="lazy" 
                referrerpolicy="no-referrer-when-downgrade">
            </iframe>
            <form action="" method="POST" class="contact-form">
                <input type="text" name="fullname" placeholder="Enter Your Full Name" required oninput="validateLetters(this)" maxlength="40">
                <input type="email" name="email" placeholder="Enter Your Email" required>
                <input type="text" name="mobile" placeholder="Enter Your Mobile Number" required oninput="validateNumbers(this)" maxlength="10">
                <input type="text" name="subject" placeholder="Subject" required>
                <textarea name="message" placeholder="Message" rows="7" required></textarea>
                <input type="hidden" name="account_type" value="customer">  
                <button type="submit">Send Message</button> 
            </form>
        </div>
    </div>
    <script>
        // Function to allow only letters
        function validateLetters(input) {
        input.value = input.value.replace(/[^a-zA-Z\s]/g, '');
        }


        // Function to allow only numbers
        function validateNumbers(input) {
        input.value = input.value.replace(/[^0-9]/g, '').substring(0, 10);
    }
    </script>
</body>
</html>