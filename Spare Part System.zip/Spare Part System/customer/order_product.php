<?php
    session_start(); 
    include '../db.php';

    if (!isset($_SESSION['id'])) {
        header("Location: customer_login.php"); 
        exit();
    }

    date_default_timezone_set("Asia/Kolkata"); // Important
    $currentDateTime = date("Y-m-d H:i:s"); // Format Y-m-d H:i:s

    $fullname = "";
    $customer_id = "";
    $account_type = "";
    if (isset($_SESSION['id'])) {
        $customer_id = $_SESSION['id']; // Get the logged-in customer ID
        $query = "SELECT fullname, 'Customer' as account_type FROM customer WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $customer_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $fullname = htmlspecialchars($row['fullname']);
            $account_type = htmlspecialchars($row['account_type']); // Get account type
        }
        $stmt->close();
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product'])) {
        $selectedProducts = $_POST['product'];
        
            foreach ($selectedProducts as $productid) {
                $query = "SELECT * FROM customer_cart WHERE id = ? AND customer_id = ?";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("ii", $productid, $customer_id);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    $product = $result->fetch_assoc();
                    $totalSaleRate = $product['totalSaleRate']; 
                    $feedback = isset($_POST['feedback'][$productid]) ? trim($_POST['feedback'][$productid]) : '';

                    $submit_id = "RJS_" . uniqid();

                    // 🔹 Debugging: Check if order_id is generated correctly
                    if (empty($submit_id)) {
                        die("Error: Order ID is empty. Debugging required.");
                    }
                    
                    $orderQuery = "INSERT INTO customer_orders (submit_id, customer_id, customer_fullname, product, batch, company, partNo, purchaseRate, gst, exp, margin, totalSaleRate, enterSaleRate, updatedSaleRate, closingQty, location, quantity, feedback, order_date)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    $orderStmt = $conn->prepare($orderQuery);
                    
                    $customer_id = $_SESSION['id'];  // Ensure you have the correct customer_id
                    $fullname = $fullname;
                    $productName = $product['product'];
                    $batch = $product['batch'];
                    $company = $product['company'];
                    $partNo = $product['partNo'];
                    $purchaseRate = $product['purchaseRate'];
                    $gst = $product['gst'];
                    $exp = $product['exp'];
                    $margin = $product['margin'];
                    $totalSaleRate = $product['totalSaleRate'];
                    $enterSaleRate = $product['enterSaleRate'] ?? ""; 
                    $updatedSaleRate = $product['updatedSaleRate'] ?? "";
                    $closingQty = $product['closingQty'];
                    $location = $product['location'];
                    $quantity = $product['quantity'];
                    $feedback = $product['feedback'];
                    
                    $orderStmt->bind_param("sisssssdidddssisiss", $submit_id, $customer_id, $fullname, $productName, $batch, $company, $partNo, $purchaseRate, $gst, $exp, $margin, $totalSaleRate, $enterSaleRate, $updatedSaleRate, $closingQty, $location, $quantity, $feedback, $currentDateTime);
                    $orderStmt->execute();
                    $orderStmt->close();

                    // Insert into admin_orders table so the admin can see the order
                    $adminOrderQuery = "INSERT INTO orders (submit_id, customer_id, customer_fullname, account_type, product, batch, company, partNo, purchaseRate, gst, exp, margin, totalSaleRate, enterSaleRate, updatedSaleRate, closingQty, location, quantity, feedback, order_date)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    $adminOrderStmt = $conn->prepare($adminOrderQuery);
                    $account_type = "Customer";
                    $adminOrderStmt->bind_param("sissssssdidddssisiss", $submit_id, $customer_id, $fullname, $account_type, $productName, $batch, $company, $partNo, $purchaseRate, $gst, $exp, $margin, $totalSaleRate, $enterSaleRate, $updatedSaleRate, $closingQty, $location, $quantity, $feedback, $currentDateTime);
                    $adminOrderStmt->execute();
                    $adminOrderStmt->close();

                    // Delete from customer_cart
                    $delete = "DELETE FROM customer_cart WHERE id = ? AND customer_id = ?";
                    $stmt = $conn->prepare($delete);
                    $stmt->bind_param("ii", $productid, $customer_id);
                    $stmt->execute();
                    $stmt->close();
                }
            }
        // Redirect after form submission (PRG pattern)
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
        } 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../customer/css/order_product.css">
    <title>Customer Orders</title>
</head>
<body>
    <?php include("preloader.html"); ?>
<a href='customer_dashboard.php' class='back-button'><img src="../image/h1.png" class="home" alt="ok"></a>

<?php
    $query = "SELECT * FROM customer_orders WHERE customer_id = ? ORDER BY created_at DESC";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $customer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $serialNumber = 1;
    $stmt->close();
?>
    <div class="container mt-4">
    <?php if ($result->num_rows > 0): ?>
        <div class="card shadow-lg border-0">
            <div class="card-body">
            <h2 class="text-center mb-4 text-primary fw-bold">Your Orders</h2>
                <div class="d-flex justify-content-end mb-3">
                <button class="btn btn-danger shadow-sm delete-btn"><i class="fas fa-trash"></i> Delete Orders</button></div>
                <div class="table-container">
                    <div class="printable-content">
                        <table border="1" class="table table-hover table-striped align-middle text-center table table-bordered" id="ordersTable">
                            <thead class="table-primary sticky-top shadow-sm">
                                <tr>
                                    <th><input type="checkbox" id="select-all-orders" style="background:none;box-shadow:none;height:18px;align-item:center;"></th>
                                    <th>Sr.No</th>
                                    <th>Product</th>
                                    <th>Customer</th>
                                    <th>Company</th>
                                    <th>Part No</th>
                                    <th>Quantity</th>
                                    <th>Order Date</th>
                                    <th>Feedback</th>
                                    <th>Delete</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $result->fetch_assoc()): ?>
                                    <div class='order-details' id='order-item-<?= $row['id']; ?>'></div>
                                    <tr data-order-id="<?php echo $row['id']; ?>" data-submit-id="<?php echo $row['submit_id']; ?>">
                                        <td data-lable="Check Box"><input type="checkbox" style="background:none;box-shadow:none;height:18px;align-item:center;"></td>
                                        <td><?php echo $serialNumber++; ?></td>
                                        <td data-lable="Product"><?php echo htmlspecialchars($row['product']); ?></td>
                                        <td data-label="Customer"><?php echo htmlspecialchars($row['customer_fullname']); ?></td>
                                        <td data-label="Company"><?php echo htmlspecialchars($row['company']); ?></td>
                                        <td data-label="Part No"><?php echo htmlspecialchars($row['partNo']); ?></td>
                                        <td><span class="quantity-text"><?php echo htmlspecialchars($row['quantity']); ?></span>
                                        <input type="number" class="quantity-input d-none" value="<?php echo htmlspecialchars($row['quantity']); ?>"></td>
                                        <td data-lable="Order Date"><?php echo htmlspecialchars($row['order_date']); ?></td>
                                        <td class="feedback-column"><?php echo htmlspecialchars($row['feedback']); ?></td>
                                        <td data-lable="Delete"><button type="button" class='delete-btn' data-order-id="<?php echo $row['id']; ?>"><i class="fas fa-trash-alt"></i></button></td>
                                        <td><button class="btn btn-primary edit-btn"><i class="fa-solid fa-pencil"></i>Edit</button></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>         
                    </div>
                </div>
                </div>
            <?php else: ?>
                <tr>
                    <td colspan="15" class="text-center">No orders found.</td>
                </tr>
                <?php endif; ?>
    </div>
<script src="../customer/order_product.js"></script>
<script>
    document.querySelectorAll(".edit-btn").forEach(button => {
        button.addEventListener("click", function() {
            let row = this.closest("tr");
            let quantityText = row.querySelector(".quantity-text");
            let quantityInput = row.querySelector(".quantity-input");

            quantityText.classList.add("d-none");
            quantityInput.classList.remove("d-none");
            quantityInput.focus();
        });
    });

    document.querySelectorAll(".quantity-input").forEach(input => {
        input.addEventListener("keypress", function(e) {
            if (e.key === "Enter") {
                let row = this.closest("tr");
                let orderId = row.getAttribute("data-order-id");
                let submitId = row.getAttribute("data-submit-id");
                let newQuantity = this.value;

                fetch("order_update.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/x-www-form-urlencoded" },
                    body: "order_id=" + orderId + "&submit_id=" + submitId + "&quantity=" + newQuantity
                })
                .then(response => response.text())
                .then(data => {
                    if (data === "success") {
                        row.querySelector(".quantity-text").textContent = newQuantity;
                        row.querySelector(".quantity-text").classList.remove("d-none");
                        row.querySelector(".quantity-input").classList.add("d-none");
                    } else {
                        alert("Failed to update quantity");
                    }
                });
            }
        });
    });
</script>
</body>
</html>
