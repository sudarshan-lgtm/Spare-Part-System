<?php
include '../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $order_id = $_POST["order_id"];
    $submit_id = $_POST["submit_id"];
    $quantity = $_POST["quantity"];

    if (!empty($order_id) && !empty($submit_id) && is_numeric($quantity)) {
        // Check submit_id exists in both tables
        $query_check = "SELECT COUNT(*) as count FROM customer_orders WHERE submit_id = ?";
        $stmt_check = $conn->prepare($query_check);
        $stmt_check->bind_param("s", $submit_id);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();
        $row_check = $result_check->fetch_assoc();
        $stmt_check->close();

        if ($row_check['count'] > 0) {
            // Update customer_orders
            $query_customer_orders = "UPDATE customer_orders SET quantity = ? WHERE submit_id = ?";
            $stmt_customer_orders = $conn->prepare($query_customer_orders);
            $stmt_customer_orders->bind_param("is", $quantity, $submit_id);
            $stmt_customer_orders->execute();
            $stmt_customer_orders->close();

            // Update orders
            $query_orders = "UPDATE orders SET quantity = ? WHERE submit_id = ?";
            $stmt_orders = $conn->prepare($query_orders);
            $stmt_orders->bind_param("is", $quantity, $submit_id);
            $stmt_orders->execute();
            $stmt_orders->close();

            echo "success";
        } else {
            echo "invalid_submit_id";
        }

        $stmt_check->close();
    } else {
        echo "invalid";
    }
}
$conn->close();
?>
