<?php
session_start();
require '../../db.php';

if (!isset($_SESSION['id'])) {
    echo "<p style='text-align:center; color:red;'>Please log in to edit your account.</p>";
    exit;
}

$customer_id = $_SESSION['id'];
$query = "SELECT username, fullname, email, mobile, dob FROM customer WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $customer_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$stmt->close();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $dob = $_POST['dob'];
    $new_password = $_POST['password'];

    if (!empty($new_password)) {
        $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
        $updateQuery = "UPDATE customer SET fullname=?, password=?, email=?, mobile=?, dob=? WHERE id=?";
        $stmt = $conn->prepare($updateQuery);
        $stmt->bind_param("sssssi", $fullname, $hashed_password, $email, $mobile, $dob, $customer_id);
    } else {
        $updateQuery = "UPDATE customer SET fullname=?, email=?, mobile=?, dob=? WHERE id=?";
        $stmt = $conn->prepare($updateQuery);
        $stmt->bind_param("ssssi", $fullname, $email, $mobile, $dob, $customer_id);
    }

    if ($stmt->execute()) {
        echo "<script>alert('Account updated successfully!'); window.location.href = 'account_cust.php';</script>";
    } else {
        echo "<script>alert('Error updating account.');</script>";
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Edit Account</title>
    <style>
        /* Global Styles */
        body { 
            font-family: Arial, sans-serif; 
            background-color: #EEF2FE; 
            text-align: center; 
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        /* Edit Account Container */
        .edit-container {
            width: 90%;
            max-width: 500px;
            background-color: #fff;
            padding: 40px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.4);
            border-radius: 10px;
            overflow-x: auto;
        }

        h2 {
            font-size: 24px;
            color: #333;
            margin-bottom: 15px;
        }

        label {
            display: block;
            font-size: 14px;
            font-weight: bold;
            text-align: left;
            margin: 10px 0 5px;
            color: #333;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 12px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
            background: #f9f9f9;
        }

        input:focus {
            outline: none;
            border-color: #007BFF;
        }

        /* Save Button */
        .save-btn {
            width: 100%;
            background: #007BFF;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
        }

        .save-btn:hover { 
            background: rgb(0, 25, 138); 
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .edit-container {
                width: 90%;
                padding: 20px;
            }
            h2 {
                font-size: 22px;
            }
            label {
                font-size: 13px;
            }
            input {
                font-size: 13px;
                padding: 8px;
            }
            .save-btn {
                font-size: 14px;
                padding: 10px;
            }
        }

        /* Mobile & Small Devices */
        @media (max-width: 480px) {
            .edit-container {
                width: 90%;
                padding: 15px;
            }
            h2 {
                font-size: 20px;
            }
            label {
                font-size: 12px;
                margin-left: 20px;
            }
            input {
                font-size: 12px;
                padding: 8px;
                width: 90%;
            }
            .save-btn {
                font-size: 12px;
                padding: 8px;
            }
        }

        /* Landscape Mode Adjustments for Smartphones & Tablets */
        @media screen and (max-height: 500px) and (orientation: landscape) {
            .edit-container {
                max-width: 70%;
            }
        }

        /* Large Screens */
        @media (min-width: 1200px) {
            .edit-container {
                max-width: 600px;
            }
        }
    </style>
</head>
<body>

<h2>Edit Account</h2>
<div class="edit-container">
    <form action="" method="POST">
        <label>Username:</label>
        <input type="text" name="username" value="<?= htmlspecialchars($row['username']); ?>" disabled>

        <label>Full Name:</label>
        <input type="text" name="fullname" value="<?= htmlspecialchars($row['fullname']); ?>" required>

        <label>New Password:</label>
        <input type="password" name="password" placeholder="Enter new password (leave empty to keep old)">

        <label>Email:</label>
        <input type="email" name="email" value="<?= htmlspecialchars($row['email']); ?>" required>

        <label>Mobile:</label>
        <input type="text" name="mobile" value="<?= htmlspecialchars($row['mobile']); ?>" required>

        <label>Date of Birth:</label>
        <input type="date" name="dob" value="<?= htmlspecialchars($row['dob']); ?>" required>

        <button type="submit" class="save-btn">Save Changes</button>
    </form>
</div>

</body>
</html>
