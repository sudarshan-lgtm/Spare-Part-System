<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
include '../db.php';
require '../vendor/autoload.php';

if (!isset($_SESSION['id'])) {
    header("Location: customer_login.php"); 
    exit();
}

$fullname = "";
    $customer_id = "";
    if (isset($_SESSION['id'])) {
        $customer_id = $_SESSION['id']; // Get the logged-in customer ID
        $query = "SELECT fullname FROM customer WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $customer_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $fullname = htmlspecialchars($row['fullname']);
        }
        $stmt->close();
    }

    // Fetch download visibility status
    $query = "SELECT download_visibility FROM settings WHERE id = 1";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    $download_enabled = ($row && $row['download_visibility'] == 1) ? 'true' : 'false';

    if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $customer_id = $_SESSION['id'];
        $product = $_POST['Product'];
        $batch = $_POST['Batch'];
        $company = $_POST['Company'];
        $partNo = $_POST['PartNo'];
        $purchaseRate = $_POST['PurchaseRate'];
        $gst = $_POST['GST'];
        $exp = !empty($_POST['Exp']) ? $_POST['Exp'] : '2025-12-31'; 
        $margin = $_POST['Margin'];
        $saleRate = isset($_POST['SaleRate']) ? floatval($_POST['SaleRate']) : 0;
        $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;
        $totalSaleRate = $saleRate * $quantity;
        $closingQty = isset($_POST['closingQty']) ? $_POST['closingQty'] : 0;
        $location = isset($_POST['location']) ? $_POST['location'] : "NA";
        $imagePath = $_POST['imagePath'];
        $feedback = "";

        $imageBasePath = "../admin folders/";
        if (strpos($imagePath, $imageBasePath) === false) {
            $imagePath = $imageBasePath . $imagePath;
        }
        
        // Insert data into the database
        $query = "INSERT INTO customer_cart (customer_id, product, batch, company, partNo, purchaseRate, gst, exp, margin, saleRate,  totalSaleRate, closingQty, location, imagePath, quantity, feedback) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($query);
        if ($stmt) {
        $stmt->bind_param("issssdidsddsssss", $customer_id, $product, $batch, $company, $partNo, $purchaseRate, $gst, $exp, $margin, $saleRate,  $totalSaleRate, $closingQty, $location, $imagePath, $quantity, $feedback);

        if ($stmt->execute()) {
        echo "<script>alert('Product added to cart successfully');</script>";
        echo "<script> window.location.href='customer_dashboard.php';</script>";
        } else {
        echo "<script>alert('Error inserting data: " . $stmt->error . "');</script>";
        }
        $stmt->close();
        } else {
        echo "<script>alert('Failed to prepare the SQL statement');</script>";
        }
        
    }
    //Marquee Images from offers to customer dashboard
// Marquee Images from offers to customer dashboard
$query = "SELECT id, Product FROM offers";  
$result = mysqli_query($conn, $query);

$product_ids = [];
while ($row = mysqli_fetch_assoc($result)) {
    $product_ids[] = $row['id'];
}

$products = [];

if (!empty($product_ids)) {
    $query = "SELECT 
        p.Product,
        p.imagePath,
        p.Batch,
        p.PartNo,
        p.Company,
        p.PurchaseRate,
        p.GST,
        p.EXP,
        p.Margin,
        p.SaleRate,
        p.ReceiptQty,
        p.IssueQty,
        o.Discount
      FROM productinventory p
      INNER JOIN offers o ON p.Product = o.Product
      WHERE o.Module = 'Customer'
      GROUP BY p.Product";

    $product_result = mysqli_query($conn, $query);

    while ($product = mysqli_fetch_assoc($product_result)) {
        if (isset($product['Product'])) {
            $products[] = $product;
        }
    }
} else {
    echo "Error in query: " . mysqli_error($conn);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <!-- Bootstrap CSS -->
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <link rel="stylesheet" href="../customer/css/cust_page.css">
    <link rel="stylesheet" href="../customer/css/cust_sidebar.css">
    <title>Customer Dashboard</title>
    <style>
        .popup-container {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0, 0, 0, 0.85);
            z-index: 9999;
            justify-content: center;
            align-items: center;
        }
        
        .popup-content {
            background-color: #EEF2FE; /* Light teal */
            background-size: 400% 400%;
            padding: 20px;
            width: 90%;
            height: 90%;
            overflow-y: auto;
            position: relative;
            border-radius: 15px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5);
            animation: zoomIn 0.5s ease forwards, gradientShift 8s ease infinite;
        }
        
        /* Gradient background animation */
        @keyframes gradientShift {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        .zoom-animation {
            animation: zoomIn 0.5s ease forwards;
        }
        @keyframes zoomIn {
            0% { transform: scale(0.7); opacity: 0; }
            100% { transform: scale(1); opacity: 1; }
        }
        
        .close-btn {
            position: absolute;
            top: 10px;
            right: 15px;
            background: red;
            color: white;
            border: none;
            font-size: 20px;
            cursor: pointer;
            border-radius: 50%;
            padding: 0 10px;
            z-index: 10000;
        }
        @keyframes sexySlideAway {
            0% {
                transform: scale(1) rotate(0deg) translateY(0);
                opacity: 1;
            }
            60% {
                transform: scale(0.9) rotate(-3deg) translateY(50px);
                opacity: 0.6;
            }
            100% {
                transform: scale(0.4) rotate(-10deg) translateY(400px);
                opacity: 0;
            }
        }
        
        .sexy-close {
            animation: sexySlideAway 0.7s ease-in-out forwards;
            transform-origin: center;
            perspective: 1000px;
        }
        .slider-container {
            width: 300px;
            margin: 20px auto;
            overflow: hidden;
            position: relative;
            filter: drop-shadow(1px 1px 20px rgb(41, 37, 37));
        }
        .slider {
            display: flex;
            transition: transform 0.5s ease-in-out;
        }
        .slider-item {
            min-width: 100%;
            box-sizing: border-box;
            text-align: center;
            border: 1px solid #ddd;
            border-radius: 10px;
            position: relative;
            padding: 15px;
            background-color: #fff;
            line-height: 1.2;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
        }
        .slider-item img {
            width: 100%;
            height: 250px;
            object-fit: cover;
            border-radius: 10px;
            margin-bottom: 10px;
        }

        .offer-popup {
            position: absolute;
            top: 10px;
            left: 10px;
            background: red;
            color: white;
            padding: 5px 10px;
            font-weight: bold;
            border-radius: 5px;
            font-size: 14px;
            z-index: 5;
        }

        .slider-buttons {
            position: absolute;
            top: 50%;
            width: 100%;
            display: flex;
            justify-content: space-between;
            transform: translateY(-50%);
        }

        .slider-buttons button {
            background-color: rgba(0, 0, 0, 0.6);
            color: white;
            border: none;
            padding: 10px;
            cursor: pointer;
            border-radius: 5px;
        }

        .slider-buttons button:hover {
            background-color: rgba(0, 0, 0, 0.8);
        }

        .quantity-btn {
            border: none;
            border-radius: 5px;
            color: white;
            margin-top: 0;
            margin-bottom: 5px;
            padding: 10px 15px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
        .minus {
            background-color: #03A9F4; /* Red color for the minus button */
        }
        .minus:hover {
            background-color: #0288D1; /* Darker shade of red for hover effect */
        }
        .plus {
            background-color: #4CAF50; /* Blue color for the plus button */
        }
        .plus:hover {
            background-color: #388E3C; /* Darker shade of blue for hover effect */
        }

        @media (max-width: 768px) {
            .slider-container {
            width: 300px;/* Adjust width as needed */
            overflow: hidden;
            position: relative;
            margin: 50px auto;
            margin-top: 2%;
        }
        }
    </style>
</head>
<body>
    <?php include("preloader.html"); ?>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <a href="../customer/customer_dashboard.php"><img src="../image/RJ bg.png" class="logo" alt="RJ"></a>
        <a href="cart_product.php" class="cart-icon" onclick="openCart()"><img src="../image/shopping-cart.png" class="cart" alt="tau"></a>
    </nav>
    <!-- Overlay -->  
    <div class="overlay" id="overlay" onclick="toggleSidebar()"></div>
    <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="toggle-btn-container">
            <span class="welcome"><marquee behavior="scroll" direction="left" scrollamount="5">Welcome - <?= $fullname ?></marquee></span>
            <button class="toggle-btn" onclick="toggleSidebar()">☰</button>
            </div>
            <ul class="sidebar-menu">
                <li style="margin-top:20px;"><a href="customer_dashboard.php" style="text-decoration:none; color:#fff;">🏠 Home</a></li>
                <li><a href="../customer/sidebar/facility.html" style="text-decoration:none; color:#fff;"> 🏢 Facility</a></li>
                <li><a href="../customer/sidebar/edit_account.php" style="text-decoration:none; color:#fff;"> 👤️ Edit Account</a></li>
                <li><a href="../customer/sidebar/gallary.php" style="text-decoration:none; color:#fff;">🖼️ Gallery</a></li>
                <li><a href="../customer/customer_logout.php" style="text-decoration:none; color:#fff; padding:10px; background: linear-gradient(45deg, #6a11cb, #2575fc); border-radius: 10px; width: 20%;"><img style="height:auto; width: 15%;" src="../image/logo/logout2.png" alt="logout"> Logout</a></li>
            </ul>
        </div>    
    </div>   
    <div class="contact-card">
        <div class="contact-item">
            <strong><i class='fas fa-user-alt'></i> Yogesh Patil :</strong>  <a href="tel:9834530051" style="text-decoration:none; color:black;">9834530051</a>
        </div>
        <div class="contact-item">
            <strong><i class='fas fa-briefcase'></i> Office Contact:</strong> <a href="tel:9881247444" style="text-decoration:none; color:black;">9881247444</a>
        </div>
    </div>
    <!-- Marquee Section for Images -->
    <div id="offerPopup" class="popup-container">
    <div class="popup-content zoom-animation">
        <button class="close-btn" onclick="closePopup()">✖</button>
            <div class="slider-container">
                <div class="slider" id="productSlider">
                    <?php if (!empty($products)): ?>
                        <?php foreach ($products as $product): ?>
                            <div class="slider-item">
                                <!--img src="../image/logo/offer.png" class="offer" alt="offers"-->
                                <img src="../admin folders/<?php echo isset($product['imagePath']) ? $product['imagePath'] : 'default-image.jpg'; ?>" alt="<?php echo isset($product['Product']) ? $product['Product'] : 'No Name'; ?>" />
                                <?php if (!empty($product['Discount'])): ?>
                                    <div class="offer-popup">
                                        <?php echo htmlspecialchars($product['Discount']); ?>% OFF
                                    </div>
                                <?php endif; ?>
                                <p><strong>Product:</strong> <?php echo isset($product['Product']) ? htmlspecialchars($product['Product']) : 'No Product'; ?></p>
                                <p><strong>Part No:</strong> <?php echo isset($product['PartNo']) ? htmlspecialchars($product['PartNo']) : 'No Part Number'; ?></p>
                                <p><strong>Company:</strong> <?php echo isset($product['Company']) ? htmlspecialchars($product['Company']) : 'No Company'; ?></p>
                                
                                <!-- Hidden Details -->
                                <p style="display:none;"><strong>EXP:</strong> <?php echo isset($product['Exp']) ? $product['Exp'] : 'No EXP'; ?></p>
                                
                                <form action="customer_dashboard.php" method="POST">
                                    <input type="hidden" name="Product" value="<?php echo htmlspecialchars($product['Product']); ?>">
                                    <input type="hidden" name="Batch" value="<?php echo htmlspecialchars($product['Batch']); ?>">
                                    <input type="hidden" name="PartNo" value="<?php echo htmlspecialchars($product['PartNo']); ?>">
                                    <input type="hidden" name="Company" value="<?php echo htmlspecialchars($product['Company']); ?>">
                                    <input type="hidden" name="PurchaseRate" value="<?php echo isset($product['PurchaseRate']) ? $product['PurchaseRate'] : 0; ?>">
                                    <input type="hidden" name="GST" value="<?php echo isset($product['GST']) ? $product['GST'] : 0; ?>">
                                    <input type="hidden" name="Exp" value="<?php echo isset($product['Exp']) ? $product['Exp'] : ''; ?>">
                                    <input type="hidden" name="Margin" value="<?php echo isset($product['Margin']) ? $product['Margin'] : 0; ?>">
                                    <input type="hidden" name="SaleRate" value="<?php echo isset($product['SaleRate']) ? $product['SaleRate'] : 0; ?>">
                                    <input type="hidden" name="ReceiptQty" value="<?php echo isset($product['ReceiptQty']) ? $product['ReceiptQty'] : 0; ?>">
                                    <input type="hidden" name="IssueQty" value="<?php echo isset($product['IssueQty']) ? $product['IssueQty'] : 0; ?>">
                                    <input type="hidden" name="imagePath" value="<?php echo htmlspecialchars($product['imagePath']); ?>">
        
                                    <!-- Quantity Buttons -->
                                    <div style="display: flex; justify-content: center; align-items: center; gap: 10px; margin-top: 10px;">
                                        <button type="button" class="quantity-btn minus" onclick="updateQuantity(this, -1)">-</button>
                                        <input type="number" name="quantity" value="1" min="1" style="width: 50px; text-align: center;">
                                        <button type="button" class="quantity-btn plus" onclick="updateQuantity(this, 1)">+</button>
                                    </div>
        
                                    <button type="submit"  style="color: red; border: 2px solid red;" onclick="syncQuantity('<?php echo htmlspecialchars($product['PartNo']); ?>')">Add To Cart</button>
                                </form>
                                </div>
                        <?php endforeach; ?>
                    <?php else: ?> 
                        <p>No products found</p>
                    <?php endif; ?>
                </div>
        
                <div class="slider-buttons">
                    <button onclick="prevSlide()">⬅</button>
                    <button onclick="nextSlide()">➡</button>
                </div>
            </div>
        </div>
    </div>

    <div class="header">
        <div class="card-container">
            <a href="javascript:void(0);" onclick="openPopup()">
                <div class="card">
                    <img src="../image/logo/offer.png" alt="offer Icon" loading="lazy">
                    <h5>Offers</h5>
                </div>
            </a>
            <a href="order_product.php">
                <div class="card">
                    <img src="../image/logo/order.png" alt="Order Icon" loading="lazy">
                    <h5>Your Orders</h5>
                </div>
            </a>
            <a href="product_group.php">
                <div class="card">
                    <img src="../image/logo/product-management.png" alt="Category Icon" loading="lazy">
                    <h5>Product Groups</h5>
                </div>
            </a>
            <a href="company_cust.php">
                <div class="card">
                    <img src="../image/logo/companies.png" alt="Loyalty Icon" loading="lazy">
                    <h5>Companies</h5>
                </div>
            </a>
            <!--<a href="#" id="downloadButton">
                <div class="card">
                    <img src="../image/logo/download-data.png" alt="Download Icon" loading="lazy">
                    <h5>Download</h5>
                </div>
            </a> -->
            <a href="account_cust.php">
                <div class="card">
                    <img src="../image/logo/user.png" alt="Account Icon" loading="lazy">
                    <h5>Payment</h5>
                </div>
            </a>
            <a href="cust_contact.php">
                <div class="card">
                    <img src="../image/logo/contact-us.png" alt="Loyalty Icon" loading="lazy">
                    <h5>Contact Us</h5>
                </div>
            </a>
        </div>
    </div>
    <footer>
        <div class="footer-container">
            <div class="about-us">
                <h4>About Us</h4>
                <p>Your one-stop destination for high-quality spare parts. Find the right part for your vehicle effortlessly with our advanced search and categorized product groups. Order with confidence and get the best deals on premium auto parts.</p>
            </div>
            <div class="order-spares">
                <h4>Order Spare Parts</h4>
                <p>Looking for genuine spare parts? Use our **Search Part Number** feature or browse through **Product Groups** to find the perfect match for your vehicle. We ensure top-quality, fast delivery, and competitive pricing.</p>
            </div>
            <div class="contact-us">
                <h4>Contact Us</h4>
                <P>Email: rjautoheaven@gmail.com</P>
                <p>Phone: 9834530051</p>
                <p>Address: Gat No. 288/2, Plot No.2, A/P-kondi, TQ, North Solapur, Dist: Solapur</p>
            </div>
            <div class="follow-us">
                <h4>Follow Us</h4>
                <div class="social-icons">
                    <a href="https://www.facebook.com/"><img src="../image/logo/facebook.png" alt="Facebook"></a>
                    <a href="https://www.instagram.com/"><img src="../image/logo/instagram.png" alt="Instagram"></a>
                    <a href="https://www.linkedin.com/"><img src="../image/logo/linkedin.png" alt="LinkedIn"></a>
                    <a href="https://www.twitter.com/"><img src="../image/logo/twitter.png" alt="Twitter"></a>
                </div>
            </div>
        </div>
        <div class="container mb-4">
            <h4 class="mb-4 text-center text-danger">RJ AUTOHEAVEN Policies</h4>
            <div class="d-flex flex-column flex-md-row justify-content-around align-items-center gap-3">
                <a href="../Privacy_Policy.html" class="btn btn-outline-primary w-100 w-md-auto">Privacy Policy</a>
                <a href="../terms_conditions.html" class="btn btn-outline-success w-100 w-md-auto">Terms & Conditions</a>
                <a href="../return_refund_policy.html" class="btn btn-outline-danger w-100 w-md-auto">Return & Refund Policy</a>
            </div>
        </div>
        <div class="footer-bottom">
            <small>Developed by <a href="customer_dashboard.php" class="text-info"><img src="../image/sud2.png" class="sudarshan"></a> | © 2025 RJ AUTOHEAVEN. All Rights Reserved.</small>
        </div>  
    </footer>
    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById("sidebar");
            const overlay = document.getElementById("overlay");

            // Toggle the 'open' class on the sidebar
            sidebar.classList.toggle("open");

            // Show or hide the overlay based on sidebar state
            if (sidebar.classList.contains("open")) {
                overlay.classList.add("active");
            } else {
                overlay.classList.remove("active");
            }
        }
        function openCart() {
            alert("Cart functionality will be implemented here!");
            // Add your cart logic here (e.g., redirect to cart page, display cart modal, etc.)
        }    

        //Marquee JS
        let currentIndex = 0;
        const slider = document.getElementById("productSlider");
        const slides = document.querySelectorAll(".slider-item");
        const totalSlides = slides.length;
    
        function updateSlide() {
            slider.style.transform = `translateX(${-currentIndex * 100}%)`;
        }
    
        function nextSlide() {
            currentIndex = (currentIndex + 1) % totalSlides;
            updateSlide();
        }
    
        function prevSlide() {
            currentIndex = (currentIndex - 1 + totalSlides) % totalSlides;
            updateSlide();
        }
    
        // Auto slide every 5 seconds
        setInterval(nextSlide, 5000);
    
        function openPopup() {
            const popup = document.getElementById('offerPopup');
            popup.style.display = 'flex';
        }
    
        function closePopup() {
            const popup = document.getElementById('offerPopup');
            const content = popup.querySelector('.popup-content');
        
            // Remove old animation if any
            content.classList.remove('zoom-animation');
        
            // Add sexy close animation
            content.classList.add('sexy-close');
        
            // Wait till animation completes
            content.addEventListener('animationend', function handleClose() {
                popup.style.display = 'none';
        
                // Reset for next open
                content.classList.remove('sexy-close');
                content.classList.add('zoom-animation');
        
                content.removeEventListener('animationend', handleClose);
            });
        }


        // Quantity Functions
        function updateQuantity(button, change) {
            const input = button.parentElement.querySelector('input[name="quantity"]');
            let quantity = parseInt(input.value) + change;
            if (quantity < 1) quantity = 1;
            input.value = quantity;
        }

        //Download Visibility
        document.getElementById('downloadButton').addEventListener('click', function(event) {
            let downloadEnabled = <?php echo $download_enabled; ?>; // Get PHP value as JS variable
            
            if (!downloadEnabled) {
                alert("Oops! This feature is currently unavailable.");
                event.preventDefault(); // Prevents navigating to download.php
            } else {
                window.location.href = "download.php"; // Open download page
            }
        });
    </script>
    <script>
  // Check if the cookie exists
  if (!document.cookie.split('; ').find(row => row.startsWith('visited='))) {
    // Set cookie for 7 days
    document.cookie = "visited=true; max-age=" + 60 * 60 * 24 * 7 + "; path=/";
    console.log("First-time visit: full content loading");
  } else {
    console.log("Returning visitor: use optimized content if needed");
    // तुम्ही इथे placeholder images किंवा low-res images लावू शकता
  }
</script>
<script>
    // Check if login was successful
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('login') === 'success') {
        // Speak login success in a woman's voice
        const utterance = new SpeechSynthesisUtterance("Login successful");
        utterance.lang = 'en-US';

        // Set voice to female if available
        const voices = window.speechSynthesis.getVoices();
        const femaleVoice = voices.find(voice => voice.name.includes('Female') || voice.name.includes('Samantha') || voice.gender === 'female');
        if (femaleVoice) {
            utterance.voice = femaleVoice;
        }

        window.speechSynthesis.speak(utterance);

        // Remove the URL parameter to prevent repeated play
        if (window.history.replaceState) {
            const cleanUrl = window.location.origin + window.location.pathname;
            window.history.replaceState({}, document.title, cleanUrl);
        }
    }
</script>

</body>
</html>