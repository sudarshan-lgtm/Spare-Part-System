<?php
session_start();
include '../db.php';

if (!isset($_SESSION['id'])) {
    header("Location: customer_login.php"); 
    exit();
}

// Initialize cart count
$cart_count = 0;

// Fetch cart count from database
$result = $conn->query("SELECT COUNT(*) as count FROM customer_cart");
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $cart_count = $row['count'];
}

// Get the logged-in customer's full name and ID
$fullname = "";
$customer_id = "";
if (isset($_SESSION['id'])) {
    $customer_id = $_SESSION['id'];
    $query = "SELECT fullname FROM customer WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $customer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $fullname = htmlspecialchars($row['fullname']);
    }
    $stmt->close();
}

// Fetch hidden columns for customer
$hiddenColumns = [];
$query = "SELECT column_name FROM hiddencolumns WHERE user_id = ? AND user_type = ?";
$stmt = $conn->prepare($query);
$userType = 'customer';
$stmt->bind_param("is", $customer_id, $userType);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $hiddenColumns[] = $row['column_name'];
}
$stmt->close();
// Get part number from URL
$partNo = isset($_GET['partNo']) ? $_GET['partNo'] : '';

$productData = [];
$imagePath = 'no-image.jpg'; // Default image if no image is found

if (!empty($partNo)) {
    $query = "SELECT * FROM productinventory WHERE PartNo = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $partNo);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $productData = $result->fetch_assoc();

        // Check if image path exists in the database
        if (!empty($productData['imagePath']) && file_exists("../admin folders/" . $productData['imagePath'])) {
            $imagePath = "../admin folders/" . $productData['imagePath'];
        }
    }
    $stmt->close();
}

mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="../customer/css/partNo.css">
    <title>Part Number Details</title>
    <script>
        function updateQuantity(button, change) {
            const input = button.parentElement.querySelector("input[name='quantity']");
            let currentValue = parseInt(input.value);
            currentValue += change;
            if (currentValue < 1) currentValue = 1; // Prevent values less than 1
            input.value = currentValue;
        }

        function addToCart(event, form) {
            event.preventDefault(); // Prevent form submission to handle it via AJAX

            const formData = new FormData(form); // Collect form data

            // Send data to cart_product.php via POST request
            fetch("cart_product.php", {
                method: "POST",
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                if (data.includes("Product added to cart successfully")) {
                    const addButton = form.querySelector("button.addToCart");
                    const originalText = addButton.textContent;
                    addButton.textContent = "Added To Cart";
                    addButton.style.backgroundColor = "#28a745"; // Green
                    addButton.style.color = "#fff";
                    addButton.disabled = true;

                    setTimeout(() => {
                        addButton.textContent = originalText;
                        addButton.style.backgroundColor = "";
                        addButton.style.color = "";
                        addButton.disabled = false;
                    }, 3000);
                    updateCartCount(); // Update cart count after adding
                } else {
                    alert("Failed to add product to cart: " + data);
                }
            })
            .catch(error => {
                console.error("Error:", error);
                alert("An error occurred while adding the product to the cart.");
            });
        }

        // Popup functionality
        document.addEventListener("DOMContentLoaded", function() {
            const productImage = document.getElementById("productImage");
            const modal = document.createElement("div");
            modal.className = "modal";
            modal.innerHTML = `
                <div class="modal-content">
                    <span class="close-btn">×</span>
                    <img src="${productImage ? productImage.src : ''}" alt="Product Image">
                    <h3>${document.getElementById("product") ? document.getElementById("product").textContent : ''}</h3>
                </div>
            `;
            document.body.appendChild(modal);

            const closeBtn = modal.querySelector(".close-btn");

            if (productImage) {
                productImage.addEventListener("click", () => {
                    modal.style.display = "flex";
                });
            }

            closeBtn.addEventListener("click", () => {
                modal.style.display = "none";
            });

            // Close modal when clicking outside the modal content
            modal.addEventListener("click", (e) => {
                if (e.target === modal) {
                    modal.style.display = "none";
                }
            });
        });

        // Keyboard Shortcut Key
        document.addEventListener("keydown", function(event) {
            const activeElement = document.activeElement;
            if (event.key === "Backspace" && (activeElement.tagName !== "INPUT" && activeElement.tagName !== "TEXTAREA")) {
                event.preventDefault();
                window.history.back();
            }
        });

        function updateCartCount() {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "cart_product_count.php", true);
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    let count = xhr.responseText.trim();
                    let cartBadge = document.getElementById("cart-count");
                    if (cartBadge.innerText !== count) {
                        cartBadge.innerText = count;
                        cartBadge.classList.add("updated"); // Apply animation effect
                        setTimeout(() => cartBadge.classList.remove("updated"), 300);
                    }
                }
            };
            xhr.send();
        }

        // Auto-update every 2 seconds (without refresh)
        setInterval(updateCartCount, 2000);

        // Call once on page load
        updateCartCount();
    </script>
</head>
<body>
    <?php include("preloader.html"); ?>
    <nav class="navbar">
        <a href="customer_dashboard.php" class="back-button"><img src="../image/h1.png" class="home" alt="Home"></a>
        <img src="../image/RJ bg.png" class="logo" alt="Logo">
        <a href="../customer/cart_product.php" class="cart-icon">
            <img src="../image/shopping-cart.png" class="cart" alt="Cart">
            <span id="cart-count" class="cart-number"><?php echo $cart_count; ?></span>
        </a>
    </nav>

    <?php if (!empty($productData)): ?>
        <div class="card">
            <img id="productImage" src="<?= htmlspecialchars($imagePath) ?>" alt="Product Image">
            <h4><span id="product"><?= htmlspecialchars($productData['Product']) ?></span></h4>

            <?php if (!in_array('Batch', $hiddenColumns)) { ?>
                <p><strong>Batch:</strong> <span id="batch"><?= htmlspecialchars($productData['Batch'] ?? '') ?></span></p>
            <?php } ?>
            <?php if (!in_array('Company', $hiddenColumns)) { ?>
                <p><strong>Company:</strong> <span id="company"><?= htmlspecialchars($productData['Company'] ?? '') ?></span></p>
            <?php } ?>
            <?php if (!in_array('PartNo', $hiddenColumns)) { ?>
                <p><strong>Part No:</strong> <span id="partNoDisplay"><?= htmlspecialchars($productData['PartNo'] ?? '') ?></span></p>
            <?php } ?>
            <?php if (!in_array('PurchaseRate', $hiddenColumns)) { ?>
                <p><strong>Purchase Rate:</strong> <span id="purchaseRate"><?= htmlspecialchars($productData['PurchaseRate'] ?? '') ?></span></p>
            <?php } ?>
            <?php if (!in_array('GST', $hiddenColumns)) { ?>
                <p><strong>GST:</strong> <span id="gst"><?= htmlspecialchars($productData['GST'] ?? '') ?></span></p>
            <?php } ?>
            <?php if (!in_array('Exp', $hiddenColumns)) { ?>
                <p><strong>Exp:</strong> <span id="exp"><?= htmlspecialchars($productData['Exp'] ?? '') ?></span></p>
            <?php } ?>
            <?php if (!in_array('Margin', $hiddenColumns)) { ?>
                <p><strong>Margin:</strong> <span id="margin"><?= htmlspecialchars($productData['Margin'] ?? '') ?></span></p>
            <?php } ?>
            <?php if (!in_array('PurchaseCode', $hiddenColumns)) { ?>
                <p><strong>Purchase Code:</strong> <span id="purchaseCode"><?= htmlspecialchars($productData['PurchaseCode'] ?? '') ?></span></p>
            <?php } ?>
            <?php if (!in_array('SaleRate', $hiddenColumns)) { ?>
                <p><strong>Sale Rate:</strong> <span id="saleRate"><?= htmlspecialchars($productData['SaleRate'] ?? '') ?></span></p>
            <?php } ?>
            <?php if (!in_array('ReceiptQty', $hiddenColumns)) { ?>
                <p><strong>Receipt Qty:</strong> <span id="receiptQty"><?= htmlspecialchars($productData['ReceiptQty'] ?? '') ?></span></p>
            <?php } ?>
            <?php if (!in_array('IssueQty', $hiddenColumns)) { ?>
                <p><strong>Issue Qty:</strong> <span id="issueQty"><?= htmlspecialchars($productData['IssueQty'] ?? '') ?></span></p>
            <?php } ?>
            <?php if (!in_array('ClosingQty', $hiddenColumns)) { ?>
                <p><strong>Closing Qty:</strong> <span id="closingQty"><?= htmlspecialchars($productData['ClosingQty'] ?? '') ?></span></p>
            <?php } ?>
            <?php if (!in_array('Location', $hiddenColumns)) { ?>
                <p><strong>Location:</strong> <span id="location"><?= htmlspecialchars($productData['Location'] ?? '') ?></span></p>
            <?php } ?>
                    
            <form onsubmit="addToCart(event, this)">
                <input type="hidden" name="customer_id" value="<?= $customer_id ?>">
                <input type="hidden" name="PartNo" value="<?= $productData['PartNo'] ?>">
                <input type="hidden" name="Product" value="<?= $productData['Product'] ?>">
                <input type="hidden" name="Batch" value="<?= $productData['Batch'] ?>">
                <input type="hidden" name="Company" value="<?= $productData['Company'] ?>">
                <input type="hidden" name="PurchaseRate" value="<?= $productData['PurchaseRate'] ?>">
                <input type="hidden" name="GST" value="<?= $productData['GST'] ?>">
                <input type="hidden" name="EXP" value="<?= $productData['Exp'] ?>">
                <input type="hidden" name="Margin" value="<?= $productData['Margin'] ?>">
                <input type="hidden" name="SaleRate" value="<?= $productData['SaleRate'] ?>">
                <input type="hidden" name="ReceiptQty" value="<?= $productData['ReceiptQty'] ?>">
                <input type="hidden" name="IssueQty" value="<?= $productData['IssueQty'] ?>">
                <input type="hidden" name="ClosingQty" value="<?= $productData['ClosingQty'] ?>">
                <input type="hidden" name="Location" value="<?= $productData['Location'] ?>">
                <input type="hidden" name="imagePath" value="../admin folders/<?= $productData['imagePath'] ?? '' ?>">
                <textarea name="feedback" class="feedbackText" placeholder="Enter Feedback Here" rows="4"></textarea>
                <div style="display: flex; justify-content: center; align-items: center; gap: 10px;">
                    <button type="button" class="quantity-btn minus" onclick="updateQuantity(this, -1)">-</button>
                    <input type="number" name="quantity" value="1" min="1" style="width: 50px; text-align: center;" id="quantity-<?= htmlspecialchars($productData['PartNo']) ?>">
                    <button type="button" class="quantity-btn plus" onclick="updateQuantity(this, 1)">+</button>
                </div>
                <button type="submit" class="addToCart">Add To Cart</button>
            </form>
        </div>
    <?php else: ?>
        <p style="margin-top:100px; font-size:25px; background-color:white; padding:15px; border-radius:10px; box-shadow:2px 2px 10px rgba(0,0,0,0.5);">No product found for the given Part Number.</p>
    <?php endif; ?>
</body>
</html>