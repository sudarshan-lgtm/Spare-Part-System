<?php
include '../db.php'; // Include database connection

$query = isset($_GET['query']) ? $_GET['query'] : '';
$suggestions = [];

if (!empty($query)) {
    $stmt = $conn->prepare("SELECT DISTINCT ProductGroup FROM productinventory WHERE ProductGroup LIKE ?");
    $searchTerm = "%$query%";
    $stmt->bind_param("s", $searchTerm);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $suggestions[] = $row['ProductGroup'];
    }
    $stmt->close();
}

echo json_encode($suggestions);
?>
