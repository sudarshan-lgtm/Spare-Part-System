<?php
session_start(); // Start the session
include '../db.php';

if (!isset($_SESSION['id'])) {
    header("Location: customer_login.php"); 
    exit();
}

// Fetch download visibility status from the database
$query = "SELECT download_visibility FROM settings WHERE id = 1";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);
$current_visibility = $row ? $row['download_visibility'] : 0; // Default OFF

// If Download Option is OFF, show message and stop page execution
if ($current_visibility == 0) {
    die("<h2 style='color: red; text-align: center;'>This option is not available</h2>");
}

$query = "SELECT ProductGroup, Product, Company, PartNo, SaleRate FROM productinventory";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../customer/css/download.css">
    <title>Download Data</title>
</head>
<body>
<a href='customer_dashboard.php' class='back-button'><img src="../image/h1.png" class="home" alt="ok"></a>
    <div class="search-container">
        <button id="searchButton" class="searchButton" style="padding: 10px; margin-top: 80px; float:right;">Search</button>
        <input type="text" id="searchInput" class="searchInput" placeholder="Search the data" style="float:right; margin-top: 80px; margin-right: 10px; padding: 8px;">
    </div>
    <h2>Downloaded Data</h2>
    <div class="download-links">
        <a href="download_data.php?type=excel">Download Excel</a>
        <a href="download_data.php?type=pdf">Download PDF</a>
        <a href="download_data.php?type=csv">Download CSV</a>
    </div>
    <table id="dataTable">
        <tr>
            <!--<th>Sr. No</th>-->
            <th>Product Group</th>
            <th>Product</th>
            <th>Company</th>
            <th>Part No</th>
            <th>Sale Rate</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) : ?>
            <tr>
                <!--<td><?= htmlspecialchars($row['']) ?></td>-->
                <td><?= htmlspecialchars($row['ProductGroup']) ?></td>
                <td><?= htmlspecialchars($row['Product']) ?></td>
                <td><?= htmlspecialchars($row['Company']) ?></td>
                <td><?= htmlspecialchars($row['PartNo']) ?></td>
                <td><?= htmlspecialchars($row['SaleRate']) ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
    <script>
        function searchTable() {
            let filter = document.getElementById('searchInput').value.toLowerCase();
            let rows = document.querySelectorAll('#dataTable tbody tr');

            rows.forEach(row => {
                let text = row.textContent.toLowerCase();
                row.style.display = text.includes(filter) ? '' : 'none';
            });
        }

        // Search when button is clicked
        document.getElementById('searchButton').addEventListener('click', searchTable);

        // Search when Enter key is pressed inside the search input
        document.getElementById('searchInput').addEventListener('keypress', function(event) {
            if (event.key === 'Enter') {
                searchTable();
            }
        });
    </script>
</body>
</html>
