<?php
include '../db.php'; // Database connection file

// Fetch products that have offers
$query = "SELECT p.imagePath, p.Product, p.PartNo, p.Company 
          FROM productinventory p 
          JOIN offers o ON p.id = o.id 
          WHERE p.imagePath IS NOT NULL";

$result = mysqli_query($conn, $query);

$products = [];
while ($row = mysqli_fetch_assoc($result)) {
    $products[] = [
        'imagepath' => $row['imagepath'],
        'product' => $row['product'],
        'partNo' => $row['partNo'],
        'company' => $row['company']
    ];
}

echo '<pre>';
print_r($products); // This will print the array of products
echo '</pre>';
echo json_encode($products);
?>
