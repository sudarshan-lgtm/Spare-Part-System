<?php
session_start();
require '../vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\IOFactory;

if (!isset($_SESSION["id"])) {
    header("Location: member_login.php");
    exit();
}

// Database connection
$pdo = new PDO("mysql:host=127.0.0.1:3306;dbname=u494849712_part", "u494849712_patilnagesh007", "Password@1381");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Fetch latest report
$reportStmt = $pdo->query("SELECT * FROM receivable_report_info2 ORDER BY id DESC LIMIT 1");
$report = $reportStmt->fetch();

$search = $_GET['search'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Receivable Report Viewer</title>
    <link rel="icon" href="../image/icon.png" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #EEF2FE;
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            color: white;
            border-radius: 50%;
            text-decoration: none;
            font-size: 22px;
            transition: all 0.3s ease;
            position: fixed; /* Optional: fixed position */
            top: 10px;
            left: 20px;
            z-index: 999;
        }
        .back-button:hover {
            transform: scale(1.1);
            color: #fff;
        }
        .back-button .home {
            height: 55px; 
            width: auto;  
            margin-right: 10px; 
            vertical-align: middle;
            object-fit: contain;
        }
        .suggestion-box {
            position: absolute;
            background: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            max-height: 300px;
            overflow-y: auto;
            width: 100%;
            margin-top: 45px;
            z-index: 1000;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .suggestion-box div {
            padding: 10px;
            cursor: pointer;
            border-bottom: 1px solid #eee;
        }
        .suggestion-box div:hover {
            background-color: #f0f0f0;
        }
    </style>
</head>
<body>
<?php include('preloader.html'); ?>
<div class="container mt-4">
    <a href='member_dashboard.php' class='back-button'><img src="../image/h1.png" class="home" alt="ok"></a>

    <div class="row justify-content-center mb-4">
        <div class="col-md-6">
            <form method="GET" class="card p-4 shadow" id="searchForm" style="background-color: #fff;">
                <h5 class="text-center mb-3">Search by Customer Name</h5>
                <div class="input-group position-relative">
                    <input type="text" id="customerSearch" name="search" value="<?= htmlspecialchars($search) ?>" class="form-control" autocomplete="off" placeholder="Click to select customer...">
                    <button class="btn btn-primary" type="submit">Search</button>
                    <div id="suggestionBox" class="suggestion-box d-none"></div>
                </div>
            </form>
        </div>
    </div>

    <div id="dataArea">
        <?php if ($report): ?>
            <h3 class="text-center"><?= htmlspecialchars($report['report_title']) ?></h3>
            <p class="text-center"><strong>Date:</strong> <?= htmlspecialchars($report['report_date']) ?></p>

            <?php
            $searchQuery = $search ? "AND customer_name = " . $pdo->quote($search) : "";
            $customers = $pdo->query("SELECT * FROM receivable_customers2 WHERE report_id = {$report['id']} $searchQuery");

            $hasData = false;
            while ($customer = $customers->fetch()) {
                $entries = $pdo->prepare("SELECT * FROM receivable_entries2 WHERE customer_id = ?");
                $entries->execute([$customer['id']]);
                $rows = $entries->fetchAll(PDO::FETCH_ASSOC);
                $entries->closeCursor();

                if (count($rows) > 0) {
                    $hasData = true;
                    ?>
                    <h5 class="mt-4"><?= htmlspecialchars($customer['customer_name']) ?></h5>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped table-sm">
                            <thead class="table-dark">
                                <tr>
                                    <th>Sr</th>
                                    <th>Bill Date</th>
                                    <th>Bill No</th>
                                    <th>Type</th>
                                    <th>Due Days</th>
                                    <th>Bill Amount</th>
                                    <th>Adv. Amount</th>
                                    <th>Adjusted Amount</th>
                                    <th>Pending Amount</th>
                                    <th>Balance Amt. (Cumulative)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sr = 1;
                                foreach ($rows as $row) {
                                    $dueDays = is_numeric($row['due_days']) ? (int)$row['due_days'] : 0;
                                    $rowClass = $dueDays > 90 ? "table-danger" : "";
                                    ?>
                                    <tr class="<?= $rowClass ?>">
                                        <td><?= $sr ?></td>
                                        <td><?= htmlspecialchars($row['bill_date']) ?></td>
                                        <td><?= htmlspecialchars($row['bill_no']) ?></td>
                                        <td><?= htmlspecialchars($row['type']) ?></td>
                                        <td><?= htmlspecialchars($row['due_days']) ?></td>
                                        <td><?= htmlspecialchars($row['bill_amount']) ?></td>
                                        <td><?= htmlspecialchars($row['adv_amount']) ?></td>
                                        <td><?= htmlspecialchars($row['adjusted_amount']) ?></td>
                                        <td><?= htmlspecialchars($row['pending_amount']) ?></td>
                                        <td><?= htmlspecialchars($row['cumulative_balance']) ?></td>
                                    </tr>
                                    <?php
                                    $sr++;
                                }

                                $total = $pdo->prepare("SELECT * FROM receivable_totals2 WHERE customer_id = ?");
                                $total->execute([$customer['id']]);
                                $totalRow = $total->fetch();
                                $total->closeCursor();

                                if ($totalRow) {
                                    ?>
                                    <tr class="fw-bold table-secondary">
                                        <td colspan="4" class="text-end">Total</td>
                                        <td><?= htmlspecialchars($totalRow['due_days']) ?></td>
                                        <td><?= htmlspecialchars($totalRow['bill_amount']) ?></td>
                                        <td><?= htmlspecialchars($totalRow['adv_amount']) ?></td>
                                        <td><?= htmlspecialchars($totalRow['adjusted_amount']) ?></td>
                                        <td><?= htmlspecialchars($totalRow['pending_amount']) ?></td>
                                        <td><?= htmlspecialchars($totalRow['cumulative_balance']) ?></td>
                                    </tr>
                                    <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                    <?php
                }
            }

            if (!$hasData) {
                echo "<div class='alert alert-info text-center mt-4'>No data found for the selected customer.</div>";
            }
            ?>
        <?php else: ?>
            <div class='alert alert-warning text-center mt-4'>No receivable reports available. Please upload a report first.</div>
        <?php endif; ?>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    document.getElementById('customerSearch').addEventListener('input', function() {
        let searchText = this.value;
        if (searchText.length === 0) {
            document.getElementById('suggestionBox').classList.add('d-none');
            return;
        }
        fetch('display_receivable_fetch_customers2.php?search=' + encodeURIComponent(searchText))
            .then(response => response.json())
            .then(data => {
                let suggestionBox = document.getElementById('suggestionBox');
                suggestionBox.innerHTML = '';
                if (data.length > 0) {
                    data.forEach(customer => {
                        let div = document.createElement('div');
                        div.textContent = customer.customer_name;
                        div.addEventListener('click', function() {
                            document.getElementById('customerSearch').value = customer.customer_name;
                            document.getElementById('suggestionBox').classList.add('d-none');
                            window.location.href = '?search=' + encodeURIComponent(customer.customer_name);
                        });
                        suggestionBox.appendChild(div);
                    });
                    suggestionBox.classList.remove('d-none');
                } else {
                    suggestionBox.classList.add('d-none');
                }
            });
    });

    document.addEventListener('click', function(e) {
        if (!e.target.closest('.position-relative')) {
            document.getElementById('suggestionBox').classList.add('d-none');
        }
    });
</script>
</body>
</html>
