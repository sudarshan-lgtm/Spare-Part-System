<?php
session_start();
require '../vendor/autoload.php'; // Include PHPSpreadsheet

if (!isset($_SESSION["id"])) {
    header("Location: member_login.php");
    exit();
}

use PhpOffice\PhpSpreadsheet\IOFactory;

// Database connection
try {
    $pdo = new PDO("mysql:host=127.0.0.1:3306;dbname=u494849712_part", "u494849712_patilnagesh007", "Password@1381");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Function to save customer data to the *new* tables
function saveCustomerData($pdo, $statement_id, $user_name, $from_date, $to_date, $opening_balance, $total_amt, $closing_balance, $transactions) {
    if (empty($user_name) || empty($from_date) || empty($to_date)) {
        echo "Skipping customer due to missing required fields: user_name='$user_name', from_date='$from_date', to_date='$to_date'<br>";
        return;
    }

    // statement_user_name2
    $stmt = $pdo->prepare("INSERT INTO statement_user_name2 (statement_id, user_name, from_date, to_date) VALUES (:statement_id, :user_name, :from_date, :to_date)");
    $stmt->execute([
        ':statement_id' => $statement_id,
        ':user_name' => $user_name,
        ':from_date' => $from_date,
        ':to_date' => $to_date
    ]);
    $stmt->closeCursor();

    // opening_balance2
    $stmt = $pdo->prepare("INSERT INTO opening_balance2 (statement_id, credit_amt, debit_amt, closer_balance) VALUES (:statement_id, :credit_amt, :debit_amt, :closer_balance)");
    $stmt->execute([
        ':statement_id' => $statement_id,
        ':credit_amt' => $opening_balance['credit_amt'] ?? 0.00,
        ':debit_amt' => $opening_balance['debit_amt'] ?? 0.00,
        ':closer_balance' => $opening_balance['closer_balance']
    ]);
    $stmt->closeCursor();

    // statement_total_amt2
    $stmt = $pdo->prepare("INSERT INTO statement_total_amt2 (statement_id, credit_amt, debit_amt) VALUES (:statement_id, :credit_amt, :debit_amt)");
    $stmt->execute([
        ':statement_id' => $statement_id,
        ':credit_amt' => $total_amt['credit_amt'] ?? 0.00,
        ':debit_amt' => $total_amt['debit_amt'] ?? 0.00
    ]);
    $stmt->closeCursor();

    // closing_balance2
    $stmt = $pdo->prepare("INSERT INTO closing_balance2 (statement_id, closing_balance) VALUES (:statement_id, :closing_balance)");
    $stmt->execute([
        ':statement_id' => $statement_id,
        ':closing_balance' => $closing_balance
    ]);
    $stmt->closeCursor();

    // statement_all_data2
    $stmt = $pdo->prepare("INSERT INTO statement_all_data2 (statement_id, date, doc_no, type, particulars, credit, debit, closing_balance) VALUES (:statement_id, :date, :doc_no, :type, :particulars, :credit, :debit, :closing_balance)");
    foreach ($transactions as $transaction) {
        $stmt->execute([
            ':statement_id' => $statement_id,
            ':date' => $transaction['date'],
            ':doc_no' => $transaction['doc_no'],
            ':type' => $transaction['type'],
            ':particulars' => $transaction['particulars'],
            ':credit' => $transaction['credit'],
            ':debit' => $transaction['debit'],
            ':closing_balance' => $transaction['closing_balance']
        ]);
    }
    $stmt->closeCursor();
    echo "Saved data for customer: $user_name<br>";
}

// File upload handling
if (isset($_FILES['file2']) && $_FILES['file2']['error'] == 0) {
    $file = $_FILES['file2']['tmp_name'];
    $fileType = pathinfo($_FILES['file2']['name'], PATHINFO_EXTENSION);


    $allowedExtensions = ['csv'];
    if (!in_array(strtolower($fileType), $allowedExtensions)) {
        echo "<script>alert('Incorrect file format! Please upload a CSV file.'); window.history.back();</script>";
        exit();
    }

        // Load file based on type
    if ($fileType == 'csv') {
        $data = array_map('str_getcsv', file($file));
    } elseif ($fileType == 'xlsx' || $fileType == 'xls') {
        $spreadsheet = IOFactory::load($file);
        $data = $spreadsheet->getActiveSheet()->toArray();
    } else {
        die("Unsupported file format. Please upload a CSV or Excel file.");
    }

    // Debugging: Print raw data to inspect
    echo "<pre>Raw Data:\n";
    print_r($data);
    echo "</pre>";

    $statement_id = "STMT" . time();
    $user_name = null;
    $from_date = null;
    $to_date = null;
    $opening_balance = [];
    $total_amt = [];
    $closing_balance = null;
    $transactions = [];

    foreach ($data as $index => $row) {
        if (!is_array($row) || empty($row)) continue;

        if (strpos($row[0], "Account Statement For") !== false) {
            if ($user_name !== null) {
                saveCustomerData($pdo, $statement_id, $user_name, $from_date, $to_date, $opening_balance, $total_amt, $closing_balance, $transactions);
                $statement_id = "STMT" . time() . rand(100, 999);
            }

            $user_name = $row[0];
            $from_date = null;
            $to_date = null;
            $opening_balance = [];
            $total_amt = [];
            $closing_balance = null;
            $transactions = [];
            continue;
        }

        if (strpos($row[0], "From ") !== false && strpos($row[0], " To ") !== false) {
            $dateParts = explode(" To ", $row[0]);
            $fromDateStr = str_replace("From ", "", $dateParts[0] ?? '');
            $toDateStr = $dateParts[1] ?? '';

            $from_date_obj = DateTime::createFromFormat('d/m/Y', $fromDateStr) ?: DateTime::createFromFormat('d-m-Y', $fromDateStr);
            $to_date_obj = DateTime::createFromFormat('d/m/Y', $toDateStr) ?: DateTime::createFromFormat('d-m-Y', $toDateStr);

            $from_date = $from_date_obj ? $from_date_obj->format('Y-m-d') : null;
            $to_date = $to_date_obj ? $to_date_obj->format('Y-m-d') : null;
            continue;
        }

        if (strpos($row[0], "Opening Balance") !== false) {
            $opening_balance['credit_amt'] = isset($row[5]) ? floatval(str_replace(',', '', $row[5])) : null;
            $opening_balance['debit_amt'] = isset($row[6]) ? floatval(str_replace(',', '', $row[6])) : null;
            $opening_balance['closer_balance'] = $row[7] ?? null;
            continue;
        }

        if (preg_match('/^\d{2}[\/-]\d{2}[\/-]\d{4}$/', $row[0])) {
            $date_obj = DateTime::createFromFormat('d/m/Y', $row[0]) ?: DateTime::createFromFormat('d-m-Y', $row[0]);
            $parsed_date = $date_obj ? $date_obj->format('Y-m-d') : null;

            if ($parsed_date === null) {
                die("Error: Could not parse transaction date '$row[0]' for customer '$user_name'");
            }

            $transactions[] = [
                'date' => $parsed_date,
                'doc_no' => $row[1] ?? null,
                'type' => $row[2] ?? null,
                'particulars' => implode(", ", array_filter([$row[3] ?? '', $row[4] ?? ''])),
                'credit' => isset($row[5]) ? floatval(str_replace(',', '', $row[5])) : null,
                'debit' => isset($row[6]) ? floatval(str_replace(',', '', $row[6])) : null,
                'closing_balance' => $row[7] ?? null
            ];
            continue;
        }

        if (strpos($row[0], "Total") !== false) {
            $total_amt['credit_amt'] = isset($row[5]) ? floatval(str_replace(',', '', $row[5])) : null;
            $total_amt['debit_amt'] = isset($row[6]) ? floatval(str_replace(',', '', $row[6])) : null;
            continue;
        }

        if (strpos($row[0], "Closing Balance") !== false) {
            $closing_balance = $row[7] ?? null;
            continue;
        }
    }

    if ($user_name !== null) {
        saveCustomerData($pdo, $statement_id, $user_name, $from_date, $to_date, $opening_balance, $total_amt, $closing_balance, $transactions);
    }

    ?>
    <script>
        alert("Data imported successfully into new tables!");
        window.location.href = "display_imported_statement2.php";
    </script>
    <?php
} else {
    echo "";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Import Kolhapur Ledger</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<?php include("preloader.html"); ?>
<body class="bg-light">

<div class="container mt-5">
    <div class="card shadow rounded-4 p-4">
        <h3 class="mb-4 text-center">Upload Customer CSV File</h3>
        <form action="import_csv_statement2.php" method="post" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="file2" class="form-label">Choose CSV File</label>
                <input class="form-control" type="file" name="file2" id="file2" accept=".csv" required>
            </div>
            <div class="d-grid gap-2">
                <button type="submit" class="btn btn-primary btn-lg">Upload</button>
            </div>
        </form>
    </div>
</div>
<?php
    include 'display_imported_all_statement2.php';
    ?>
</body>
</html>
