<?php
session_start(); // Start the session
include '../db.php';
if (!isset($_SESSION['id'])) {
    header("Location: member_login.php"); 
    exit();
}

$customer_fullname = "kolhapur_member";
$account_type = "kolhapur_member";
if (isset($_GET['name'])) {
    $customer_fullname = htmlspecialchars($_GET['name']);

    // Fetch account_type from the database based on the fullname
    $query = "SELECT account_type FROM k_member_admission WHERE customer_fullname = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $customer_fullname);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $account_type);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);
}

// Get the logged-in customer's full name and ID
$fullname = "";
$customer_id = "";
if (isset($_SESSION['id'])) {
    $customer_id = $_SESSION['id']; // Store the logged-in customer ID
    $query = "SELECT fullname FROM kolhapur_member WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $customer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $fullname = htmlspecialchars($row['fullname']);
    }
    $stmt->close();
}

$query = "SELECT DISTINCT ProductGroup FROM kolhapurdata";
$result = mysqli_query($conn, $query);

$productGroups = [];
while ($row = mysqli_fetch_assoc($result)) {
    $productGroups[] = htmlspecialchars($row['ProductGroup']);
}

$imageFolderPath = "../admin folders/uploads/folders";
$imageFiles = glob("$imageFolderPath/*.{jpg,jpeg,png,gif,webp}", GLOB_BRACE);

$matchedProducts = [];
foreach ($productGroups as $groupName) {
    foreach ($imageFiles as $imageFile) {
        $imageName = pathinfo($imageFile, PATHINFO_FILENAME); 
        if (strcasecmp($groupName, $imageName) == 0) { 
            $matchedProducts[] = [
                'group' => $groupName,
                'imagePath' => $imageFile
            ];
            break; 
        }
    }
}
mysqli_close($conn); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../kolhapur member/css/product_group.css">
    <title>Product Groups</title>
    <script>
        function searchProductGroup() {
            const input = document.getElementById("searchInput").value;

            // AJAX Request to get suggestions
            fetch(`product_group_fetch_suggestion.php?query=${encodeURIComponent(input)}`)
                .then(response => response.json())
                .then(data => {
                    const suggestions = document.getElementById("suggestions");
                    suggestions.innerHTML = ""; // Clear previous suggestions

                    // Display new suggestions
                    data.forEach(group => {
                        const div = document.createElement("div");
                        div.textContent = group;
                        div.style.cursor = "pointer";
                        div.style.padding = "5px"; // Add padding for better UX
                        div.onclick = () => fetchGroupDetails(group); // Call function on click
                        suggestions.appendChild(div);
                    });
                });
        }
        function fetchGroupDetails(groupName) {
            // Redirect to display details for the selected product group
            const encodedGroupName = encodeURIComponent(groupName); // Ensure proper URL encoding
            const customer_fullname = "<?= $customer_fullname ?>"; // Get the customer_fullname value from PHP
            const account_type = "<?= $account_type ?>";
            window.location.href = `product_group_display.php?group=${encodeURIComponent(groupName)}&name=${encodeURIComponent(customer_fullname)}&account_type=${encodeURIComponent(account_type)}`;

        }
        // Search Part NO JS
        function searchProduct() {
            const partNo = document.getElementById("partNo").value;
            if (!partNo) {
                alert("Please enter a part number to search.");
                return;
            }

            // Redirect to search_partNo.php with the searched part number
            const customer_fullname = "<?= $customer_fullname ?>"; // Get the customer_fullname value from PHP
            const account_type = "<?= $account_type ?>";
            window.location.href = `partNo.php?partNo=${encodeURIComponent(partNo)}&name=${encodeURIComponent(customer_fullname)}&account_type=${encodeURIComponent(account_type)}`;
        }

        //Search All Products in database
        function searchAllProducts() {
            const query = document.getElementById("productSearchInput").value;
            const customer_fullname = "<?= $customer_fullname ?>";
            const account_type = "<?= $account_type ?>";

            if (query.length === 0) {
                document.getElementById("allProductSuggestions").innerHTML = "";
                return;
            }

            const xhr = new XMLHttpRequest();
            xhr.open("GET", `search_all_products.php?query=${encodeURIComponent(query)}&name=${encodeURIComponent(customer_fullname)}&account_type=${encodeURIComponent(account_type)}`, true);
            xhr.onload = function () {
                if (xhr.status === 200) {
                    document.getElementById("allProductSuggestions").innerHTML = xhr.responseText;
                }
            };
            xhr.send();
        }
    </script>
</head>
<body>
    <?php include("preloader.html"); ?>
    <!-- Navigation Bar -->
    <nav class="navbar">
    <a href='member_dashboard.php' class='back-button'><img src="../image/h1.png" class="home" alt="ok"></a>
        <img src="../image/RJ bg.png" class="logo" alt="RJ">
        <?php if ($fullname): ?>
                    <span class="customer"><i class="fa fa-user"></i>
                        <?php echo htmlspecialchars($fullname); ?>
                    </span>
                <?php endif; ?>
        <a href="../kolhapur member/cart_product.php" class="cart-icon" onclick="openCart()"><img src="../image/shopping-cart.png" class="cart" alt="tau"></a>
    </nav>
    <div class="fixed-container">
    <?php if (!empty($customer_fullname)): ?>
        <h2 class="fullname"><?= $customer_fullname ?> (<?= $account_type ?>)!</h2>
    <?php endif; ?>
    <form action="admission.php">
        <button type="submit" class="addCustomer">Add Customer</button>
    </form>
    </div>
    <div class="search-wrapper shadow p-3 position-fixed top-0 w-100 z-3 mt-5 pt-5 mr-5" style="background-color:#E9EAEC;">
        <div class="container-fluid">
            <div class="row g-3 flex-column flex-md-row justify-content-center align-items-start">
    
                <!-- Product Group Search -->
                <div class="col-12 col-md-4">
                    <form onsubmit="return false;">
                        <input type="text" id="searchInput" class="form-control" placeholder="Search Product Group" oninput="searchProductGroup()" required>
                    </form>
                    <div id="suggestions" class="suggestion-box mt-2"></div>
                </div>
    
                <!-- Part No Search with Button -->
                <div class="col-12 col-md-4 d-flex flex-column align-items-stretch">
                    <form onsubmit="return false;" class="d-flex">
                        <input type="text" id="partNo" class="form-control me-2" placeholder="Search Part Number" required>
                        <button onclick="searchProduct()" class="btn btn-primary">Search</button>
                    </form>
                    <div id="partNoSuggestions" class="suggestion-box mt-2"></div>
                </div>
    
                <!-- All Products Search -->
                <div class="col-12 col-md-4">
                    <form onsubmit="return false;">
                        <input type="text" id="productSearchInput" class="form-control" placeholder="Search Product (All Tables)" oninput="searchAllProducts()" required>
                    </form>
                    <div id="allProductSuggestions" class="suggestion-box mt-2"></div>
                </div>
    
            </div>
        </div>
    </div>
    
    <h1>Product Groups</h1>
    <div class="file-container">
        <?php
        foreach ($matchedProducts as $product) {
            $groupName = $product['group'];
            $imagePath = $product['imagePath'];
            ?>
            <div class='card' onclick="fetchGroupDetails('<?= $groupName ?>')" style="cursor:pointer;">
                <img src="<?= $imagePath ?>" alt="<?= $groupName ?>" loading="lazy">
                <h2><?= $groupName ?></h2>
            </div>
        <?php } ?>
    </div>
    <script>
  // Check if the cookie exists
  if (!document.cookie.split('; ').find(row => row.startsWith('visited='))) {
    // Set cookie for 7 days
    document.cookie = "visited=true; max-age=" + 60 * 60 * 24 * 7 + "; path=/";
    console.log("First-time visit: full content loading");
  } else {
    console.log("Returning visitor: use optimized content if needed");
    // तुम्ही इथे placeholder images किंवा low-res images लावू शकता
  }
</script>

</body>
</html>