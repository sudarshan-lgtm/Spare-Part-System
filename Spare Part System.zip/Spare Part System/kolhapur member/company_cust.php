<?php
session_start();
include '../db.php';

if (!isset($_SESSION['id'])) {
    header("Location: member_login.php"); 
    exit();
}

// Get the list of images from the folder
$image_dir = "../admin folders/uploads/folders/";
$images = array_diff(scandir($image_dir), array('.', '..'));

$customer_fullname = "Member";
$account_type = "Member";
if (isset($_GET['name'])) {
    $customer_fullname = htmlspecialchars($_GET['name']);

    // Fetch account_type from the database based on the fullname
    $query = "SELECT account_type FROM k_member_admission WHERE customer_fullname = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $customer_fullname);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $account_type);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);
}

// Fetch company data from the database
$sql = "SELECT DISTINCT company FROM kolhapurdata";
$result = $conn->query($sql);

$cards = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $company_name = strtolower($row['company']); // Convert to lowercase for consistency
        foreach ($images as $image) {
            $image_name = strtolower(pathinfo($image, PATHINFO_FILENAME)); // Get image name without extension
            if ($image_name === $company_name) {
                $cards[] = [
                    'image' => $image_dir . $image,
                    'company' => $row['company']
                ];
                break;
            }
        }
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Companies</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #EEF2FE; /* Light teal */
            text-align: center;
            margin: 0;
            padding: 0;
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            color: white;
            border-radius: 50%;
            text-decoration: none;
            font-size: 22px;
            transition: all 0.3s ease;
            position: fixed; /* Optional: fixed position */
            top: 10px;
            left: 20px;
            z-index: 999;
        }
        .back-button:hover {
            transform: scale(1.1);
            color: #fff;
        }
        .back-button .home {
            height: 55px; 
            width: auto;  
            margin-right: 10px; 
            vertical-align: middle;
            object-fit: contain;
        }
        .fullname-container {
            position: fixed; 
            top: 20px; 
            right: 20px; 
            font-size: 16px; 
            font-weight: bold; 
            padding: 10px 20px; 
            border-radius: 8px; 
            background-color: #f8f9fa;
            display: inline-block;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); 
            text-align: right;
        }
        /* Center the container and ensure proper spacing */
        .cards-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center; /* Centers the cards */
            gap: 20px; /* Spacing between cards */
            max-width: 1200px; /* Restricts the width */
            margin: 0 auto; /* Centers the container */
            padding: 20px;
        }
        /* Card Styling */
        .card {
            width: calc(25% - 20px); /* 4 cards in one row with proper spacing */
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            text-align: center;
            overflow: hidden;
            transition: transform 0.3s ease-in-out;
        }
        .card:hover {
            transform: scale(1.05); /* Slight zoom effect on hover */
        }
        .card img {
            width: 100%;
            height: 180px;
            object-fit: cover;
            border-bottom: 1px solid #ddd;
        }
        .card h3 {
            margin: 10px 0;
            font-size: 18px;
            color: #333;
        }
        .card a {
            text-decoration: none;
            color: #333;
            display: block;
            padding: 10px;
        }
        /* Responsive Design */
        @media (max-width: 1200px) {
            .card {
                width: calc(33.33% - 20px); /* 3 cards per row */
            }
        }
        @media (max-width: 992px) {
            .card {
                width: calc(50% - 20px); /* 2 cards per row */
            }
            .card img {
                height: 160px;
            }
        }
        @media (max-width: 600px) {
            .card {
                width: calc(100% - 40px); /* 1 card per row, with margin */
            }
            .card img {
                height: 150px;
                object-fit: contain;
            }
        }
        @media (max-width: 480px) {
            h1 {
                margin-top: 30% !important;
            }
            .cards-container {
                margin-top:0;
            }
            .fullname-container {
                margin-right: -10px !important;
            }
            .card {
                width :45% !important;
            }
        }
        /* Large Screens */
        @media (min-width: 1400px) {
            .card {
                width: calc(20% - 20px); /* 5 cards in one row */
            }
        }
    </style>
</head>
<body>
    <?php include("preloader.html"); ?>
    <div class='back-button-container'>
    <h1 style="text-align: center;">Companies</h1>
    <a href='member_dashboard.php' class='back-button'><img src="../image/h1.png" class="home" alt="ok"></a>
    </div>
    <?php if (!empty($customer_fullname)): ?>
        <h2 class="fullname-container">Welcome, <?= $customer_fullname ?> (<?= $account_type ?>)!</h2>
    <?php endif; ?>
    <div class="cards-container">
        <?php if (count($cards) > 0): ?>
            <?php foreach ($cards as $card): ?>
                <div class="card">
                <a href="company_product_display.php?company=<?= urlencode($card['company']) ?>&customer_fullname=<?= urlencode($customer_fullname) ?>&account_type=<?= urlencode($account_type) ?>" style="text-decoration:none; color:#333;">
                    <img src="<?= $card['image'] ?>" alt="Company Image" loading="lazy">
                    <h3><?= $card['company'] ?></h3>
                    </a>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No matching companies found.</p>
        <?php endif; ?>
    </div>
    <script>
  // Check if the cookie exists
  if (!document.cookie.split('; ').find(row => row.startsWith('visited='))) {
    // Set cookie for 7 days
    document.cookie = "visited=true; max-age=" + 60 * 60 * 24 * 7 + "; path=/";
    console.log("First-time visit: full content loading");
  } else {
    console.log("Returning visitor: use optimized content if needed");
    // तुम्ही इथे placeholder images किंवा low-res images लावू शकता
  }
</script>

</body>
</html>