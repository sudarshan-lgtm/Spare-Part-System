<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
         body {
            font-family: Arial, sans-serif;
            background-color: #EEF2FE; /* Light teal */
            justify-content: center;
            padding: 20px;
            margin: 0; 
        } 
        .gallery {
            display: flex;
            flex-wrap: wrap;
            justify-content: center; /* Centers items horizontally */
            align-items: center; /* Aligns items in the center */
            gap: 20px;
            width: 100%;
            max-width: 1400px;
            margin: 20px auto; /* Centers the gallery itself */
            margin-top: 75px;
        }

        .card {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            background-color: white;
            padding: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            width: 130px; /* Set a fixed width for proper alignment */
            height: auto;
            text-align: center;                    
        }

        .card .image {
            width: 100%;
            height: 130px;
            border-radius: 8px;
            pointer-events: none; /* Disable mouse interactions */
        }

        .card .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0); /* Transparent overlay */
            z-index: 10; /* Ensures overlay is on top */
        }

        header {
            text-align: center;
            margin: 20px 0;
        }

        /* Disable text/image selection */
        body, img {
            user-select: none;
            -webkit-user-select: none;
            -ms-user-select: none;
            -moz-user-select: none;
        }

        /* Responsive Design */
        @media (min-width: 480px) and (max-width: 768px) { /* Smartphones and smaller tablets */
            .gallery {
                grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); /* Smaller images for narrower screens */
            }

            button {
                width: 20%; /* Larger button width on small devices */
            }
            .card {
                width: 90px; /* Adjust card size for smaller screens */
            }
        }

        @media (min-width: 769px) and (max-width: 1024px) { /* Tablets and smaller laptops */
            .gallery {
                grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); /* Moderate column width */
            }

            button {
                width: 20%;
            }
            .card {
                width: 100%; /* Make cards take full width */
            }
        }

        @media (orientation: landscape) and (max-height: 500px) { /* Landscape mode */
            .gallery {
                grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); /* Adjust for landscape */
            }
        }

        @media (min-width: 1025px) { /* Laptops and desktops */
            .gallery {
                grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); /* Larger columns for desktops */
            }

            button {
                width: 20%;
            }
        }

        @media (max-width: 479px) { /* Extra small screens (phones) */
            .gallery {
                grid-template-columns: 1fr; /* Single column layout */
            }

            button {
                width: 30%;
            }
        }
    </style>
    <script>
        // Disable right-click on the entire page
        document.addEventListener('contextmenu', (event) => event.preventDefault());

        // Prevent screenshot shortcuts
        document.addEventListener('keydown', (event) => {
            if (event.key === "PrintScreen") {
                event.preventDefault();
                alert("Screenshots are disabled.");
            }
            if ((event.ctrlKey && event.key === "s") || (event.metaKey && event.key === "s")) {
                event.preventDefault();
                alert("Saving is disabled.");
            }
            if ((event.ctrlKey && event.key === "p") || (event.metaKey && event.key === "p")) {
                event.preventDefault();
                alert("Printing is disabled.");
            }
        });
    </script>
</head>
<body>
    <?php include("../preloader.html"); ?>
    <div class="gallery">
        <?php
            $directory = "../../admin folders/uploads/folders/";
            $images = array_diff(scandir($directory), array('..', '.')); // Get all files in the uploads folder

            foreach ($images as $image) {
                $imagePath = $directory . $image;
                if (is_file($imagePath)) {
                    echo "<div class='card'>";
                    echo "<img src='$imagePath' alt='$image' class='image'>";
                    echo "<div class='overlay'></div>";
                    echo "</div>";
                }
            }
        ?>
    </div>
</body>
</html>