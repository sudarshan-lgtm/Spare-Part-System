<?php
// ✅ Auto-closing MySQLi wrapper
class AutoClosingMySQLi extends mysqli {
private array $openStatements = [];

public function prepare(string $query): mysqli_stmt|false {
$stmt = parent::prepare($query);
if ($stmt !== false) {
$this->openStatements[] = $stmt;
}
return $stmt;
}

public function stmt_init(): mysqli_stmt|false {
$stmt = parent::stmt_init();
if ($stmt !== false) {
$this->openStatements[] = $stmt;
}
return $stmt;
}

public function closeAllStatements(): void {
foreach ($this->openStatements as $stmt) {
if ($stmt instanceof mysqli_stmt) {
@$stmt->close(); // already closed? Ignore warning
}
}
$this->openStatements = [];
}
}

// ✅ Auto-closing PDO wrapper
class AutoClosingPDO extends PDO {
private array $openStatements = [];

public function prepare(string $query, array $options = []): PDOStatement|false {
$stmt = parent::prepare($query, $options);
if ($stmt !== false) {
$this->openStatements[] = $stmt;
}
return $stmt;
}

public function closeAllStatements(): void {
foreach ($this->openStatements as $stmt) {
if ($stmt instanceof PDOStatement) {
@$stmt->closeCursor();
}
}
$this->openStatements = [];
}
}

// ✅ DB Config
$host = "127.0.0.1";
$port = "3306";
$username = "u494849712_patilnagesh007";
$password = "Password@1381";
$dbname = "u494849712_part";

// ✅ MySQLi Connection (AutoCleanup)
$conn = new AutoClosingMySQLi("$host:$port", $username, $password, $dbname);
if ($conn->connect_error) {
die("MySQLi connection failed: " . $conn->connect_error);
}

// ✅ Optional: PDO connection (if needed)
try {
$pdo = new AutoClosingPDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
]);
} catch (PDOException $e) {
die("PDO connection failed: " . $e->getMessage());
}

// ✅ Automatically clean all open statements on shutdown
register_shutdown_function(function () use ($conn, $pdo) {
if ($conn instanceof AutoClosingMySQLi) {
$conn->closeAllStatements();
}
if ($pdo instanceof AutoClosingPDO) {
$pdo->closeAllStatements();
}
});
?>
