<?php
session_start(); 
include '../db.php';

// Set timezone to India
date_default_timezone_set("Asia/Kolkata");

if (!isset($_SESSION['id'])) {
    header("Location: member_login.php"); 
    exit();
}

$fullname = "";
$customer_id = "";
$customer_fullname = isset($_SESSION['customer_fullname']) ? $_SESSION['customer_fullname'] : "";

if (isset($_SESSION['id'])) {
    $customer_id = $_SESSION['id']; // Store the logged-in customer ID
    $query = "SELECT fullname FROM member WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $customer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $fullname = htmlspecialchars($row['fullname']);
    }
    $stmt->close();
}

if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve product data from POST request
    $customer_fullname = $_POST['customer_fullname'];
    $account_type = $_POST['account_type'];
    $product = $_POST['Product'];
    $batch = $_POST['Batch'];
    $company = $_POST['Company'];
    $partNo = $_POST['PartNo'];
    $purchaseRate = $_POST['PurchaseRate'];
    $gst = $_POST['GST'];
    $exp = !empty($_POST['Exp']) ? $_POST['Exp'] : '2025-12-31'; 
    $margin = $_POST['Margin'];
    $saleRate = isset($_POST['SaleRate']) ? floatval($_POST['SaleRate']) : 0;
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;
    $totalSaleRate = $saleRate * $quantity;
    $closingQty = $_POST['ClosingQty'];
    $location = $_POST['Location'];
    $imagePath = $_POST['imagePath'];
    $imageBasePath = "../../admin folders/";
    $imagePathWithoutBase = str_replace($imageBasePath, '',$imagePath);
    $feedback = isset($_POST['feedback']) ? trim($_POST['feedback']) : ''; // Capture feedback
    
    // Current Date Time in IST
    $currentDateTime = date("Y-m-d H:i:s");

    // Insert data into the database
    $query = "INSERT INTO member_cart (customer_id, customer_fullname, account_type, product, batch, company, partNo, purchaseRate, gst, exp, margin, saleRate,  totalSaleRate, closingQty, location, imagePath, quantity, feedback, created_at) 
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($query);
    if ($stmt) {
        $stmt->bind_param("issssssdidsddssssss", $customer_id, $customer_fullname, $account_type, $product, $batch, $company, $partNo, $purchaseRate, $gst, $exp, $margin, $saleRate,  $totalSaleRate, $closingQty, $location, $imagePath, $quantity, $feedback, $currentDateTime);

        if ($stmt->execute()) {
            echo "<script>alert('Product added to cart successfully');</script>";
            echo "<script> window.location.href='cart_product.php';</script>";
        } else {
            echo "<script>alert('Error inserting data: " . $stmt->error . "');</script>";
        }
        $stmt->close();
    } else {
        echo "<script>alert('Failed to prepare the SQL statement');</script>";
    }
    
}
// Fetch hidden columns for customer/member
$hiddenColumns = [];
$query = "SELECT column_name FROM hiddencolumns WHERE user_id = ? AND user_type = ?";
$stmt = $conn->prepare($query);
$userType = 'member'; // Adjust based on session type (admin, member, etc.)
$stmt->bind_param("is", $customer_id, $userType);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $hiddenColumns[] = $row['column_name'];
}
$stmt->close();

// Fetch hidden columns for customer/member end

$query = "SELECT * FROM member_cart WHERE customer_id = ? ORDER BY created_at DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $customer_id); // Filter cart by customer ID
$stmt->execute();
$result = $stmt->get_result();

$cartProducts = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css'>
    <link rel='stylesheet' href='../member/css/cart_product.css'>
    <title>Cart Details</title>
    <style>
        .header-container {
            position: absolute; 
            top: 10px; 
            right: 20px; 
            display: flex;
            gap: 10px;
            align-items: center; 
            background-color: #fff; 
            padding: 5px 10px; 
            border-radius: 5px; 
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); 

        }
        .header-container h1 {
            margin: 0;
            font-size: 18px;
        }
        .customer {
            font-size: 16px;
            color: #333;
        }
    </style>
</head>
<body>
    <?php include("preloader.html"); ?>
    <h1>Cart Details</h1>
    <?php if (!empty($cartProducts)) { ?>
    <form action="order_product.php" method="post" id="orderForm" onsubmit="return validateSelection()">
        <div class='checkbox-container'>
        <a href='member_dashboard.php' class='back-button'><img src="../image/h1.png" class="home" alt="ok"></a>
            <input type="checkbox" id="select-product" onclick="toggleSelectAll()">
            <label for="select-product">Select All Orders</label>
        </div>
        <div class="cart-container">
            <?php foreach ($cartProducts as $row) { ?>
            <div class="cart-card">
            <div class="cart-details"   id="cart-item-<?= $row['id'] ?>">
            <input type="checkbox" class="product-checkbox" name="product[]" value="<?= $row['id'] ?>">
            <img src="<?= htmlspecialchars($row['imagePath']) ?>" alt="<?= htmlspecialchars($row['product']) ?>">
            <h4> <?= $row['product'] ?></h4>
            <p><strong>Customer:</strong> <?= $fullname ?></p>
            <p><strong>Selected Customer:</strong> <?= htmlspecialchars($row['customer_fullname']) ?></p>
            <p><strong>Account Type:</strong> <?= htmlspecialchars($row['account_type']) ?></p>
            <?php if (!in_array('Company', $hiddenColumns)) { ?>
                <p><strong>Company:</strong> <?= htmlspecialchars($row['company']) ?></p>
            <?php } ?>
            <?php if (!in_array('PartNo', $hiddenColumns)) { ?>
                <p><strong>Part No:</strong> <?= htmlspecialchars($row['partNo']) ?></p>
            <?php } ?>
            <?php if (!in_array('PurchaseRate', $hiddenColumns)) { ?>
                <p><strong>Purchase Rate:</strong> ₹<?= htmlspecialchars($row['purchaseRate']) ?></p>
            <?php } ?>
            <?php if (!in_array('GST', $hiddenColumns)) { ?>
                <p><strong>GST:</strong> <?= htmlspecialchars($row['gst']) ?>%</p>
            <?php } ?>
            <?php if (!in_array('Exp', $hiddenColumns)) { ?>
                <p><strong>Exp:</strong> <?= htmlspecialchars($row['exp']) ?></p>
            <?php } ?>
            <?php if (!in_array('Margin', $hiddenColumns)) { ?>
                <p><strong>Margin:</strong> <?= htmlspecialchars($row['margin']) ?>%</p>
            <?php } ?>
            <?php if (!in_array('SaleRate', $hiddenColumns)) { ?>
                <p><strong>Sale Rate:</strong> ₹<?= htmlspecialchars($row['saleRate']) ?></p>
            <?php } ?>
            <?php if (!in_array('TotalSaleRate', $hiddenColumns)) { ?>
                <p><strong>Total Sale Rate:</strong> ₹<?= htmlspecialchars($row['totalSaleRate']) ?></p>
            <?php } ?>
            <?php if (!in_array('ClosingQty', $hiddenColumns)) { ?>
                <p><strong>Closing Qty:</strong> <?= htmlspecialchars($row['closingQty']) ?></p>
            <?php } ?>
            <?php if (!in_array('Location', $hiddenColumns)) { ?>
                <p><strong>Location:</strong> <?= htmlspecialchars($row['location']) ?></p>
            <?php } ?>
            <p><strong>Quantity Ordered:</strong> <?= htmlspecialchars($row['quantity']) ?></p>   
            <?php if (!in_array('Feedback', $hiddenColumns)) { ?>
                <p><strong style="text-align:left;">Feedback:</strong> <?= !empty($row['feedback']) ? htmlspecialchars($row['feedback']) : "No feedback provided" ?></p>
            <?php } ?>     
        </div>
            <div class="cart-button">
                <button class="delete-btn" data-id="<?= $row['id'] ?>">Remove From Cart</button>
            </div>  
    </div>
    <?php } ?>
</div>
<div class="submit-btn">
        <button type="submit" >Submit All Orders</button>
</div>
</form>
<?php } else { ?>
<h1>No Cart Data Found</h1>
<?php } ?>
<div class="scroll-btn" onclick="toggleScroll()">
    <img id="arrow-img" src="../image/logo/down-arrow.png" alt="scroll-arrow">
</div>
<script>
    function validateSelection() {
        var checkboxes = document.querySelectorAll(".product-checkbox:checked");
        if (checkboxes.length === 0) {
            alert("Please select at least one order before submitting.");
            return false;
        }
        return true;
    }
    function toggleSelectAll() {
        const selectAllCheckbox = document.getElementById('select-product');
        const productCheckboxes = document.querySelectorAll('.product-checkbox');
        productCheckboxes.forEach(checkbox => { 
        checkbox.checked = selectAllCheckbox.checked;
        });
    }
    function submitForm() {
        const selectedCheckboxes = document.querySelectorAll('.product-checkbox:checked');
        if (selectedCheckboxes.length === 0) {
            alert('Select At Least One Product!');
            return false;
        }                    
        document.getElementById('orderForm').submit();
    }
    // Select all delete buttons
    document.addEventListener('DOMContentLoaded', () => {
        // Select all delete buttons
        document.querySelectorAll('.delete-btn').forEach(button => {
            button.addEventListener('click', function (event) {
                event.preventDefault(); // Prevent form submission or page reload
                const id = this.getAttribute('data-id'); // Get product ID
                const cartItem = this.closest('.cart-card'); // Get the closest cart item card
                // Send delete request to the server
                fetch('cart_product_remove.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ id: id }) // Send product ID
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        cartItem.remove(); // Remove the entire cart item card
                        alert('Product removed from cart successfully!');
                    } else {
                        alert('Failed to remove product from cart!');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while removing the product.');
                });
            });
        });
    });
    // Function to toggle scroll up and down
    function toggleScroll() {
        if (window.innerHeight + window.scrollY >= document.body.offsetHeight) {
            // If at bottom, scroll to top
            window.scrollTo({ top: 0, behavior: "smooth" });
        } else {
            // If at top, scroll to bottom
            window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" });
        }
    }
    // Change arrow image on scroll
    window.addEventListener("scroll", function () {
        let arrowImg = document.getElementById("arrow-img");
        if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 10) {
            arrowImg.src = "../image/logo/up-arrow.png"; // Show Up Arrow when at bottom
        } else {
            arrowImg.src = "../image/logo/down-arrow.png"; // Show Down Arrow when at top
        }
    });
</script>
</body>
</html>