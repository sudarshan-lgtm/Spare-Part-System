<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>My Account</title>
    <style>
         /* Global Styles */
         body { 
            font-family: Arial, sans-serif; 
            background-color: #EEF2FE; 
            text-align: center; 
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }
        .card {
            display: flex;
            flex-direction: row;
            align-items: center;
            background-color: #fff;
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            max-width: 550px;
            width: 90%;
            gap: 20px;
        }

        /* QR Image Section */
        .qr-section {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .qr-section img {
            width: 180px;
            height: auto;
            border-radius: 8px;
            border: 1px solid #ccc;
            cursor: pointer;
        }

        /* Text Section */
        .details-section {
            flex: 2;
        }

        .details-section h2 {
            color: #d60000;
            margin-bottom: 20px;
            font-size: 24px;
        }

        .details-section p {
            font-size: 18px;
            margin: 10px 0;
        }

        .label {
            font-weight: bold;
            color: #333;
        }

        /* Popup styles */
        .popup {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.4);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 999;
        }

        .popup-content {
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }

        .popup-content h3 {
            margin-bottom: 20px;
        }

        .popup-content button {
            padding: 10px 20px;
            margin: 10px;
            font-size: 16px;
            border: none;
            background-color: #007bff;
            color: white;
            border-radius: 6px;
            cursor: pointer;
        }

        .popup-content button:hover {
            background-color: #0056b3;
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            color: white;
            border-radius: 50%;
            text-decoration: none;
            font-size: 22px;
            transition: all 0.3s ease;
            position: fixed; /* Optional: fixed position */
            top: 10px;
            left: 20px;
            z-index: 999;
        }
        .back-button:hover {
            transform: scale(1.1);
            color: #fff;
        }
        .back-button .home {
            height: 55px; 
            width: auto;  
            margin-right: 10px; 
            vertical-align: middle;
            object-fit: contain;
        }
        /* Account Container */
        .account-container {
            width: 40%;
            max-width: 400px;
            background: #fff;
            padding: 20px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        h2 {
            font-size: 24px;
            color: #333;
            margin-bottom: 15px;
        }

        table { 
            width: 100%; 
            border-collapse: collapse;
            text-align: left;
        }

        th, td { 
            padding: 12px; 
            border-bottom: 1px solid #ddd; 
            font-size: 16px;
        }

        th { 
            background:rgb(129, 129, 129);
            color: white;
            text-align: left;
            border-radius: 5px;
            width: 20%;
        }

        td { 
            background: #f9f9f9; 
            color: #333;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); 
        }

        /* Edit Button */
        .edit-btn {
            padding: 10px 15px;
            background: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
        }

        .edit-btn:hover { 
            background: rgb(0, 25, 138); 
        }

        .edit-btn i {
            font-size: 18px;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .card {
                flex-direction: column;
                padding: 20px;
                max-width: 90%;
            }

            .qr-section img {
                width: 160px;
                margin-bottom: 20px;
            }

            .details-section h2 {
                font-size: 22px;
                text-align: center;
            }

            .details-section p {
                font-size: 16px;
                text-align: center;
            }
            .account-container {
                width: 90%;
                padding: 15px;
            }
            h2 {
                font-size: 22px;
            }
            th, td {
                padding: 10px;
                font-size: 14px;
            }
            .edit-btn {
                font-size: 14px;
                padding: 8px;
            }
        }

        /* Mobile & Small Devices */
        @media (max-width: 480px) {
            .qr-section img {
                width: 140px;
            }

            .details-section h2 {
                font-size: 20px;
            }

            .details-section p {
                font-size: 15px;
            }

            .popup-content {
                width: 90%;
                padding: 20px;
            }

            .popup-content button {
                width: 100%;
                margin: 10px 0;
            }
            .account-container {
                width: 95%;
                padding: 10px;
            }
            h2 {
                font-size: 20px;
            }
            th, td {
                font-size: 12px;
                padding: 8px;
            }
            .edit-btn {
                font-size: 12px;
                padding: 6px;
            }
        }

        /* Landscape Mode Adjustments for Smartphones & Tablets */
        @media screen and (max-height: 500px) and (orientation: landscape) {
            .account-container {
                max-width: 80%;
            }
        }

        /* Large Screens */
        @media (min-width: 1200px) {
            .account-container {
                max-width: 800px;
            }
        }
    </style>
</head>
<body>
    <?php include("preloader.html"); ?>
<a href='member_dashboard.php' class='back-button'><img src="../image/h1.png" class="home" alt="ok"></a>
<div class="card">
    <div class="qr-section">
      <img src="../image/logo/QR.jpg" alt="QR" id="qr-image">
    </div>
    <div class="details-section">
      <h2>Bank Details</h2>
      <p><span class="label">Account Holder:</span> RJ AUTO HEAVEN</p>
      <p><span class="label">Bank Name:</span> HDFC BANK</p>
      <p><span class="label">A/C No:</span> 50200075320026</p>
      <p><span class="label">IFSC Code:</span> HDFC0007281</p>
      <p><span class="label">Address:</span> MOHOL</p>
    </div>
  </div>
  <!-- Popup -->
  <div class="popup" id="popup">
    <div class="popup-content">
      <h3>Select Payment App</h3>
      <button onclick="window.location.href='upi://pay?pa=patilnagesh007-1@okhdfcbank'">Google Pay</button>
      <button onclick="window.location.href='upi://pay?pa=patilnagesh007-1@okhdfcbank'">PhonePe</button>
      <button onclick="closePopup()">Cancel</button>
    </div>
  </div>

<script>
//Payment JS
    // Show popup on QR click
    document.getElementById('qr-image').addEventListener('click', function () {
    document.getElementById('popup').style.display = 'flex';
    });

    // Close popup
    function closePopup() {
    document.getElementById('popup').style.display = 'none';
    }

    document.addEventListener('contextmenu', e => e.preventDefault());
        document.onkeydown = function(e) {
        if(e.key === "F12" || (e.ctrlKey && e.shiftKey && (e.key === "I" || e.key === "J"))) {
            return false;
        }
    }
</script>
</body>
</html>
