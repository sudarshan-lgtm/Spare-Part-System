<?php
session_start();
include '../db.php';

if (!isset($_SESSION['id'])) {
    header("Location: member_login.php"); 
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $customer_fullname = $_POST["customer_fullname"];
    $mobile = $_POST["mobile"];
    $email = $_POST["email"];
    $location = $_POST["location"];
    $account_type = $_POST["account_type"];

    $sql = "INSERT INTO member_admission (customer_fullname, account_type, mobile, email, location) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $customer_fullname, $account_type, $mobile, $email, $location);

    if ($stmt->execute()) {
        header("Location: admission.php?success=1");
        exit();
    } else {
        echo "Error:" . $stmt->error;
    }
    $stmt->close();
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Admission</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            min-height: 100vh;
            background-color: #f5f5f5;
        }

        .back-button-container {
            position: absolute;
            left: 10px;
            top: 100px;
        }

        .container {
            display: flex;
            flex-direction: column;
            flex: 2;
            gap: 20px;
            max-width: 1200px;
            width: 100%;
            padding: 20px;
        }

        .table-container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
            overflow-x: auto;
            /* Enables horizontal scrolling */
        }

        .add-container {
            width: 40%;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
            margin-left: 30%;
        }

        .add-container input[type="text"],
        .add-container input[type="email"] {
            width: 95%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }

        .input-field input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        .input-field select {
            width: 95%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-top: 10px;
            margin-bottom: 10px;
            font-size: 16px;
            transition: all 0.3s ease;
        }

        .add-container button {
            width: 30%;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            margin-left: 35%;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        .add-container button:hover {
            background-color: #0056b3;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: center;
            min-width: 600px;
            /* Ensures scrolling on small screens */
        }

        table th,
        table td {
            padding: 10px;
            border: 1px solid #ddd;
        }

        table th {
            background-color: rgb(124, 124, 124);
            color: white;
        }

        table tr:hover {
            background-color: #f1f1f1;
        }

        h2 {
            text-align: center;
        }

        table td a {
            padding: 7px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .delete-btn {
            padding: 7px;
            width: 80%;
            border: none;
            border-radius: 5px;
            background-color: rgb(255, 41, 41);
        }

        .delete-btn:hover {
            background-color: rgb(204, 0, 0);
        }

        /* Responsive Design */
        @media screen and (max-width: 1024px) {
            .container {
                padding: 15px;
            }

            .add-container {
                width: 60%;
                margin-left: 20%;
            }
        }

        @media screen and (max-width: 768px) {
            .container {
                padding: 10px;
            }

            .add-container {
                width: 80%;
                margin-left: 10%;
            }

            table th,
            table td {
                padding: 8px;
            }
        }

        @media screen and (max-width: 600px) {
            body {
                flex-direction: column;
                align-items: center;
            }

            .back-button-container {
                position: relative;
                text-align: center;
                margin: 10px 0;
                top: 0;
                left: -35%;
            }

            .container {
                width: 100%;
                padding: 5px;
            }

            .table-container {
                width: 100%;
                overflow-x: auto;
                /* Enables scrolling on mobile */
            }

            .add-container {
                width: 90%;
                margin-left: 5%;
            }

            .add-container button {
                width: 50%;
                margin-left: 25%;
            }

            table th,
            table td {
                padding: 5px;
                font-size: 12px;
            }
        }

        /* Landscape mode for smartphones & tablets */
        @media screen and (max-width: 812px) and (orientation: landscape) {
            .container {
                padding: 10px;
            }

            .add-container {
                width: 60%;
                margin-left: 20%;
            }

            table th,
            table td {
                padding: 7px;
            }
        }
    </style>
</head>

<body>
    <?php include("preloader.html"); ?>
    <div class="container">
        <!-- Admission Form -->
        <div class="add-container">
            <form action="admission.php" method="POST">
                <h2>Admission Form</h2>
                <input type="text" placeholder="Full name" name="customer_fullname" required oninput="validateLetters(this)" maxlength="40"><br>
                <input type="text" placeholder="Mobile number" name="mobile" required oninput="validateNumbers(this)" maxlength="10"><br>
                <input type="email" placeholder="Email" name="email" required><br>
                <input type="text" placeholder="Location" name="location" required pattern="[A-Za-z0-9@#$%^&*()_+!]+" minlength="4" maxlength="50"><br>
                <div class="input-field">
                    <select name="account_type" required>
                        <option value="">Select Account Type</option>
                        <option value="Member">Member</option>
                        <option value="Customer">Customer</option>
                    </select>
                </div>
                <button type="submit">Submit</button>
            </form>
        </div>

        <!-- Admission Table -->
        <div class="table-container">
            <h2>Admission List</h2>
            <?php
            $sql = "SELECT * FROM member_admission";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo "<table>";
                echo "<tr>
                        <th>ID</th>
                        <th>Full Name</th>
                        <th>Mobile</th>
                        <th>Email</th>
                        <th>Location</th>
                        <th>Delete</th>
                      </tr>";
                while ($row = $result->fetch_assoc()) {
                    $PartNo = $_GET["PartNo"];
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td><a href='partNo.php?partNo=$PartNo&name=" . urlencode($row['customer_fullname']) . "&account_type=" . urlencode($row['account_type']) . "'>
                                {$row['customer_fullname']}
                            </a></td>
                            <td>{$row['mobile']}</td>
                            <td>{$row['email']}</td>
                            <td>{$row['location']}</td>
                            <td><button type='submit' class='delete-btn' data-id='" . $row['id'] . "'> 
                                <i class='fas fa-trash'></i> Delete
                            </button></td>
                        </tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No admissions found.</p>";
            }
            ?>
        </div>
    </div>
    <script>
        // Function to allow only letters
        function validateLetters(input) {
            input.value = input.value.replace(/[^a-zA-Z\s]/g, '');
        }
        // Function to allow only numbers
        function validateNumbers(input) {
            input.value = input.value.replace(/[^0-9]/g, '').substring(0, 10);
        }

        document.addEventListener("DOMContentLoaded", function() {
            const deleteButtons = document.querySelectorAll(".delete-btn");
            deleteButtons.forEach(button => {
                button.addEventListener("click", function() {
                    const id = this.getAttribute("data-id");
                    if (confirm("Are you sure you want to delete this admission?")) {
                        fetch("admission_delete.php", {
                                method: "POST",
                                headers: {
                                    "Content-Type": "application/x-www-form-urlencoded"
                                },
                                body: "id=" + id
                            })
                            .then(response => response.text())
                            .then(data => {
                                if (data === "success") {
                                    document.getElementById("row-" + id).remove();
                                } else {
                                    alert("Error deleting record.");
                                }
                            })
                            .catch(error => console.error("Error:", error));
                    }
                });
            });
        });
    </script>
</body>

</html>