<?php
session_start();
require '../../db.php';

if (!isset($_SESSION['id'])) {
    header("Location: member_login.php"); 
    exit();
}

$customer_id = $_SESSION['id'];
$query = "SELECT username, fullname, email, mobile, dob FROM member WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $customer_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "<p style='text-align:center; color:red;'>User not found.</p>";
    exit;
}

$row = $result->fetch_assoc();
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>My Account</title>
    <style>
         /* Global Styles */
         body { 
            font-family: Arial, sans-serif; 
            background-color: #EEF2FE; /* Light teal */
            text-align: center; 
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            color: white;
            border-radius: 50%;
            text-decoration: none;
            font-size: 22px;
            transition: all 0.3s ease;
            position: fixed; /* Optional: fixed position */
            top: 10px;
            left: 20px;
            z-index: 999;
        }
        .back-button:hover {
            transform: scale(1.1);
            color: #fff;
        }
        .back-button .home {
            height: 55px; 
            width: auto;  
            margin-right: 10px; 
            vertical-align: middle;
            object-fit: contain;
        }
        /* Account Container */
        .account-container {
            width: 40%;
            max-width: 400px;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        h2 {
            font-size: 24px;
            color: #333;
            margin-bottom: 15px;
        }

        table { 
            width: 100%; 
            border-collapse: collapse;
            text-align: left;
        }

        th, td { 
            padding: 12px; 
            border-bottom: 1px solid #ddd; 
            font-size: 16px;
        }

        th { 
            background:rgb(129, 129, 129);
            color: white;
            text-align: left;
            border-radius: 5px;
            width: 20%;
        }

        td { 
            background: #f9f9f9; 
            color: #333;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); 
        }

        /* Edit Button */
        .edit-btn {
            padding: 10px 15px;
            background: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
        }

        .edit-btn:hover { 
            background: rgb(0, 25, 138); 
        }

        .edit-btn i {
            font-size: 18px;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .card {
                flex-direction: column;
                padding: 20px;
                max-width: 90%;
            }

            .qr-section img {
                width: 160px;
                margin-bottom: 20px;
            }

            .details-section h2 {
                font-size: 22px;
                text-align: center;
            }

            .details-section p {
                font-size: 16px;
                text-align: center;
            }
            .account-container {
                width: 90%;
                padding: 15px;
            }
            h2 {
                font-size: 22px;
            }
            th, td {
                padding: 10px;
                font-size: 14px;
            }
            .edit-btn {
                font-size: 14px;
                padding: 8px;
            }
        }

        /* Mobile & Small Devices */
        @media (max-width: 480px) {
            .qr-section img {
                width: 140px;
            }

            .details-section h2 {
                font-size: 20px;
            }

            .details-section p {
                font-size: 15px;
            }

            .popup-content {
                width: 90%;
                padding: 20px;
            }

            .popup-content button {
                width: 100%;
                margin: 10px 0;
            }
            .account-container {
                width: 95%;
                padding: 10px;
            }
            h2 {
                font-size: 20px;
            }
            th, td {
                font-size: 12px;
                padding: 8px;
            }
            .edit-btn {
                font-size: 12px;
                padding: 6px;
            }
        }

        /* Landscape Mode Adjustments for Smartphones & Tablets */
        @media screen and (max-height: 500px) and (orientation: landscape) {
            .account-container {
                max-width: 80%;
            }
        }

        /* Large Screens */
        @media (min-width: 1200px) {
            .account-container {
                max-width: 800px;
            }
        }
    </style>
</head>
<body>
    <?php include("../preloader.html"); ?>
<a href='../member_dashboard.php' class='back-button'><img src="../../image/h1.png" class="home" alt="ok"></a>
<h2>My Account</h2>
<div class="account-container">
    <table>
        <tr><th>Username</th><td><?= htmlspecialchars($row['username']); ?></td></tr>
        <tr><th>Full Name</th><td><?= htmlspecialchars($row['fullname']); ?></td></tr>
        <tr><th>Email</th><td><?= htmlspecialchars($row['email']); ?></td></tr>
        <tr><th>Mobile</th><td><?= htmlspecialchars($row['mobile']); ?></td></tr>
        <tr><th>Date of Birth</th><td><?= htmlspecialchars($row['dob']); ?></td></tr>
        <tr><th>Edit</th><td><a href="account_edit.php"><button class="edit-btn"><i class="fa-solid fa-pen-to-square"></i> Edit</button></a></td></tr>
    </table>
</div>
</body>
</html>