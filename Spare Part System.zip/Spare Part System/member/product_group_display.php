<?php
    session_start(); 
    include '../db.php'; 

    if (!isset($_SESSION['id'])) {
        header("Location: member_login.php"); 
        exit();
    }

    // Initialize cart count
    $cart_count = 0;

    // Fetch cart count from database
    $result = $conn->query("SELECT COUNT(*) as count FROM member_cart");
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $cart_count = $row['count'];
    }

    $fullname = "";
    $customer_id = "";
    if (isset($_SESSION['id'])) {
        $customer_id = $_SESSION['id']; // Get the logged-in customer ID
        $query = "SELECT fullname FROM member WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $customer_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $fullname = htmlspecialchars($row['fullname']);
        }
        $stmt->close();
    }

    $customer_fullname = isset($_GET['name']) ? htmlspecialchars($_GET['name']) : '';
    $account_type = isset($_GET['account_type']) ? htmlspecialchars($_GET['account_type']) : "";
    $customer_id = isset($_SESSION['id']) ? $_SESSION['id'] : '';

    // Fetch hidden columns for customer/member
    $hiddenColumns = [];
    $query = "SELECT column_name FROM hiddencolumns WHERE user_id = ? AND user_type = ?";
    $stmt = $conn->prepare($query);
    $userType = 'member'; // Adjust based on session type (admin, member, etc.)
    $stmt->bind_param("is", $customer_id, $userType);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $hiddenColumns[] = $row['column_name'];
    }
    $stmt->close();
    // Fetch products with offers
    $products = [];
    if (isset($_GET['single_product'])) {
        // Show only the selected product
        $productName = trim($_GET['single_product']);
        $query = "SELECT p.*, COALESCE(o.Discount, 0) AS Discount, COALESCE(o.module, '') AS module
                  FROM productinventory p
                  LEFT JOIN offers o ON p.Product = o.Product AND o.module = 'Member'
                  WHERE p.Product = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $productName);
    } else {
        // Show entire product group
        $groupName = isset($_GET['group']) ? trim($_GET['group']) : '';
        if (empty($groupName)) {
            echo "<h1>No Product Group Provided</h1>";
            exit;
        }

        $query = "SELECT p.*, COALESCE(o.Discount, 0) AS Discount, COALESCE(o.module, '') AS module
                  FROM productinventory p
                  LEFT JOIN offers o ON p.Product = o.Product AND o.module = 'Member'
                  WHERE p.ProductGroup = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $groupName);
    }

    $stmt->execute();
    $result = $stmt->get_result();

    // Filter valid images
    while ($row = $result->fetch_assoc()) {
        $imagePath = "../admin folders/" . $row['imagePath'];
        
        // Assign image path if the image exists, else assign default placeholder
        if (!empty($row['imagePath']) && file_exists($imagePath)) {
            $row['imagePath'] = $imagePath;
        } else {
            $row['imagePath'] = '../assets/images/no-image.png'; // Set your own placeholder image here
        }

        $products[] = $row;
    }
    $stmt->close();

    if (isset($groupName) && !empty($groupName)) {
        echo "<h1 style='margin-top: 130px;'>Search Results for Product Group: $groupName</h1>";
    } elseif (isset($_GET['product']) && !empty($_GET['product'])) {
        $productName = htmlspecialchars($_GET['product']);
        echo "<h1 class='single-product-title'>Search Results for Product: $productName</h1>";
    }
    echo "<div class='file-container' style='display: flex; flex-wrap: wrap; gap: 20px;'>";

    if (!empty($products)) {
        // If single_product is set, center the single card
        $isSingleProduct = isset($_GET['single_product']) && count($products) === 1;
    
        if ($isSingleProduct) {
            echo "<div style='display: flex; justify-content: center; align-items: center; height: 100vh;'>";
        } else {
            echo "<div class='file-container' style='display: flex; flex-wrap: wrap; gap: 20px;'>";
        }
        foreach ($products as $index => $product) {
            echo "<div class='card' style='border: 1px solid #ccc; padding: 20px; width: 300px; text-align: center;'>
            <div class='image-container' style='position: relative; display: inline-block;'>
                <img src='{$product['imagePath']}' alt='{$product['Product']}' loading='lazy' style='width: 100%; height: auto;' class='product-image' onclick='openImagePopup($index, \"{$product['imagePath']}\", \"{$product['Product']}\")'>";
                if (!empty($product['Discount'])) {
                    echo "<div class='offer-popup'>{$product['Discount']}% Off</div>";
                }
                echo "</div>
                <h4>{$product['Product']}</h4>";
                // Conditionally show/hide columns based on selected hidden columns
                if (!in_array('Batch', $hiddenColumns) && isset($product['Batch'])) {
                    echo "<p><strong>Batch:</strong> {$product['Batch']}</p>";
                }
                if (!in_array('Company', $hiddenColumns) && isset($product['Company'])) {
                    echo "<p><strong>Company:</strong> {$product['Company']}</p>";
                }
                if (!in_array('PartNo', $hiddenColumns) && isset($product['PartNo'])) {
                    echo "<p><strong>Part No:</strong> {$product['PartNo']}</p>";
                }
                if (!in_array('GST', $hiddenColumns) && isset($product['GST'])) {
                    echo "<p><strong>GST:</strong> {$product['GST']}%</p>";
                }
                if (!in_array('Exp', $hiddenColumns) && isset($product['Exp'])) {
                    echo "<p><strong>Exp:</strong> {$product['Exp']}</p>";
                }
                if (!in_array('Margin', $hiddenColumns) && isset($product['Margin'])) {
                    echo "<p><strong>Margin:</strong> {$product['Margin']}%</p>";
                }
                if (!in_array('SaleRate', $hiddenColumns) && isset($product['SaleRate'])) {
                    echo "<p><strong>Sale Rate:</strong> ₹{$product['SaleRate']}</p>";
                }
                if (!in_array('PurchaseRate', $hiddenColumns) && isset($product['PurchaseRate'])) {
                    echo "<p><strong>Purchase Rate:</strong> ₹{$product['PurchaseRate']}</p>";
                }
                if (!in_array('ReceiptQty', $hiddenColumns) && isset($product['ReceiptQty'])) {
                    echo "<p><strong>Receipt Qty:</strong> {$product['ReceiptQty']}</p>";
                }
                if (!in_array('IssueQty', $hiddenColumns) && isset($product['IssueQty'])) {
                    echo "<p><strong>Issue Qty:</strong> {$product['IssueQty']}</p>";
                }
                if (!in_array('ClosingQty', $hiddenColumns) && isset($product['ClosingQty'])) {
                    echo "<p><strong>Closing Qty:</strong> {$product['ClosingQty']}</p>";
                }
                if (!in_array('Location', $hiddenColumns) && isset($product['Location'])) {
                    echo "<p><strong>Location:</strong> {$product['Location']}</p>";
                }
                
                echo "<form id='addToCartForm-{$product['PartNo']}' onsubmit='addToCart(event, this)'>
                    <input type='hidden' name='Product' value='{$product['Product']}'>
                    <input type='hidden' name='customer_id' value='<?php echo $customer_id; ?>'>
                    <input type='hidden' name='Customer' value='$fullname'> 
                    <input type='hidden' name='customer_fullname' value='$customer_fullname'>
                    <input type='hidden' name='account_type' value='$account_type'>
                    <input type='hidden' name='Batch' value='{$product['Batch']}'>
                    <input type='hidden' name='Company' value='{$product['Company']}'>
                    <input type='hidden' name='PartNo' value='{$product['PartNo']}'>
                    <input type='hidden' name='GST' value='{$product['GST']}'>
                    <input type='hidden' name='Exp' value='{$product['Exp']}'>
                    <input type='hidden' name='Margin' value='{$product['Margin']}'>
                    <input type='hidden' name='SaleRate' value='{$product['SaleRate']}'>
                    <input type='hidden' name='PurchaseRate' value='{$product['PurchaseRate']}'>
                    <input type='hidden' name='ReceiptQty' value='{$product['ReceiptQty']}'>
                    <input type='hidden' name='IssueQty' value='{$product['IssueQty']}'>
                    <input type='hidden' name='ClosingQty' value='{$product['ClosingQty']}'>
                    <input type='hidden' name='Location' value='{$product['Location']}'>
                    <input type='hidden' name='imagePath' value='{$product['imagePath']}'>
                    <!-- Textarea for Additional Notes -->
                    <textarea name='feedback' class='feedbackText' placeholder='Enter Feedback Here' rows='10'></textarea>
                    <div style='display: flex; justify-content: center; align-items: center; gap: 10px;'>
                        <button type='button' class='quantity-btn minus' onclick='updateQuantity(this, -1)'>-</button>
                        <input type='number' name='quantity' value='1' min='1' style='width: 50px; text-align: center;' id='quantity-{$product['PartNo']}'>
                        <button type='button' class='quantity-btn plus' onclick='updateQuantity(this, 1)' >+</button>
                    </div>
                    <button type='submit' class='add-to-cart-btn'>Add To Cart</button>
                </form>
            </div>";
        }
    } else {
        echo "<p>No products found for the selected group or no images available.</p>";
    }
    echo "</div>";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!--<link rel="stylesheet" href="../member/css/display_product_group.css">-->
    <title>Display Products</title>
    <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #EEF2FE;
            padding: 20px;
        }
        /* Navigation Bar Start*/
        .navbar {
            position: fixed; 
            top: 0;          
            left: 0;         
            width: 100%; 
            height: 60px !important; 
            background-color: #fff;
            border-radius: 2px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.6);
            display: flex;   
            align-items: center;
            justify-content: space-between;
            padding: 10px 20px; 
            z-index: 1000; 
            backdrop-filter: blur(9px);
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            color: white;
            border-radius: 50%;
            text-decoration: none;
            font-size: 22px;
            transition: all 0.3s ease;
            position: fixed;
            top: 10px;
            left: 20px;
            z-index: 999;
        }
        .back-button:hover {
            transform: scale(1.1);
            color: #fff;
        }
        .back-button .home {
            height: 55px; 
            width: auto;  
            margin-right: 10px; 
            vertical-align: middle;
            object-fit: contain;
        }
        .navbar .logo {
            height: 45px; 
            object-fit: contain;
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            filter: drop-shadow(2px 2px 5px rgba(0,0,0,0.4));
        }
        .customer {
            position: absolute;
            right: 60px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 14px;
            font-weight: bold;
            color: #333;
            white-space: nowrap;
        }
        .navbar .cart-icon {
            font-size: 24px;
            color: #333;
            text-decoration: none;
            cursor: pointer;
            transition: transform 0.3s ease, color 0.3s ease;
            position: absolute;
            right: 20px; 
        }
        .cart {
            width: 40px;
            height: 40px;
            object-fit: contain;
            transition: transform 0.1s ease, box-shadow 0.3s ease;
            margin-left: 10px;
            transform: perspective(200px) rotateY(5deg);
        }
        .cart:hover {
            transform: perspective(200px) rotateY(0deg) scale(1.05);
        }
        /* Calculator Model Open */
        .calculator {
            height: 35px; 
            object-fit: contain;
            position: absolute;
            left: 70%;
            top: 20%;
        }
        .popup {
            display: none;
            position: fixed;
            left: 50%;
            top: 60%;
            transform: translate(-50%, -50%);
            width: 320px;
            padding: 20px;
            background: rgba(0, 0, 0, 0.736);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
            text-align: center;
            animation: fadeIn 0.3s ease-in-out;
        }
        .display {
            width: 100%;
            height: 60px;
            font-size: 2em;
            text-align: right;
            border: none;
            outline: none;
            background: rgba(255, 255, 255, 0.2);
            color: #fff;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 10px;
        }
        .buttons {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
        }
        .buttons button {
            width: 100%;
            height: 60px;
            font-size: 1.5em;
            border: none;
            outline: none;
            border-radius: 8px;
            background: rgba(255, 255, 255, 0.3);
            color: #fff;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
            cursor: pointer;
            transition: all 0.2s ease-in-out;
        }
        .buttons button:hover {
            background: rgba(255, 255, 255, 0.5);
            transform: scale(1.05);
        }
        .equal {
            grid-column: span 2;
            background: #34d399;
        }
        .equal:hover {
            background: #2ab77d;
        }
        .clear {
            background: #ef4444;
        }
        .clear:hover {
            background: #d32f2f;
        }
        /* Fade-in animation */
        @keyframes fadeIn {
            from { opacity: 0; transform: translate(-50%, -45%); }
            to { opacity: 1; transform: translate(-50%, -50%); }
        }
        /* Image Popup Styling */
        .image-popup {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 1001;
            justify-content: center;
            align-items: center;
            animation: fadeIn 0.3s ease-in-out;
        }
        .image-popup-content {
            position: relative;
            max-width: 90%;
            max-height: 90%;
            background: #fff;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            animation: zoomIn 0.3s ease-in-out;
        }
        .popup-image-container {
            text-align: center;
        }
        #popupImage {
            max-width: 100%;
            max-height: 60vh;
            border-radius: 10px;
            object-fit: contain;
        }
        #popupProductName {
            margin-top: 15px;
            font-size: 1.5rem;
            color: #333;
            font-weight: bold;
        }
        .image-close-btn {
            position: absolute;
            top: -15px;
            right: -15px;
            background: #ff4444;
            color: white;
            font-size: 1.5rem;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        .image-close-btn:hover {
            background: #cc0000;
        }
        .nav-btn {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: #007bff;
            color: white;
            font-size: 1.5rem;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: none;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.3s ease;
        }
        .nav-btn:hover {
            background: #0056b3;
            transform: scale(1.1);
        }
        .prev-btn {
            left: -50px;
        }
        .next-btn {
            right: -50px;
        }
        @keyframes zoomIn {
            from { transform: scale(0.8); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }
        /* Cart Styling */
        .cart-number {
            position: absolute;
            top: -6px;
            right: -17px;
            color: red;
            font-size: 20px;
            font-weight: bold;
            font-family: Arial, sans-serif;
            transition: all 0.3s ease-in-out;
        }
        .cart-badge.updated {
            animation: pop 0.3s ease-in-out;
        }
        @keyframes pop {
            0% { transform: scale(1); }
            50% { transform: scale(1.3); }
            100% { transform: scale(1); }
        }
        .header-container {
            position: absolute; 
            top: 85px; 
            right: 20px; 
            display: flex; 
            gap: 10px; 
            align-items: center; 
            padding: 5px 10px; 
            border-radius: 5px;
            margin-top: 70px; 
        }
        .header-container h1 {
            margin: 0;
            font-size: 18px;
        }
        /* Search Bar Styling */
        .search-container {
            position: fixed;
            top: 0;
            left: 0;
            background-color: #E9EAEC;
            box-shadow: none;
            width: 100%;
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 999;
        }
        .searchInput {
            padding: 10px;
            font-size: 14px;
            width: 250px;
            border: 1px solid #ccc;
            border-radius: 5px;
            outline: none;
        }
        .searchButton {
            padding: 10px 15px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-left: 10px;
            transition: background-color 0.3s;
        }
        .searchButton:hover {
            background-color: #0056b3;
        }
        .feedbackText {
            width: 100%;
            height: 50px;
            font-size: 14px;
            margin-top: 5px;
            margin-bottom: 7px;
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
            margin-top: 65px;
        }
        .single-product-title {
            margin-top: 250px !important;
            font-size: 24px;
            font-weight: bold;
            text-align: center;
            color: #444;
        }
        .file-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 2fr));
            gap: 20px;
            padding: 20px;
        }
        .card {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            width: 100%;
            max-width: 290px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
            overflow: hidden;
            align-items: center;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .product-image {
            width: 100%;
            height: auto;
            border-radius: 10px;
            cursor: pointer;
        }
        .offer-popup {
            position: absolute;
            top: 5px;
            right: 6px;
            background: red;
            color: white;
            font-size: 13px;
            font-weight: bold;
            padding: 10px;
            border-radius: 50%;
            text-align: center;
            width: 50px;
            height: 50px;
            display: flex;
            justify-content: center;
            align-items: center;
            opacity: 1;
            animation: zoomEffect 1.5s ease-in-out infinite alternate;
        }
        @keyframes zoomEffect {
            0% { transform: scale(1); }
            100% { transform: scale(1.3); }
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
        }
        .card img {
            width: 100%;
            height: 250px !important;
            object-fit: cover;
        }
        .card h3 {
            font-size: 1.1rem;
            color: #333;
            margin: 10px 0;
        }
        .card p {
            margin: 0;
            font-size: 16px;
            color: #555;
            word-wrap: break-word;
            text-align: left;
            margin-left: 10px;
        }
        .add-to-cart-btn {
            background-color: #FF9800;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            margin-top: 10px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
        .add-to-cart-btn:hover {
            background-color: #FB8C00;
            transform: scale(1.05);
        }
        .add-to-cart-btn:active {
            background-color: #F57C00;
            transform: scale(0.98);
        }
        .quantity-btn {
            border: none;
            border-radius: 5px;
            color: white;
            padding: 10px 15px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
        .minus {
            background-color: #03A9F4;
        }
        .minus:hover {
            background-color: #0288D1;
        }
        .plus {
            background-color: #4CAF50;
        }
        .plus:hover {
            background-color: #388E3C;
        }
        
        @media (max-width: 600px) {
            .navbar {
                height: 50px;
                padding: 5px 10px;
            }
            .navbar .logo {
                height: 35px !important;
            }
            .calculator {
                margin-left: -56% !important;
            }
            .customer {
                display: none;
                font-size: 12px;
                right: 40px;
            }
            .navbar .cart-icon {
                font-size: 17px;
                right: 18px;
            }
            .back-button {
                font-size: 10px;
                margin-left: -15px;
            }
            .file-container {
                justify-content: center;
                grid-template-columns: repeat(1, 1fr);
                gap: 10px;
            }
            .card {
                width: 90%;
                margin: 0 auto;
            }
            .popup { 
                width: 300px; 
            }
            .display { 
                height: 50px; 
                font-size: 1.8em; 
            }
            .buttons button { 
                height: 50px; 
                font-size: 1.3em; 
            }
            .image-popup-content {
                max-width: 95%;
                padding: 10px;
            }
            .nav-btn {
                width: 30px;
                height: 30px;
                font-size: 1rem;
            }
            .prev-btn {
                left: -40px;
            }
            .next-btn {
                right: -40px;
            }
        }
        /* Mobile - 600px or less */
        @media (max-width: 600px) {
            .navbar {
                height: 50px;
                padding: 5px 10px;
            }
            .navbar .logo {
                height: 35px !important;
            }
            .calculator {
                margin-left: -56% !important;
            }
            .customer {
                display: none;
                font-size: 12px;
                right: 40px;
            }
            .navbar .cart-icon {
                font-size: 17px;
                right: 18px;
            }
            .back-button {
                font-size: 10px;
                margin-left: -15px;
            }
            .file-container {
                justify-content: center;
                grid-template-columns: repeat(1, 1fr);
                gap: 10px;
            }
            .card {
                width: 90%;
                margin: 0 auto;
            }
            .popup { 
                width: 300px; 
            }
            .display { 
                height: 50px; 
                font-size: 1.8em; 
            }
            .buttons button { 
                height: 50px; 
                font-size: 1.3em; 
            }
            .image-popup-content {
                max-width: 95%;
                padding: 10px;
            }
            .nav-btn {
                width: 30px;
                height: 30px;
                font-size: 1rem;
            }
            .prev-btn {
                left: -40px;
            }
            .next-btn {
                right: -40px;
            }
        }
        /* Tablets - 768px */
        @media (max-width: 768px) {
            .navbar {
                height: 55px;
                padding: 8px 15px;
            }
            .navbar .logo {
                height: 30px;
            }
            .customer {
                display: none;
                font-size: 13px;
                right: 55px;
            }
            .navbar .cart-icon {
                font-size: 20px;
                right: 17px;
            }
            .back-button {
                font-size: 11px;
                margin-left: -15px;
            }
            .file-container {
                grid-template-columns: repeat(4, 1fr);
            }
            
            .popup { 
                width: 320px; 
            }
            .buttons button { 
                height: 55px; 
                font-size: 1.4em; 
            }
        }
        /* Laptops - 1024px */
        @media (max-width: 1024px) {
            .navbar {
                height: 60px;
                padding: 10px 20px;
            }
            .file-container {
                grid-template-columns: repeat(4, 1fr);
            }
            .customer {
                font-size: 14px;
                right: 60px;
            }
            .popup { 
                width: 350px; 
            }
            .buttons button { 
                height: 60px; 
                font-size: 1.5em; 
            }  
        }
        /* Desktops - 1025px */
        @media (min-width: 1025px) {
            .file-container {
                grid-template-columns: repeat(5, 1fr);
            }
            .popup { 
                width: 400px; 
            }
            .buttons button { 
                height: 65px; 
                font-size: 1.6em; 
            }
        }
        /* Large Screens - 1600px */
        @media (min-width: 1600px) {
            .file-container {
                grid-template-columns: repeat(6, 1fr);
            }
            .card {
                width: 80%;
                max-width: 300px;
            }
            h1 {
                font-size: 2em;
            }
        }
        /* Landscape Mode for Smartphones & Tablets */
        @media (max-width: 850px) and (orientation: landscape) {
            .navbar {
                height: 50px;
                padding: 5px 15px;
            }
            .navbar .logo {
                height: 30px;
            }
            .customer {
                font-size: 12px;
                right: 50px;
            }
            .navbar .cart-icon {
                font-size: 20px;
                right: 10px;
            }
            .file-container {
                grid-template-columns: repeat(3, 1fr);
            }
            .popup {
                width: 70%;
                height: auto;
            }
            .buttons {
                grid-template-columns: repeat(4, 1fr);
                gap: 8px;
            }
            .buttons button {
                height: 40px;
                font-size: 1.2em;
            }
            .image-popup-content {
                max-width: 80%;
            }
        }
    </style>
</head>
<body>
    <?php include("preloader.html"); ?>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <a href='member_dashboard.php' class='back-button'><img src="../image/h1.png" class="home" alt="ok"></a>
        <img src="../image/RJ bg.png" class="logo" alt="RJ">
        <a href="#" onclick="toggleCalculator()">
            <img src="../image/logo/calculator.png" alt="calculator" class="calculator">
        </a>
        <?php if (!empty($fullname)): ?>
            <span class="customer"><i class="fa fa-user"></i>
                <?php echo $fullname; ?></span>
        <?php endif; ?>
        <a href="../member/cart_product.php" class="cart-icon" onclick="openCart()"><img src="../image/shopping-cart.png" class="cart" alt="tau">
            <span id="cart-count" class="cart-number"><?php echo $cart_count; ?></span>
        </a>
    </nav>    
    <!-- Search Bar -->
    <div class="search-container">
        <input type="text" id="searchInput" class="searchInput" placeholder="Search the data" style="float:right; margin-top: 80px; margin-right: 10px; padding: 8px;">
        <button id="searchButton" class="searchButton" style="padding: 10px; margin-top: 80px; float:right;">Search</button>
    </div>
    <!-- Calculator Modal -->
    <div id="calculatorPopup" class="popup">
        <div class="popup-content">
            <span class="close-btn"></span>
            <input type="text" id="display" class="display" readonly>
            <div class="buttons">
                <button onclick="clearDisplay()" class="clear">C</button>
                <button onclick="backspace()">⌫</button>
                <button onclick="appendToDisplay('%')">%</button>
                <button onclick="appendToDisplay('/')">÷</button>
                
                <button onclick="appendToDisplay('7')">7</button>
                <button onclick="appendToDisplay('8')">8</button>
                <button onclick="appendToDisplay('9')">9</button>
                <button onclick="appendToDisplay('*')">×</button>
                
                <button onclick="appendToDisplay('4')">4</button>
                <button onclick="appendToDisplay('5')">5</button>
                <button onclick="appendToDisplay('6')">6</button>
                <button onclick="appendToDisplay('-')">−</button>
                
                <button onclick="appendToDisplay('1')">1</button>
                <button onclick="appendToDisplay('2')">2</button>
                <button onclick="appendToDisplay('3')">3</button>
                <button onclick="appendToDisplay('+')">+</button>
                
                <button onclick="appendToDisplay('0')">0</button>
                <button onclick="appendToDisplay('.')">.</button>
                <button onclick="calculateResult()" class="equal">=</button>
            </div>
        </div>
    </div>
    <!-- Image Popup -->
    <div id="imagePopup" class="image-popup">
        <div class="image-popup-content">
            <span class="image-close-btn" onclick="closeImagePopup()">&times;</span>
            <button class="nav-btn prev-btn" onclick="navigateImage(-1)">&#10094;</button>
            <div class="popup-image-container">
                <img id="popupImage" src="" alt="Product Image">
                <h3 id="popupProductName"></h3>
            </div>
            <button class="nav-btn next-btn" onclick="navigateImage(1)">&#10095;</button>
        </div>
    </div>
    <!-- Scripts -->
    <script>
        // Product data for navigation
        const products = <?php echo json_encode($products); ?>;
        let currentImageIndex = 0;

        function openImagePopup(index, imageSrc, productName) {
            currentImageIndex = index;
            document.getElementById('popupImage').src = imageSrc;
            document.getElementById('popupProductName').textContent = productName;
            document.getElementById('imagePopup').style.display = 'flex';
            document.body.style.overflow = 'hidden'; // Prevent scrolling
        }

        function closeImagePopup() {
            document.getElementById('imagePopup').style.display = 'none';
            document.body.style.overflow = 'auto'; // Restore scrolling
        }

        function navigateImage(direction) {
            currentImageIndex += direction;
            if (currentImageIndex < 0) {
                currentImageIndex = products.length - 1;
            } else if (currentImageIndex >= products.length) {
                currentImageIndex = 0;
            }
            const product = products[currentImageIndex];
            document.getElementById('popupImage').src = product.imagePath;
            document.getElementById('popupProductName').textContent = product.Product;
        }

        // Keyboard navigation
        document.addEventListener('keydown', function(event) {
            if (document.getElementById('imagePopup').style.display === 'flex') {
                if (event.key === 'ArrowLeft') {
                    navigateImage(-1);
                } else if (event.key === 'ArrowRight') {
                    navigateImage(1);
                } else if (event.key === 'Escape') {
                    closeImagePopup();
                }
            }
        });

        function updateQuantity(button, change) {
            const input = button.parentElement.querySelector("input[name='quantity']");
            let currentValue = parseInt(input.value);
            currentValue += change;
            if (currentValue < 1) currentValue = 1; // Prevent values less than 1
            input.value = currentValue;
        }

        async function addToCart(event, form) {
            event.preventDefault();
            const formData = new FormData(form);

            const feedbackTextarea = form.querySelector("textarea[name='feedback']");
            if (feedbackTextarea) {
                formData.append("feedback", feedbackTextarea.value);
            }

            const submitButton = form.querySelector(".add-to-cart-btn");
            const originalBackground = submitButton.style.backgroundColor;
            const originalText = submitButton.innerText;

            try {
                const response = await fetch('cart_product.php', {
                    method: 'POST',
                    body: formData,
                });

                if (response.ok) {
                    const result = await response.text();
                    console.log(result); // Debugging purpose

                    // Change button appearance
                    submitButton.style.backgroundColor = '#28a745'; // Bootstrap green
                    submitButton.innerText = 'Added To Cart!';
                    submitButton.disabled = true;

                    // Revert after 3 seconds
                    setTimeout(() => {
                        submitButton.style.backgroundColor = originalBackground;
                        submitButton.innerText = originalText;
                        submitButton.disabled = false;
                    }, 3000);
                } else {
                    alert('Failed to add product to cart. Please try again.');
                }
            } catch (error) {
                console.error('Error adding product to cart:', error);
                alert('An error occurred. Please try again.');
            }
        }

        // Search JS
        document.addEventListener("DOMContentLoaded", function () {
            const searchInput = document.getElementById("searchInput");
            const searchButton = document.getElementById("searchButton");

            function filterProducts() {
                const searchText = searchInput.value.toLowerCase().trim();
                const cards = document.querySelectorAll(".card");

                cards.forEach(card => {
                    const cardText = card.innerText.toLowerCase();
                    card.style.display = cardText.includes(searchText) ? "block" : "none";
                });
            }

            searchInput.addEventListener("keyup", function (event) {
                if (event.key === "Enter") {
                    filterProducts();
                }
            });

            searchButton.addEventListener("click", filterProducts);
        });

        // Keyboard Shortcut Key
        document.addEventListener("keydown", function(event) {
            const activeElement = document.activeElement;
            if (event.key === "Backspace" && (activeElement.tagName !== "INPUT" && activeElement.tagName !== "TEXTAREA")) {
                event.preventDefault();
                window.history.back(); 
            }
        });

        document.addEventListener("keydown", function(event) {
            if (event.ctrlKey && event.key.toLowerCase() === "s") {
                event.preventDefault(); 
                const searchInput = document.getElementById("searchInput");
                if (searchInput) {
                    searchInput.focus();
                }
            }
        });

        function updateCartCount() {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "cart_product_count.php", true);
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    let count = xhr.responseText.trim();
                    let cartBadge = document.getElementById("cart-count");

                    if (cartBadge.innerText !== count) {
                        cartBadge.innerText = count;
                        cartBadge.classList.add("updated");
                        setTimeout(() => cartBadge.classList.remove("updated"), 300);
                    }
                }
            };
            xhr.send();
        }

        setInterval(updateCartCount, 2000);
        updateCartCount();

        function toggleCalculator() {
            let popup = document.getElementById("calculatorPopup");
            popup.style.display = (popup.style.display === "block") ? "none" : "block";
        }

        function appendToDisplay(value) {
            document.getElementById("display").value += value;
        }

        function clearDisplay() {
            document.getElementById("display").value = "";
        }

        function calculateResult() {
            try {
                let expression = document.getElementById("display").value;
                expression = expression.replace(/%/g, "/100");
                document.getElementById("display").value = eval(expression);
            } catch {
                document.getElementById("display").value = "Error";
            }
        }

        function backspace() {
            let display = document.getElementById("display");
            display.value = display.value.slice(0, -1);
        }

        if (!document.cookie.split('; ').find(row => row.startsWith('visited='))) {
            document.cookie = "visited=true; max-age=" + 60 * 60 * 24 * 7 + "; path=/";
            console.log("First-time visit: full content loading");
        } else {
            console.log("Returning visitor: use optimized content if needed");
        }
    </script>
</body>
</html>