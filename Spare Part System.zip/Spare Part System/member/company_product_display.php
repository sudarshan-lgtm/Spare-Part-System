<?php
session_start();
include '../db.php';

if (!isset($_SESSION['id'])) {
    header("Location: member_login.php"); 
    exit();
}

// Initialize cart count
$cart_count = 0;

// Fetch cart count from database
$result = $conn->query("SELECT COUNT(*) as count FROM member_cart");
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $cart_count = $row['count'];
}

$fullname = "";
$customer_id = "";
if (isset($_SESSION['id'])) {
    $customer_id = $_SESSION['id']; // Get the logged-in customer ID
    $query = "SELECT fullname FROM member WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $customer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $fullname = htmlspecialchars($row['fullname']);
    }
    $stmt->close();
}

// Get the company name from the query string
$company = isset($_GET['company']) ? $_GET['company'] : null;
$account_type = isset($_GET['account_type']) ? urldecode($_GET['account_type']) : 'Member';
$customer_fullname = isset($_GET['customer_fullname']) ? urldecode($_GET['customer_fullname']) : 'Guest';

if (!$company) {
    die('No company specified.');
}

// Fetch hidden columns for customer/member
$hiddenColumns = [];
$query = "SELECT column_name FROM hiddencolumns WHERE user_id = ? AND user_type = ?";
$stmt = $conn->prepare($query);
$userType = 'member';
$stmt->bind_param("is", $customer_id, $userType);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $hiddenColumns[] = $row['column_name'];
}

$stmt->close();

// Fetch product data for the specified company
$sql = "SELECT imagePath, Product, Batch, Company, PartNo, PurchaseRate, GST, Exp, Margin, PurchaseCode, SaleRate, ReceiptQty, IssueQty, ClosingQty, Location 
        FROM productinventory WHERE Company = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $company);
$stmt->execute();
$result = $stmt->get_result();

$products = [];
$imageBasePath = "../admin folders/";

while ($row = $result->fetch_assoc()) {
    $imagePath = $imageBasePath . $row['imagePath'];
    $row['imagePath'] = $imagePath;
    $products[] = $row;
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title><?= htmlspecialchars($company) ?> Products</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            line-height: 1.6;
            background-color: #EEF2FE;
        }
        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 40px !important;
            background-color: #fff;
            border-radius: 2px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.6);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 20px;
            z-index: 1000;
            backdrop-filter: blur(9px);
        }
        .navbar .logo {
            height: 45px;
            object-fit: contain;
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            filter: drop-shadow(2px 2px 5px rgba(0,0,0,0.4));
        }
        .navbar .cart-icon {
            font-size: 24px;
            color: #333;
            text-decoration: none;
            cursor: pointer;
            transition: transform 0.3s ease, color 0.3s ease;
            position: absolute;
            right: 63px;
        }
        .cart {
            width: 40px;
            height: 40px;
            object-fit: contain;
            transition: transform 0.1s ease, box-shadow 0.3s ease;
            margin-left: 10px;
            transform: perspective(200px) rotateY(5deg);
        }
        .cart:hover {
            transform: perspective(200px) rotateY(0deg) scale(1.05);
        }
        .calculator {
            height: 35px;
            object-fit: contain;
            position: absolute;
            left: 85%;
            top: 20%;
        }
        .popup {
            display: none;
            position: fixed;
            left: 50%;
            top: 60%;
            transform: translate(-50%, -50%);
            width: 320px;
            padding: 20px;
            background: rgba(0, 0, 0, 0.736);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
            text-align: center;
            animation: fadeIn 0.3s ease-in-out;
            z-index: 1001;
        }
        .display {
            width: 100%;
            height: 60px;
            font-size: 2em;
            text-align: right;
            border: none;
            outline: none;
            background: rgba(255, 255, 255, 0.2);
            color: #fff;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 10px;
        }
        .buttons {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
        }
        .buttons button {
            width: 100%;
            height: 60px;
            font-size: 1.5em;
            border: none;
            outline: none;
            border-radius: 8px;
            background: rgba(255, 255, 255, 0.3);
            color: #fff;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
            cursor: pointer;
            transition: all 0.2s ease-in-out;
        }
        .buttons button:hover {
            background: rgba(255, 255, 255, 0.5);
            transform: scale(1.05);
        }
        .equal {
            grid-column: span 2;
            background: #34d399;
        }
        .equal:hover {
            background: #2ab77d;
        }
        .clear {
            background: #ef4444;
        }
        .clear:hover {
            background: #d32f2f;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translate(-50%, -45%); }
            to { opacity: 1; transform: translate(-50%, -50%); }
        }
        /* Image Popup Styles */
        .image-popup {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.85);
            z-index: 1002;
            justify-content: center;
            align-items: center;
            animation: fadeInPopup 0.3s ease-in-out;
        }
        .image-popup-content {
            position: relative;
            max-width: 90%;
            max-height: 90%;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.5);
            overflow: hidden;
            animation: zoomIn 0.3s ease-in-out;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
        }
        .image-popup-content img {
            width: 100%;
            height: auto;
            max-height: 70vh;
            object-fit: contain;
            border-radius: 5px;
        }
        .image-popup-content .product-name {
            margin-top: 15px;
            font-size: 18px;
            font-weight: bold;
            color: #333;
            text-align: center;
            padding: 0 20px;
        }
        .close-popup {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 30px;
            color: #fff;
            background: rgba(0, 0, 0, 0.7);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            transition: background 0.3s;
        }
        .close-popup:hover {
            background: rgba(255, 0, 0, 0.7);
        }
        .nav-arrow {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            font-size: 40px;
            color: #fff;
            background: rgba(0, 0, 0, 0.5);
            padding: 10px;
            cursor: pointer;
            user-select: none;
            transition: background 0.3s;
        }
        .nav-arrow:hover {
            background: rgba(0, 0, 0, 0.8);
        }
        .prev-arrow {
            left: 10px;
        }
        .next-arrow {
            right: 10px;
        }
        @keyframes fadeInPopup {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes zoomIn {
            from { transform: scale(0.8); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }
        .cart-number {
            position: absolute;
            top: -6px;
            right: -17px;
            color: red;
            font-size: 20px;
            font-weight: bold;
            font-family: Arial, sans-serif;
            transition: all 0.3s ease-in-out;
        }
        .cart-badge.updated {
            animation: pop 0.3s ease-in-out;
        }
        @keyframes pop {
            0% { transform: scale(1); }
            50% { transform: scale(1.3); }
            100% { transform: scale(1); }
        }
        h1 {
            margin-top: 10% !important;
            margin-bottom: 20px;
            text-align: center;
        }
        .search-container {
            position: fixed;
            top: 0;
            left: 0;
            background-color: #E9EAEC;
            box-shadow: none;
            width: 100%;
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 999;
        }
        .searchInput {
            padding: 10px;
            font-size: 14px;
            width: 250px;
            border: 1px solid #ccc;
            border-radius: 5px;
            outline: none;
        }
        .searchButton {
            padding: 10px 15px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-left: 10px;
            transition: background-color 0.3s;
        }
        .searchButton:hover {
            background-color: #0056b3;
        }
        .product-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); 
            gap: 20px;
            justify-content: center;
            padding: 10px;
            width: 100%;
            max-width: 1400px;
        }
        .product-card {
            border: 1px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            padding: 15px;
            text-align: center;
            background-color: #fff;
        }
        .product-card img {
            width: 100%;
            height: 250px;
            object-fit: cover;
            border-radius: 5px;
            margin-bottom: 10px;
            cursor: pointer;
            transition: transform 0.3s;
        }
        .product-card img:hover {
            transform: scale(1.05);
        }
        .product-card p {
            font-size: 14px;
            margin: 5px 0;
            text-align: left;
        }
        h4 {
            margin-top: 5px;
            margin-bottom: 5px;
            font-size: 14px;
        }
        .feedbackText {
            width: 100%;
            height: 50px;
            font-size: 14px;
            margin-top: 5px;
            margin-bottom: 7px;
        }
        .quantity-btn {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            border-radius: 4px;
            font-size: 18px;
        }
        .minus {
            background-color: #03A9F4;
        }
        .minus:hover {
            background-color: #0288D1;
        }
        .plus {
            background-color: #4CAF50;
        }
        .plus:hover {
            background-color: #388E3C;
        }
        .quantity-input {
            width: 50px;
            text-align: center;
            font-size: 16px;
            padding: 3px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .add-to-cart-btn {
            background-color: #FF9800;
            color: white;
            border: none;
            padding: 8px 15px;
            cursor: pointer;
            border-radius: 4px;
            font-size: 16px;
            margin-top: 10px;
            width: 100%;
        }
        .add-to-cart-btn:hover {
            background-color: #FB8C00;
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            color: white;
Cesium;
            border-radius: 50%;
            text-decoration: none;
            font-size: 22px;
            transition: all 0.3s ease;
            position: fixed;
            top: 10px;
            left: 20px;
            z-index: 999;
        }
        .back-button:hover {
            transform: scale(1.1);
            color: #fff;
        }
        .back-button .home {
            height: 55px;
            width: auto;
            margin-right: 10px;
            vertical-align: middle;
            object-fit: contain;
        }
        @media (max-width: 2400px) {
            .product-container {
                grid-template-columns: repeat(7, 1fr);
            }
        }
        @media (max-width: 2000px) {
            .product-container {
                grid-template-columns: repeat(6, 1fr);
            }
        }
        @media (max-width: 1600px) {
            .product-container {
                grid-template-columns: repeat(5, 1fr);
            }
        }
        @media (max-width: 1400px) {
            .product-container {
                grid-template-columns: repeat(4, 1fr);
            }
        }
        @media (max-width: 1200px) {
            .product-container {
                grid-template-columns: repeat(4, 1fr);
            }
        }
        @media (max-width: 992px) {
            .product-container {
                grid-template-columns: repeat(3, 1fr);
            }
        }
        @media (max-width: 768px) {
            .product-container {
                grid-template-columns: repeat(3, 1fr);
            }
            .popup {
                width: 320px;
            }
            .buttons button {
                height: 55px;
                font-size: 1.4em;
            }
        }
        @media (max-width: 600px) {
            .product-container {
                grid-template-columns: repeat(2, 1fr);
            }
            .product-card img {
                height: 150px;
                object-fit: contain;
            }
            .quantity-btn {
                font-size: 16px;
                padding: 5px 10px;
            }
            .popup {
                width: 300px;
            }
            .display {
                height: 50px;
                font-size: 1.8em;
            }
            .buttons button {
                height: 50px;
                font-size: 1.3em;
            }
        }
        @media (max-width: 480px) {
            .calculator {
                margin-left: -68% !important;
            }
            .navbar .logo {
                height: 35px;
            }
            .product-container {
                grid-template-columns: repeat(1, 1fr);
            }
            .product-card {
                padding: 12px;
            }
            .add-to-cart-btn {
                font-size: 14px;
            }
            .quantity-input {
                width: 40px;
            }
            .popup {
                width: 280px;
            }
            .display {
                height: 45px;
                font-size: 1.6em;
            }
            .buttons button {
                height: 45px;
                font-size: 1.2em;
            }
        }
        @media screen and (max-height: 500px) and (orientation: landscape) {
            .product-container {
                grid-template-columns: repeat(3, 1fr);
            }
            .product-card img {
                height: 180px;
            }
        }
        @media (min-width: 1400px) {
            .product-container {
                grid-template-columns: repeat(5, 1fr);
            }
        }
    </style>
</head>
<body>
    <?php include("preloader.html"); ?>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <a href='member_dashboard.php' class='back-button'><img src="../image/h1.png" class="home" alt="ok"></a>
        <img src="../image/RJ bg.png" class="logo" alt="RJ">
        <a href="#" onclick="toggleCalculator()">
            <img src="../image/logo/calculator.png" alt="calculator" class="calculator">
        </a>
        <a href="../member/cart_product.php" class="cart-icon" onclick="openCart()"><img src="../image/shopping-cart.png" class="cart" alt="cart">
            <span id="cart-count" class="cart-number"><?php echo $cart_count; ?></span>
        </a>
    </nav>
    <!-- Search Bar -->
    <div class="search-container">
        <input type="text" id="searchInput" class="searchInput" placeholder="Search the data" style="float:right; margin-top: 80px; margin-right: 10px; padding: 8px;">
        <button id="searchButton" class="searchButton" style="padding: 10px; margin-top: 80px; float:right;">Search</button>
    </div>
    <!-- Calculator Modal -->
    <div id="calculatorPopup" class="popup">
        <div class="popup-content">
            <span class="close-btn"></span>
            <input type="text" id="display" class="display" readonly>
            <div class="buttons">
                <button onclick="clearDisplay()" class="clear">C</button>
                <button onclick="backspace()">⌫</button>
                <button onclick="appendToDisplay('%')">%</button>
                <button onclick="appendToDisplay('/')">÷</button>
                <button onclick="appendToDisplay('7')">7</button>
                <button onclick="appendToDisplay('8')">8</button>
                <button onclick="appendToDisplay('9')">9</button>
                <button onclick="appendToDisplay('*')">×</button>
                <button onclick="appendToDisplay('4')">4</button>
                <button onclick="appendToDisplay('5')">5</button>
                <button onclick="appendToDisplay('6')">6</button>
                <button onclick="appendToDisplay('-')">−</button>
                <button onclick="appendToDisplay('1')">1</button>
                <button onclick="appendToDisplay('2')">2</button>
                <button onclick="appendToDisplay('3')">3</button>
                <button onclick="appendToDisplay('+')">+</button>
                <button onclick="appendToDisplay('0')">0</button>
                <button onclick="appendToDisplay('.')">.</button>
                <button onclick="calculateResult()" class="equal">=</button>
            </div>
        </div>
    </div>
    <!-- Image Popup -->
    <div id="imagePopup" class="image-popup">
        <div class="image-popup-content">
            <span class="close-popup" onclick="closeImagePopup()">×</span>
            <img id="popupImage" src="" alt="Product Image">
            <div id="popupProductName" class="product-name"></div>
            <span class="nav-arrow prev-arrow" onclick="navigateImage(-1)">❮</span>
            <span class="nav-arrow next-arrow" onclick="navigateImage(1)">❯</span>
        </div>
    </div>
    <div class='back-button-container'>
        <h1>Products for <?= htmlspecialchars($company) ?></h1>
    </div>
    <div class="product-container">
        <?php if (!empty($products)): ?>
            <?php foreach ($products as $index => $product): ?>
                <div class="product-card">
                    <img src="<?= htmlspecialchars($product['imagePath']) ?>" alt="Product Image" loading="lazy" onclick="openImagePopup(<?php echo $index; ?>)">
                    <h4><?= htmlspecialchars($product['Product']) ?></h4>
                    <?php if (!in_array('Batch', $hiddenColumns)) { ?>
                        <p><strong>Batch:</strong> <?= htmlspecialchars($product['Batch']) ?></p>
                    <?php } ?>
                    <?php if (!in_array('Company', $hiddenColumns)) { ?>
                        <p><strong>Company:</strong> <?= htmlspecialchars($product['Company']) ?></p>
                    <?php } ?>
                    <?php if (!in_array('PartNo', $hiddenColumns)) { ?>
                        <p><strong>Part No:</strong> <?= htmlspecialchars($product['PartNo']) ?></p>
                    <?php } ?>
                    <?php if (!in_array('GST', $hiddenColumns)) { ?>
                        <p><strong>GST:</strong> <?= htmlspecialchars($product['GST']) ?>%</p>
                    <?php } ?>
                    <?php if (!in_array('Exp', $hiddenColumns)) { ?>
                        <p><strong>Exp:</strong> <?= htmlspecialchars($product['Exp']) ?></p>
                    <?php } ?>
                    <?php if (!in_array('Margin', $hiddenColumns)) { ?>
                        <p><strong>Margin:</strong> <?= htmlspecialchars($product['Margin']) ?>%</p>
                    <?php } ?>
                    <?php if (!in_array('SaleRate', $hiddenColumns)) { ?>
                        <p><strong>Sale Rate:</strong> ₹<?= htmlspecialchars($product['SaleRate']) ?></p>
                    <?php } ?>
                    <?php if (!in_array('PurchaseRate', $hiddenColumns)) { ?>
                        <p><strong>Purchase Rate:</strong> ₹<?= htmlspecialchars($product['PurchaseRate']) ?></p>
                    <?php } ?>
                    <?php if (!in_array('ReceiptQty', $hiddenColumns)) { ?>
                        <p><strong>Receipt Qty:</strong> <?= htmlspecialchars($product['ReceiptQty']) ?></p>
                    <?php } ?>
                    <?php if (!in_array('IssueQty', $hiddenColumns)) { ?>
                        <p><strong>Issue Qty:</strong> <?= htmlspecialchars($product['IssueQty']) ?></p>
                    <?php } ?>
                    <?php if (!in_array('ClosingQty', $hiddenColumns)) { ?>
                        <p><strong>Closing Qty:</strong> <?= htmlspecialchars($product['ClosingQty']) ?></p>
                    <?php } ?>
                    <?php if (!in_array('Location', $hiddenColumns)) { ?>
                        <p><strong>Location:</strong> <?= htmlspecialchars($product['Location']) ?></p>
                    <?php } ?>
                    <form onsubmit="addToCart(event, this)">
                        <input type="hidden" name="Product" value="<?= htmlspecialchars($product['Product']) ?>">
                        <input type="hidden" name="Customer" value="<?= htmlspecialchars($fullname) ?>">
                        <input type="hidden" name="customer_fullname" value="<?= htmlspecialchars($customer_fullname) ?>">
                        <input type="hidden" name="account_type" value="<?= htmlspecialchars($account_type) ?>">
                        <input type="hidden" name="Batch" value="<?= htmlspecialchars($product['Batch']) ?>">
                        <input type="hidden" name="Company" value="<?= htmlspecialchars($product['Company']) ?>">
                        <input type="hidden" name="PartNo" value="<?= htmlspecialchars($product['PartNo']) ?>">
                        <input type="hidden" name="GST" value="<?= htmlspecialchars($product['GST']) ?>">
                        <input type="hidden" name="Exp" value="<?= htmlspecialchars($product['Exp']) ?>">
                        <input type="hidden" name="Margin" value="<?= htmlspecialchars($product['Margin']) ?>">
                        <input type="hidden" name="SaleRate" value="<?= htmlspecialchars($product['SaleRate']) ?>">
                        <input type="hidden" name="PurchaseRate" value="<?= htmlspecialchars($product['PurchaseRate']) ?>">
                        <input type="hidden" name="ReceiptQty" value="<?= htmlspecialchars($product['ReceiptQty']) ?>">
                        <input type="hidden" name="IssueQty" value="<?= htmlspecialchars($product['IssueQty']) ?>">
                        <input type="hidden" name="ClosingQty" value="<?= htmlspecialchars($product['ClosingQty']) ?>">
                        <input type="hidden" name="Location" value="<?= htmlspecialchars($product['Location']) ?>">
                        <input type="hidden" name="imagePath" value="<?= htmlspecialchars($product['imagePath']) ?>">
                        <textarea name="feedback" class="feedbackText" placeholder="Enter Feedback Here" rows="4"></textarea>
                        <div style="display: flex; justify-content: center; align-items: center; gap: 10px;">
                            <button type="button" class="quantity-btn minus" onclick="updateQuantity(this, -1)">-</button>
                            <input type="number" name="quantity" value="1" min="1" style="width: 50px; text-align: center;" id="quantity-<?php echo htmlspecialchars($product['PartNo']); ?>">
                            <button type="button" class="quantity-btn plus" onclick="updateQuantity(this, 1)">+</button>
                        </div>
                        <button type="submit" class="add-to-cart-btn">Add To Cart</button>
                    </form>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No products found for <?= htmlspecialchars($company) ?>.</p>
        <?php endif; ?>
    </div>
    <script>
        let currentImageIndex = 0;
        const images = document.querySelectorAll('.product-card img');

        function openImagePopup(index) {
            currentImageIndex = index;
            const popup = document.getElementById('imagePopup');
            const popupImage = document.getElementById('popupImage');
            const popupProductName = document.getElementById('popupProductName');
            popupImage.src = images[index].src;
            popupProductName.textContent = images[index].closest('.product-card').querySelector('h4').textContent;
            popup.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }

        function closeImagePopup() {
            const popup = document.getElementById('imagePopup');
            popup.style.display = 'none';
            document.body.style.overflow = 'auto';
        }

        function navigateImage(direction) {
            currentImageIndex += direction;
            if (currentImageIndex < 0) {
                currentImageIndex = images.length - 1;
            } else if (currentImageIndex >= images.length) {
                currentImageIndex = 0;
            }
            const popupImage = document.getElementById('popupImage');
            const popupProductName = document.getElementById('popupProductName');
            popupImage.src = images[currentImageIndex].src;
            popupProductName.textContent = images[currentImageIndex].closest('.product-card').querySelector('h4').textContent;
        }

        document.addEventListener('keydown', function(event) {
            const popup = document.getElementById('imagePopup');
            if (popup.style.display === 'flex') {
                if (event.key === 'ArrowRight') {
                    navigateImage(1);
                } else if (event.key === 'ArrowLeft') {
                    navigateImage(-1);
                } else if (event.key === 'Escape') {
                    closeImagePopup();
                }
            }
        });

        function updateQuantity(button, change) {
            const input = button.parentElement.querySelector("input[name='quantity']");
            let currentValue = parseInt(input.value);
            currentValue += change;
            if (currentValue < 1) currentValue = 1;
            input.value = currentValue;
        }

        async function addToCart(event, form) {
            event.preventDefault();
            const formData = new FormData(form);
            const addButton = form.querySelector(".add-to-cart-btn");

            try {
                const response = await fetch("cart_product.php", {
                    method: "POST",
                    body: formData
                });
                if (response.ok) {
                    addButton.style.backgroundColor = "#28a745";
                    addButton.textContent = "Added To Cart!";
                    addButton.disabled = true;
                    updateCartCount();
                    setTimeout(() => {
                        addButton.style.backgroundColor = "";
                        addButton.textContent = "Add To Cart";
                        addButton.disabled = false;
                    }, 3000);
                } else {
                    alert('Failed to add product to cart. Please try again.');
                }
            } catch (error) {
                console.error("Error:", error);
                alert('An error occurred while adding to cart.');
            }
        }

        document.addEventListener("DOMContentLoaded", function () {
            const searchInput = document.getElementById("searchInput");
            const searchButton = document.getElementById("searchButton");

            function filterProducts() {
                const searchText = searchInput.value.toLowerCase().trim();
                const cards = document.querySelectorAll(".product-card");

                cards.forEach(card => {
                    let found = false;
                    const allText = card.innerText.toLowerCase();

                    if (allText.includes(searchText)) {
                        found = true;
                    }

                    card.style.display = found ? "block" : "none";
                });
            }

            searchInput.addEventListener("keyup", function (event) {
                if (event.key === "Enter") {
                    filterProducts();
                }
            });

            searchButton.addEventListener("click", filterProducts);
        });

        function updateCartCount() {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "cart_product_count.php", true);
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    let count = xhr.responseText.trim();
                    let cartBadge = document.getElementById("cart-count");

                    if (cartBadge.innerText !== count) {
                        cartBadge.innerText = count;
                        cartBadge.classList.add("updated");
                        setTimeout(() => cartBadge.classList.remove("updated"), 300);
                    }
                }
            };
            xhr.send();
        }

        setInterval(updateCartCount, 2000);

        function toggleCalculator() {
            let popup = document.getElementById("calculatorPopup");
            popup.style.display = (popup.style.display === "block") ? "none" : "block";
        }

        function appendToDisplay(value) {
            document.getElementById("display").value += value;
        }

        function clearDisplay() {
            document.getElementById("display").value = "";
        }

        function calculateResult() {
            try {
                let expression = document.getElementById("display").value;
                expression = expression.replace(/%/g, "/100");
                document.getElementById("display").value = eval(expression);
            } catch {
                document.getElementById("display").value = "Error";
            }
        }

        function backspace() {
            let display = document.getElementById("display");
            display.value = display.value.slice(0, -1);
        }

        if (!document.cookie.split('; ').find(row => row.startsWith('visited='))) {
            document.cookie = "visited=true; max-age=" + 60 * 60 * 24 * 7 + "; path=/";
            console.log("First-time visit: full content loading");
        } else {
            console.log("Returning visitor: use optimized content if needed");
        }
    </script>
</body>
</html>