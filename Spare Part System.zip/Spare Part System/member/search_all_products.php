<?php 
include '../db.php';

$query = $_GET['query'] ?? '';
$query = trim($query);
$customer_fullname = $_GET['name'] ?? '';
$account_type = $_GET['account_type'] ?? '';

if ($query !== '') {
    $query = "%$query%";

    $sql = "SELECT Product FROM productinventory WHERE Product LIKE ? LIMIT 10";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $query);
    $stmt->execute();
    $result = $stmt->get_result();

    echo "<ul style='list-style: none; padding: 0;'>";
    while ($row = $result->fetch_assoc()) {
        $product = urlencode($row['Product']);
        $nameParam = urlencode($customer_fullname);
        $accountParam = urlencode($account_type);
        echo "<li style='padding: 5px; border-bottom: 1px solid #ddd;'>
            <a href='product_group_display.php?single_product=$product&name=$nameParam&account_type=$accountParam' style='text-decoration: none;'>{$row['Product']}</a>
        </li>";
    }
    echo "</ul>";

    $stmt->close();
}
$conn->close();
?>
