<?php
session_start();
include '../db.php';  // Database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

// Check if email already exists
    $sql = "SELECT * FROM member WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

         if ($user['status'] != 1) {
            echo "<script>alert('Your account has been temporarily suspended. Please contact the administrator for assistance.'); window.location.href='member_login.php';</script>";
        } else {
            if (password_verify($password, $user['password'])) {
                // Password is correct
                $_SESSION['id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                header("Location: member_dashboard.php?login=success");
                exit();
            } else {
                echo "<script>alert('Incorrect password!'); window.location.href='member_login.php';</script>";
            }
        }
    } else {
        echo "<script>alert('No account found with the entered username. Please check and try again.'); window.location.href='member_login.php';</script>";
    }

    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <!-- Icon Font Stylesheet -->
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <title>Member Login</title>
    <style>
       body, html {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            height: 100%;
            background-color: #EEF2FE;
        }
        
        .login-page {
            min-height: 100vh;
            padding: 20px;
            border-radius: 20px;
        }
        
        .login-form {
            background-color: #ffffff;
            max-width: 400px;
            width: 100%;
            color: #333;
            border-radius: 20px;
            transition: all 0.3s ease-in-out;
        }
        
        .login-form:hover {
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
            transform: translateY(-3px);
        }
        
        .login-form h2 {
            font-weight: 600;
            color: #2c5364;
        }
        
        .input-group-text {
            background-color: #2c5364;
            color: #fff;
            border: none;
        }
        
        .form-control:focus {
            border-color: #0f2027;
            box-shadow: 0 0 0 0.2rem rgba(47, 128, 237, 0.25);
        }
        
        .btn-primary {
            background-color: #2c5364;
            border: none;
            transition: background-color 0.3s ease-in-out;
        }
        
        .btn-primary:hover {
            background-color: #1a2e3b;
        }
        
        .extra-links a {
            color: #2c5364;
            text-decoration: none;
            font-weight: 500;
        }
        
        .extra-links a:hover {
            text-decoration: underline;
        }

    </style>
</head>
<body>
    <?php include("preloader.html"); ?>
    <div class="container-fluid login-page d-flex align-items-center justify-content-center">
    <form action="member_login.php" method="POST" class="login-form shadow-lg p-4 rounded">
        <div class="login-form">
            <h2  class="text-center mb-4">Member Login</h2>
            <div class="mb-3 input-group">
                <span class="input-group-text"><i class="fa fa-user"></i></span>
                <input type="username" name="username" class="form-control" id="username" placeholder="Enter Username" required>
            </div>
            <div class="mb-3 input-group position-relative">
                <span class="input-group-text"><i class="fas fa-lock"></i></span>
                <input type="password" name="password" id="password" class="form-control" placeholder="Enter Password" required pattern="[A-Za-z0-9@#$%^&*()_+!]+" minlength="8" maxlength="20" title="Password can include letters, numbers, and special characters (@#$%^&*()_+=!).">
                <span class="input-group-text toggle-password" id="toggle-password" style="cursor: pointer;"><i class="fas fa-eye" title="Show Password"></i></span>
            </div>   
            <!--<div class="check">
                <input type="checkbox" name="check" id="check" placeholder="Remember Me"><span>Remember Me</span>
            </div> -->
            <div class="text-center">
                <button type="submit" name="login" class="btn btn-primary px-5">Login In</button>
            </div>
            
            <div class="extra-links text-center mt-3">
                <a href="member_register.php">Register First</a>
            </div>
        </div>
    </form>
    </div>
    <script>
        // Toggle Password Visibility
        document.getElementById("toggle-password").addEventListener("click", function () {
            const passwordField = document.getElementById("password");
            const icon = this.querySelector("i");
            if (passwordField.type === "password") {
                passwordField.type = "text";
                icon.classList.remove("fa-eye");
                icon.classList.add("fa-eye-slash");
            } else {
                passwordField.type = "password";
                icon.classList.remove("fa-eye-slash");
                icon.classList.add("fa-eye");
            }
        });

    </script>
</body>
</html>