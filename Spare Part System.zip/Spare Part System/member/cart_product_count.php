<?php
session_start();
include '../db.php'; // Ensure this file contains database connection logic

// Check if the user is logged in
if (!isset($_SESSION['id'])) {
    echo "0"; // Return 0 if no user is logged in
    exit;
}

$customer_id = $_SESSION['id'];

// Get count of products added by the specific customer
$query = "SELECT COUNT(*) as count FROM member_cart WHERE customer_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $customer_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo $row['count']; // Return count value
} else {
    echo "0";
}

$stmt->close();
$conn->close();
?>
