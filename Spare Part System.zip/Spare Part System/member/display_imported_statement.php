<?php
session_start();
if (!isset($_SESSION["id"])) {
    header("Location: member_login.php");
    exit();
}
// Database connection
try {
    $pdo = new PDO("mysql:host=127.0.0.1:3306;dbname=u494849712_part", "u494849712_patilnagesh007", "Password@1381");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Fetch the most recent import minute
$stmt = $pdo->query("SELECT DATE_FORMAT(MAX(created_at), '%Y-%m-%d %H:%i') as latest_import_minute FROM statement_user_name");
$latest_import_minute = $stmt->fetch(PDO::FETCH_ASSOC)['latest_import_minute'];

// Fetch all customers from the most recent import minute
if ($latest_import_minute) {
    $stmt = $pdo->prepare("SELECT * FROM statement_user_name WHERE DATE_FORMAT(created_at, '%Y-%m-%d %H:%i') = :latest_import_minute ORDER BY statement_id");
    $stmt->execute([':latest_import_minute' => $latest_import_minute]);
    $customers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt = null;
} else {
    $customers = [];
}
?>

<!DOCTYPE html>
<html>
<head>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'>
<link rel="icon" href="../image/icon.png" type="image/png">
<title>Account Statements</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #EEF2FE; /* Light teal */
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            color: white;
            border-radius: 50%;
            text-decoration: none;
            font-size: 22px;
            transition: all 0.3s ease;
            position: fixed; /* Optional: fixed position */
            top: 10px;
            left: 20px;
            z-index: 999;
        }
        .back-button:hover {
            transform: scale(1.1);
            color: #fff;
        }
        .back-button .home {
            height: 55px; 
            width: auto;  
            margin-right: 10px; 
            vertical-align: middle;
            object-fit: contain;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        h2 {
            color: #555;
            margin-top: 30px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 40px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr {
            background-color: #fff !important;
        }
        .summary-row {
            font-weight: bold;
            background-color: #f0f0f0;
        }
        .search-container {
            display: flex;
            justify-content: center;
            margin: 20px 0;
        }

        #searchInput {
            width: 100%;
            max-width: 400px;
            padding: 12px 20px;
            font-size: 16px;
            border: 2px solid #ddd;
            border-radius: 25px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            outline: none;
        }

        #searchInput:focus {
            border-color: #007bff;
            box-shadow: 0 4px 10px rgba(0,123,255,0.2);
        }
    </style>
</head>
<body>
    <?php include("preloader.html"); ?>
    <h1>Last Imported File Account Statements</h1>
    <a href='admin_dashboard.php' class='back-button'><img src="../image/h1.png" class="home" alt="ok"></a>
    <!-- Search Input -->
    <div class="search-container">
        <input type="text" id="searchInput" placeholder="Search by customer name..." onkeyup="filterCustomers()">
    </div>

    <?php if (empty($customers)): ?>
        <p>No data available.</p>
    <?php else: ?>
        <p>Showing data from last import: <?php echo htmlspecialchars($latest_import_minute); ?></p>
        <?php foreach ($customers as $customer): ?>
            <div class="customer-section" data-customer-name="<?php echo htmlspecialchars(strtolower($customer['user_name'])); ?>">
                <h2><?php echo htmlspecialchars($customer['user_name']); ?></h2>
                <p>Period: <?php echo htmlspecialchars($customer['from_date']); ?> to <?php echo htmlspecialchars($customer['to_date']); ?></p>

                <!-- Fetch Opening Balance -->
                <?php
                $stmt = $pdo->prepare("SELECT * FROM opening_balance WHERE statement_id = :statement_id");
                $stmt->execute([':statement_id' => $customer['statement_id']]);
                $opening_balance = $stmt->fetch(PDO::FETCH_ASSOC);
                $stmt = null;
                ?>

                <!-- Fetch Transactions -->
                <?php
                $stmt = $pdo->prepare("SELECT * FROM statement_all_data WHERE statement_id = :statement_id ORDER BY date");
                $stmt->execute([':statement_id' => $customer['statement_id']]);
                $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $stmt = null;
                ?>

                <!-- Fetch Total Amounts -->
                <?php
                $stmt = $pdo->prepare("SELECT * FROM statement_total_amt WHERE statement_id = :statement_id");
                $stmt->execute([':statement_id' => $customer['statement_id']]);
                $total_amt = $stmt->fetch(PDO::FETCH_ASSOC);
                $stmt = null;
                ?>

                <!-- Fetch Closing Balance -->
                <?php
                $stmt = $pdo->prepare("SELECT * FROM closing_balance WHERE statement_id = :statement_id");
                $stmt->execute([':statement_id' => $customer['statement_id']]);
                $closing_balance = $stmt->fetch(PDO::FETCH_ASSOC);
                $stmt = null;
                ?>

                <!-- Transactions Table with Opening Balance, Total, and Closing Balance -->
                <table>
                    <tr>
                        <th>Date</th>
                        <th>Doc/Chq. No.</th>
                        <th>Type</th>
                        <th>Particulars</th>
                        <th>Credit</th>
                        <th>Debit</th>
                        <th>Closing Balance</th>
                    </tr>
                    <!-- Opening Balance Row -->
                    <tr class="summary-row">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>Opening Balance:</td>
                        <td><?php echo number_format($opening_balance['credit_amt'] ?? 0, 2); ?></td>
                        <td><?php echo number_format($opening_balance['debit_amt'] ?? 0, 2); ?></td>
                        <td><?php echo htmlspecialchars($opening_balance['closer_balance'] ?? 'N/A'); ?></td>
                    </tr>
                    <!-- Transaction Rows -->
                    <?php foreach ($transactions as $transaction): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($transaction['date']); ?></td>
                            <td><?php echo htmlspecialchars($transaction['doc_no'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($transaction['type'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($transaction['particulars']); ?></td>
                            <td><?php echo $transaction['credit'] !== null ? number_format($transaction['credit'], 2) : ''; ?></td>
                            <td><?php echo $transaction['debit'] !== null ? number_format($transaction['debit'], 2) : ''; ?></td>
                            <td><?php echo htmlspecialchars($transaction['closing_balance'] ?? ''); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <!-- Total Row -->
                    <tr class="summary-row">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>Total:</td>
                        <td><?php echo number_format($total_amt['credit_amt'] ?? 0, 2); ?></td>
                        <td><?php echo number_format($total_amt['debit_amt'] ?? 0, 2); ?></td>
                        <td></td>
                    </tr>
                    <!-- Closing Balance Row -->
                    <tr class="summary-row">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>Closing Balance:</td>
                        <td></td>
                        <td></td>
                        <td><?php echo htmlspecialchars($closing_balance['closing_balance'] ?? 'N/A'); ?></td>
                    </tr>
                </table>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <script>
        function filterCustomers() {
            // Get the search input value and convert to lowercase
            const searchValue = document.getElementById('searchInput').value.toLowerCase();
            // Get all customer sections
            const customerSections = document.getElementsByClassName('customer-section');

            // Loop through each customer section
            for (let i = 0; i < customerSections.length; i++) {
                const customerName = customerSections[i].getAttribute('data-customer-name');
                // Show or hide based on whether the customer name contains the search value
                if (customerName.includes(searchValue)) {
                    customerSections[i].style.display = 'block';
                } else {
                    customerSections[i].style.display = 'none';
                }
            }
        }
    </script>
</body>
</html>