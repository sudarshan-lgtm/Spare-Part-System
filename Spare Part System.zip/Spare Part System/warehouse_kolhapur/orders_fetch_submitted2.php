<?php
session_start();
include '../db.php';

if (!isset($_SESSION["id"])) {
    exit("Session expired. Please login again.");
}

if (isset($_POST['customer']) && isset($_POST['submit_order_date'])) {
    $customer = $conn->real_escape_string($_POST['customer']);
    $submit_order_date = $conn->real_escape_string($_POST['submit_order_date']);

    // Allowed account types
    $allowedAccountTypes = ['kolhapur_member', 'kolhapur_customer'];
    $placeholders = implode(',', array_fill(0, count($allowedAccountTypes), '?'));

    $query = "SELECT submit_id, product, batch, company, partNo, quantity 
              FROM submitted_orders 
              WHERE customer_fullname = ? 
              AND submit_order_date = ? 
              AND account_type IN ($placeholders)";

    $stmt = $conn->prepare($query);

    // Bind parameters dynamically
    $types = 'ss' . str_repeat('s', count($allowedAccountTypes));
    $stmt->bind_param($types, $customer, $submit_order_date, ...$allowedAccountTypes);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        echo '<div class="expandable-table">';
        echo '<div class="mb-2 d-flex justify-content-between">';
        echo '<button class="btn btn-danger btn-sm my-2 delete-selected">Delete Selected</button>';
        echo '<button class="btn btn-primary btn-sm print-selected">Print Selected</button>';
        echo '</div>';
        echo '<div class="table-responsive">';
        echo '<table class="table table-bordered table-sm">';
        echo '<thead class="table-info">';
        echo '<tr>';
        echo '<th>Sr. No</th>';
        echo '<th><input type="checkbox" class="select-all"></th>';
        echo '<th>Product</th>';
        echo '<th>Batch</th>';
        echo '<th>Company</th>';
        echo '<th>Part No</th>';
        echo '<th>Quantity</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';

        $sr = 1;
        while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . $sr++ . '</td>';
            echo '<td><input type="checkbox" class="order-checkbox" value="'.$row['submit_id'].'"></td>';
            echo '<td>' . htmlspecialchars($row['product']) . '</td>';
            echo '<td>' . htmlspecialchars($row['batch']) . '</td>';
            echo '<td>' . htmlspecialchars($row['company']) . '</td>';
            echo '<td>' . htmlspecialchars($row['partNo']) . '</td>';
            echo '<td>' . htmlspecialchars($row['quantity']) . '</td>';
            echo '</tr>';
        }

        echo '</tbody>';
        echo '</table>';
        echo '</div>';
        echo '</div>';
        $stmt->close();
    } else {
        echo '<div class="text-danger">No orders found for this customer on this date.</div>';
    }
} else {
    echo 'Invalid request.';
}
?>
