    <?php
session_start();
session_unset();   // Clear all session variables
session_destroy(); // Destroy all session data
header("Location: warehouse_login.php"); // Redirect to login page
exit();
?>
