<?php
include '../db.php'; // Database connection

// Define allowed account types
$allowedAccountTypes = ['kolhapur_member', 'kolhapur_customer'];
$placeholders = implode(',', array_fill(0, count($allowedAccountTypes), '?'));

// SQL with IN clause for account_type
$query = "SELECT COUNT(*) AS new_orders 
          FROM orders 
          WHERE is_seen = 0 
          AND account_type IN ($placeholders)";

$stmt = $conn->prepare($query);
$stmt->bind_param(str_repeat('s', count($allowedAccountTypes)), ...$allowedAccountTypes);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
echo $row['new_orders']; // Return new orders count
$stmt->close();
?>
