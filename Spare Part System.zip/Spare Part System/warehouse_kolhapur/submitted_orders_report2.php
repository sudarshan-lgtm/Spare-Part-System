<?php 
session_start();
include '../db.php';

if (!isset($_SESSION["id"])) {
    header("Location: warehouse_login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <title>Customer Orders Summary</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body{
            background-color: #EEF2FE; /* Light teal */
        }
        .expandable {
            cursor: pointer;
            color: blue;
            text-decoration: underline;
        }
        @media print {
            body * {
                visibility: hidden;
            }
            .expandable-table, .expandable-table * {
                visibility: visible;
            }
            .expandable-table {
                position: absolute;
                left: 0;
                top: 0;
            }
        }
    </style>
</head>
<body>

<div class="container my-5">
    <h2 class="text-center mb-4">Customer Orders Summary</h2>

    <div class="table-responsive">
        <table class="table table-bordered table-striped" id="summaryTable">
            <thead class="table-dark">
                <tr>
                    <th>Sr. No</th>
                    <th>Customer Full Name</th>
                    <th>Order Date</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $accountTypes = ['kolhapur_member', 'kolhapur_customer'];
                $placeholders = implode(',', array_fill(0, count($accountTypes), '?'));
                
                $sql = "SELECT customer_fullname, submit_order_date 
                        FROM submitted_orders 
                        WHERE account_type IN ($placeholders)
                        GROUP BY customer_fullname, submit_order_date 
                        ORDER BY submit_order_date DESC";
                
                $stmt = $conn->prepare($sql);
                $stmt->bind_param(str_repeat('s', count($accountTypes)), ...$accountTypes);
                $stmt->execute();
                $result = $stmt->get_result();
                $sr = 1;

                if ($result && $result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $customer = htmlspecialchars($row['customer_fullname']);
                        $submit_order_date = htmlspecialchars($row['submit_order_date']);
                        echo '<tr class="expandable" data-customer="'.htmlspecialchars($row['customer_fullname']).'" data-date="'.htmlspecialchars($row['submit_order_date']).'">';
                        echo '<td>' . $sr++ . '</td>';
                        echo '<td>' . $customer . '</td>';
                        echo '<td>' . date('d-m-Y', strtotime($submit_order_date)) . '</td>';
                        echo '</tr>';
                        echo '<tr class="order-details" style="display:none;"><td colspan="3"></td></tr>'; // Empty row for expanded table
                    }
                } else {
                    echo '<tr><td colspan="3">No orders found</td></tr>';
                }
                $stmt->close();
                ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="print_orders.js"></script> <!-- Print function here -->
<script>
    let selectedPrintContainer = null; // Track currently selected container for Ctrl+P

$(document).ready(function() {
    // Expand Row
    $('.expandable').click(function() {
        var customer = $(this).data('customer');
        var orderDate = $(this).data('date');
        var nextRow = $(this).next('.order-details');

        if (nextRow.is(':visible')) {
            nextRow.hide();
            nextRow.find('td').html('');
        } else {
            $('.order-details').hide().find('td').html('');

            $.ajax({
                url: 'orders_fetch_submitted2.php',
                method: 'POST',
                data: { customer: customer, submit_order_date: orderDate },
                success: function(response) {
                    nextRow.find('td').html(response);
                    nextRow.show();
                }
            });
        }
    });

    // Delete Selected
    $(document).on('click', '.delete-selected', function() {
        var tableContainer = $(this).closest('.expandable-table');
        var checked = tableContainer.find('input.order-checkbox:checked');

        if (checked.length === 0) {
            alert('Please select at least one order to delete.');
            return;
        }

        if (!confirm('Are you sure you want to delete selected orders?')) {
            return;
        }

        var submitIds = [];
        checked.each(function() {
            submitIds.push($(this).val());
        });

        $.ajax({
            url: 'delete_order_submitted.php',
            method: 'POST',
            data: { submit_ids: submitIds },
            success: function(response) {
                alert(response);
                setTimeout(function() {
                    location.reload();
                }, 1000);
            }
        });
    });

    // Single Select All Checkbox (for each inner table)
    $(document).on('change', '.select-all', function() {
        var container = $(this).closest('.expandable-table');
        container.find('.order-checkbox').prop('checked', this.checked);
    });

    // Print Selected
    $(document).on('click', '.print-selected', function() {
        var container = $(this).closest('.expandable-table');
        var checkboxes = container.find('.order-checkbox:checked');

        if (checkboxes.length === 0) {
            alert("Please select at least one order to print.");
            return;
        }

        selectedPrintContainer = container; // Track current container for Ctrl+P

        generatePrint(container, checkboxes);
    });
});

// Function: Generate and Print Selected Orders
function generatePrint(container, checkboxes) {
    let partyName = container.find('.party-name').text() || "N/A";
    let city = container.find('.party-city').text() || "N/A";
    let transport = container.find('.party-transport').text() || "N/A";
    let contact = container.find('.party-contact').text() || "N/A";
    let submitId = container.find('.submit-id').text() || "N/A";
    let orderDate = container.find('.order-date').text() || new Date().toLocaleDateString();

    let printContent = `
    <div class="order-form">
        <div class="header" style="display: flex; justify-content: space-between; align-items: center;">
            <img src="../image/RJ logo.png" style="width: 100px;">
            <div class="contact">
                <h3>Yogesh Patil</h3>
                <p>📞 9834530051 | <img src="../image/logo/whatsapp.png" style="width:15px;"> 9766950925</p>
            </div>
        </div>
        <hr>
        <div class="company-details" style="font-size:14px;">
            <p><strong>Office:</strong> PUNE-SOLAPUR ROAD, NH-65, MOHOL-413 213, DIST. SOLAPUR.</p>
            <p><strong>Warehouse:</strong> GATE NO. 280, PLOT NO. 2, A/P. KONDI, TQ. NORTH SOLAPUR, DIST. SOLAPUR.</p>
            <p><strong>GSTIN:</strong> 27AAZFR2504H1ZV | <strong>Email:</strong> rjautoheaven@gmail.com</p>
        </div>
        <hr>
        <div class="order-details" style="font-size:14px;">
            <p><strong>Order No.:</strong> ${submitId}</p>
            <p><strong>Date:</strong> ${orderDate}</p>
            <p><strong>Party Name:</strong> ${partyName}</p>
            <p><strong>City:</strong> ${city}</p>
            <p><strong>Transport:</strong> ${transport}</p>
            <p><strong>Contact No.:</strong> ${contact}</p>
        </div>
    </div>`;

    printContent += '<table class="table table-bordered" style="width:100%; font-size:14px;"><thead><tr><th>Sr. No</th><th>Product</th><th>Part No</th><th>Qty</th></tr></thead><tbody>';
    
    let sr = 1;
    checkboxes.each(function() {
        var row = $(this).closest('tr').find('td');
        printContent += `
            <tr>
                <td>${sr++}</td>
                <td>${row.eq(2).text()}</td>
                <td>${row.eq(3).text()}</td>
                <td>${row.eq(4).text()}</td>
            </tr>`;
    });

    printContent += '</tbody></table>';

    var printWindow = window.open('', '', 'width=900,height=700');
    printWindow.document.write('<html><head><title>Print Orders</title><style>' +
    'table { border-collapse: collapse; width: 100%; }' +
    'th, td { border: 1px solid black; padding: 8px; text-align: left; }' +
    '.table td:nth-child(2) { min-width: 150px; max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }' +
    '.table td:nth-child(3), .table td:nth-child(4) { min-width: 70px; max-width: 100px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }' +
    '.order-form { width: 90%; margin: 20px auto; padding: 10px; border: 2px solid #000; border-radius: 8px; font-family: Arial, sans-serif; }' +
    '.header { display: flex; justify-content: space-between; align-items: center; }' +
    '.logo { width: 20%; margin-top: -10px; }' +
    'p img { width: 3%; height: auto; }' +
    '.contact { text-align: right; font-size: 14px; margin-top: -10px; line-height: 0.5; font-weight: bold; }' +
    '.contact h3 { text-align: right; font-size: 14px; font-weight: bold; }' +
    '.contact p { line-height: 0.5; }' +
    '.company-details { text-align: center; font-size: 14px; margin-top: -55px; }' +
    '.order-details { font-size: 16px; line-height: 0.5; }' +
    '.order-details h3 { display: inline-block; margin-right: 20px; line-height: 0.5; }' +
    '.order-header, .order-footer { display: flex; justify-content: space-between; align-items: center; }' +
    '.order-row { display: flex; justify-content: space-between; margin: 5px 0; width: 100%; }' +
    '.order-row p { width: 50%; line-height: 0.5; }' +
'</style></head><body>' + printContent + '</body></html>');
    printWindow.document.close();
    printWindow.print();
}

// Handle Ctrl + P Printing
$(document).keydown(function(e) {
    if (e.ctrlKey && e.key === 'p') {
        if (selectedPrintContainer !== null) {
            e.preventDefault();
            var checkboxes = selectedPrintContainer.find('.order-checkbox:checked');
            if (checkboxes.length > 0) {
                generatePrint(selectedPrintContainer, checkboxes);
            } else {
                alert("Please select at least one order to print.");
            }
        }
    }
});
</script>
</body>
</html>
