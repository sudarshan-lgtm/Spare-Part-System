<?php
include '../db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $submit_id = $_POST['submit_id'];
    $remark = $_POST['remark'];

    if (!empty($submit_id) && !empty($remark)) {
        $stmt = $conn->prepare("UPDATE orders SET remark = ? WHERE submit_id = ?");
        $stmt->bind_param("ss", $remark, $submit_id);
        if ($stmt->execute()) {
            echo "success";
        } else {
            echo "fail";
        }
        $stmt-close();
    } else {
        echo "invalid";
    }
} else {
    echo "invalid";
}
?>
