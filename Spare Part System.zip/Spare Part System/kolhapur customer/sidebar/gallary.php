<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("Location: kolhapur_login.php"); 
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Gallery</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #EEF2FE; /* Light teal */
        } 
        .gallery-container {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 50px;
        }
        .folder {
            cursor: pointer;
            text-align: center;
            margin-top: 70px;
            text-align: center;
        }
        .folder img {
            width: 150px;
            height: auto;
            border-radius: 10px;
            transition: transform 0.3s;
        }
        .folder img:hover {
            transform: scale(1.1);
        }
        .folder p {
            margin-top: 5px;
            font-weight: bold;
        }
        button {
            padding: 10px;
            width: auto;
            border-radius: 5px;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
   
</head>
<body> 
<?php include("../preloader.html"); ?>
    <div class="container my-5">
    <div class="row justify-content-center g-4">
        <div class="col-6 col-sm-4 col-md-3 text-center">
            <div class="folder" onclick="location.href='gallery_images.php?folder=images'" style="cursor: pointer;">
                <img src="../../image/logo/gallaryFolder.png" alt="Gallery Folder" class="img-fluid mb-2">
                <p class="fw-bold">Images</p>
            </div>
        </div>
        <div class="col-6 col-sm-4 col-md-3 text-center">
            <div class="folder" onclick="location.href='gallery_videos.php?folder=videos'" style="cursor: pointer;">
                <img src="../../image/logo/gallaryFolder.png" alt="Videos Folder" class="img-fluid mb-2">
                <p class="fw-bold">Videos</p>
            </div>
        </div>
        <div class="col-6 col-sm-4 col-md-3 text-center">
            <div class="folder" onclick="location.href='gif_gallery.php?folders=gifs'" style="cursor: pointer;">
                <img src="../../image/logo/gallaryFolder.png" alt="GIFs Folder" class="img-fluid mb-2">
                <p class="fw-bold">GIFs</p>
            </div>
        </div>
    </div>
</div>
    
</body>
</html>
