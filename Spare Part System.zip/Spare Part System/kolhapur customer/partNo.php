<?php
session_start();
include '../db.php';

if (!isset($_SESSION['id'])) {
    header("Location: kolhapur_login.php"); 
    exit();
}

// Initialize cart count
$cart_count = 0;

// Fetch cart count from database
$result = $conn->query("SELECT COUNT(*) as count FROM kolhapur_cart");
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $cart_count = $row['count'];
}

// Get the logged-in customer's full name and ID
$fullname = "";
$customer_id = "";
if (isset($_SESSION['id'])) {
    $customer_id = $_SESSION['id'];
    $query = "SELECT fullname FROM kolhapur_customer WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $customer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $fullname = htmlspecialchars($row['fullname']);
    }
    $stmt->close();
}

// Fetch hidden columns for customer
$hiddenColumns = [];
$query = "SELECT column_name FROM hiddencolumns WHERE user_id = ? AND user_type = ?";
$stmt = $conn->prepare($query);
$userType = 'kolhapur_customer';
$stmt->bind_param("is", $customer_id, $userType);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $hiddenColumns[] = $row['column_name'];
}
$stmt->close();
// Get part number from URL
$partNo = isset($_GET['partNo']) ? $_GET['partNo'] : '';

$productData = [];
$imagePath = 'no-image.jpg'; // Default image if no image is found

if (!empty($partNo)) {
    $query = "SELECT * FROM kolhapurdata WHERE PartNo = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $partNo);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $productData = $result->fetch_assoc();

        // Check if image path exists in the database
        if (!empty($productData['imagePath']) && file_exists("../admin folders/" . $productData['imagePath'])) {
            $imagePath = "../admin folders/" . $productData['imagePath'];
        }
    }
    $stmt->close();
}

mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <!--<link rel="stylesheet" href="../kolhapur customer/css/partNo.css">-->
    <style>
        /* General Page Styling */
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background-color: #EEF2FE; /* Light teal */
}

/* 🏠 Navigation Bar */
.navbar {
    position: fixed; 
    top: 0;          
    left: 0;         
    width: 100%; 
    height: 40px !important; 
    background-color: #fff;
    border-radius: 2px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.6); 
    display: flex;   
    align-items: center;
    justify-content: space-between;
    padding: 10px 20px; 
    z-index: 1000; 
    backdrop-filter: blur(9px); /* Glass Effect */
}
.navbar .logo {
    height: 45px;
    object-fit: contain;
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
    filter: drop-shadow(2px 2px 5px rgba(0,0,0,0.4)); /* Shadow Effect */
}
.navbar .cart-icon {
    font-size: 24px;
    color: #333;
    text-decoration: none;
    cursor: pointer;
    transition: transform 0.3s ease, color 0.3s ease;
    position: absolute;
    right: 60px; 
}
.cart {
    width: 40px;
    height: 40px;
    object-fit: contain;
    transition: transform 0.1s ease, box-shadow 0.3s ease;
    margin-left: 10px;
    transform: perspective(200px) rotateY(5deg);
}
.cart:hover {
    transform: perspective(200px) rotateY(0deg) scale(1.05);
}
.cart-number {
    position: absolute;
    top: -6px;
    right: -17px;
    color: red; /* 🔥 Cart count number in red */
    font-size: 20px;
    font-weight: bold;
    font-family: Arial, sans-serif;
    transition: all 0.3s ease-in-out;
}
/* Animation for badge update */
.cart-badge.updated {
    animation: pop 0.3s ease-in-out;
}
@keyframes pop {
    0% { transform: scale(1); }
    50% { transform: scale(1.3); }
    100% { transform: scale(1); }
}
.back-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    color: white;
    border-radius: 50%;
    text-decoration: none;
    font-size: 22px;
    transition: all 0.3s ease;
    position: fixed;
    top: 10px;
    left: 20px;
    z-index: 999;
}
.back-button:hover {
    transform: scale(1.1);
    color: #fff;
}
.back-button .home {
    height: 55px; 
    width: auto;  
    margin-right: 10px; 
    vertical-align: middle;
    object-fit: contain;
}  
/* 🛍 Product Groups Container */
.file-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 20px;
    padding: 20px;
}
.card {
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.3);
    width: 300px;
    text-align: center;
    padding: 15px;
    margin-top: 80px;
}
.card img {
    width: 100%;
    height: 250px;
    object-fit: cover;
    border-radius: 8px;
    cursor: pointer; /* Indicate the image is clickable */
}
h4 {
    margin-top: 2px;
    margin-bottom: 5px;
    line-height: 1;
}
.card h3 {
    color: #333;
    margin-top: 10px;
    font-size: 18px;
}
p {
    line-height: 12px;
    text-align: left;
}
.feedbackText {
    width: 100%;
    height: 50px;
    font-size: 14px;
    margin-top: 5px;
    margin-bottom: 7px;
}
/* 📦 Add to Cart Button */
.addToCart {
    width: 100%;
    padding: 10px;
    font-size: 16px;
    background-color: #FF9800; /* Vibrant orange color for the button */
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    margin-top: 10px;
    transition: background-color 0.3s ease, transform 0.3s ease;
}
.addToCart:hover {
    background-color: #FB8C00; 
    transform: scale(1.05);
}
.addToCart:active {
    background-color: #F57C00;
    transform: scale(0.98);
}
/* ➕ Quantity Buttons */
.quantity-container {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 10px;
}
.quantity-btn {
    border: none;
    padding: 10px 15px;
    font-size: 18px;
    cursor: pointer;
    border-radius: 5px;
    width: 40px;
    height: 40px;
    display: flex;
    justify-content: center;
    align-items: center;
    transition: background-color 0.3s ease, transform 0.3s ease;
}
.minus {
    background-color: #03A9F4; /* Blue color for the minus button */
}
.minus:hover {
    background-color: #0288D1; /* Darker shade of blue for hover effect */
}
.plus {
    background-color: #4CAF50; /* Green color for the plus button */
}
.plus:hover {
    background-color: #388E3C; /* Darker shade of green for hover effect */
}
/* 🔄 Animation */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
/* Modal (Popup) Styling */
.modal {
    display: none; /* Hidden by default */
    position: fixed;
    z-index: 1001; /* Above navbar */
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5); /* Semi-transparent background */
    justify-content: center;
    align-items: center;
}
.modal-content {
    background-color: #fff;
    border-radius: 10px;
    padding: 20px;
    text-align: center;
    max-width: 500px;
    width: 90%;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.3);
    position: relative;
}
.modal-content img {
    width: 100%;
    height: auto;
    object-fit: cover;
    border-radius: 8px;
    margin-bottom: 15px;
}
.modal-content h3 {
    margin: 10px 0;
    font-size: 20px;
    color: #333;
}
.close-btn {
    position: absolute;
    top: 10px;
    right: 15px;
    font-size: 24px;
    color: #333;
    cursor: pointer;
    transition: color 0.3s ease;
}
.close-btn:hover {
    color: #FF0000;
}
/* 📱 Responsive Design */
@media (max-width: 768px) {
    .search-partNo-container {
        flex-direction: column;
        align-items: center;
    }
    .search-partNo-container input {
        width: 100%;
        border-radius: 5px;
        margin-bottom: 10px;
    }
    .search-partNo-container button {
        width: 100%;
        border-radius: 5px;
    }
}
@media (max-width: 480px) {
    .card {
        padding: 15px;
    }
    .card p {
        font-size: 14px;
    }
    .search-partNo-container button {
        width: 92%;
        border-radius: 5px;
    }
    .modal-content img {
        height: 200px;
    }
}
/* Landscape Mode Adjustments */
@media screen and (max-height: 500px) and (orientation: landscape) {
    .search-container {
        max-width: 80%;
    }
    .card {
        max-width: 80%;
    }
}
    </style>
    <title>Part Number Details</title>
    <script>
        function updateQuantity(button, change) {
            const input = button.parentElement.querySelector("input[name='quantity']");
            let currentValue = parseInt(input.value);
            currentValue += change;
            if (currentValue < 1) currentValue = 1; // Prevent values less than 1
            input.value = currentValue;
        }

        function addToCart(event, form) {
            event.preventDefault(); // Prevent form submission to handle it via AJAX

            const formData = new FormData(form); // Collect form data

            // Send data to cart_product.php via POST request
            fetch("cart_product.php", {
                method: "POST",
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                if (data.includes("Product added to cart successfully")) {
                    const addButton = form.querySelector("button.addToCart");
                    const originalText = addButton.textContent;
                    addButton.textContent = "Added To Cart";
                    addButton.style.backgroundColor = "#28a745"; // Green
                    addButton.style.color = "#fff";
                    addButton.disabled = true;

                    setTimeout(() => {
                        addButton.textContent = originalText;
                        addButton.style.backgroundColor = "";
                        addButton.style.color = "";
                        addButton.disabled = false;
                    }, 3000);
                    updateCartCount(); // Update cart count after adding
                } else {
                    alert("Failed to add product to cart: " + data);
                }
            })
            .catch(error => {
                console.error("Error:", error);
                alert("An error occurred while adding the product to the cart.");
            });
        }

        // Popup functionality
        document.addEventListener("DOMContentLoaded", function() {
            const productImage = document.getElementById("productImage");
            const modal = document.createElement("div");
            modal.className = "modal";
            modal.innerHTML = `
                <div class="modal-content">
                    <span class="close-btn">×</span>
                    <img src="${productImage ? productImage.src : ''}" alt="Product Image">
                    <h3>${document.getElementById("product") ? document.getElementById("product").textContent : ''}</h3>
                </div>
            `;
            document.body.appendChild(modal);

            const closeBtn = modal.querySelector(".close-btn");

            if (productImage) {
                productImage.addEventListener("click", () => {
                    modal.style.display = "flex";
                });
            }

            closeBtn.addEventListener("click", () => {
                modal.style.display = "none";
            });

            // Close modal when clicking outside the modal content
            modal.addEventListener("click", (e) => {
                if (e.target === modal) {
                    modal.style.display = "none";
                }
            });
        });

        // Keyboard Shortcut Key
        document.addEventListener("keydown", function(event) {
            const activeElement = document.activeElement;
            if (event.key === "Backspace" && (activeElement.tagName !== "INPUT" && activeElement.tagName !== "TEXTAREA")) {
                event.preventDefault();
                window.history.back();
            }
        });

        function updateCartCount() {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "cart_product_count.php", true);
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    let count = xhr.responseText.trim();
                    let cartBadge = document.getElementById("cart-count");
                    if (cartBadge.innerText !== count) {
                        cartBadge.innerText = count;
                        cartBadge.classList.add("updated"); // Apply animation effect
                        setTimeout(() => cartBadge.classList.remove("updated"), 300);
                    }
                }
            };
            xhr.send();
        }

        // Auto-update every 2 seconds (without refresh)
        setInterval(updateCartCount, 2000);

        // Call once on page load
        updateCartCount();
    </script>
</head>
<body>
    <?php include("preloader.html"); ?>
    <nav class="navbar">
        <a href="kolhapur_dashboard.php" class="back-button"><img src="../image/h1.png" class="home" alt="Home"></a>
        <img src="../image/RJ bg.png" class="logo" alt="Logo">
        <a href="../kolhapur customer/cart_product.php" class="cart-icon">
            <img src="../image/shopping-cart.png" class="cart" alt="Cart">
            <span id="cart-count" class="cart-number"><?php echo $cart_count; ?></span>
        </a>
    </nav>

    <?php if (!empty($productData)): ?>
        <div class="card">
            <img id="productImage" src="<?= htmlspecialchars($imagePath) ?>" alt="Product Image">
            <h4><span id="product"><?= htmlspecialchars($productData['Product']) ?></span></h4>

            <?php if (!in_array('Batch', $hiddenColumns)) { ?>
                <p><strong>Batch:</strong> <span id="batch"><?= htmlspecialchars($productData['Batch'] ?? '') ?></span></p>
            <?php } ?>
            <?php if (!in_array('Company', $hiddenColumns)) { ?>
                <p><strong>Company:</strong> <span id="company"><?= htmlspecialchars($productData['Company'] ?? '') ?></span></p>
            <?php } ?>
            <?php if (!in_array('PartNo', $hiddenColumns)) { ?>
                <p><strong>Part No:</strong> <span id="partNoDisplay"><?= htmlspecialchars($productData['PartNo'] ?? '') ?></span></p>
            <?php } ?>
            <?php if (!in_array('PurchaseRate', $hiddenColumns)) { ?>
                <p><strong>Purchase Rate:</strong> <span id="purchaseRate"><?= htmlspecialchars($productData['PurchaseRate'] ?? '') ?></span></p>
            <?php } ?>
            <?php if (!in_array('GST', $hiddenColumns)) { ?>
                <p><strong>GST:</strong> <span id="gst"><?= htmlspecialchars($productData['GST'] ?? '') ?></span></p>
            <?php } ?>
            <?php if (!in_array('Exp', $hiddenColumns)) { ?>
                <p><strong>Exp:</strong> <span id="exp"><?= htmlspecialchars($productData['Exp'] ?? '') ?></span></p>
            <?php } ?>
            <?php if (!in_array('Margin', $hiddenColumns)) { ?>
                <p><strong>Margin:</strong> <span id="margin"><?= htmlspecialchars($productData['Margin'] ?? '') ?></span></p>
            <?php } ?>
            <?php if (!in_array('PurchaseCode', $hiddenColumns)) { ?>
                <p><strong>Purchase Code:</strong> <span id="purchaseCode"><?= htmlspecialchars($productData['PurchaseCode'] ?? '') ?></span></p>
            <?php } ?>
            <?php if (!in_array('SaleRate', $hiddenColumns)) { ?>
                <p><strong>Sale Rate:</strong> <span id="saleRate"><?= htmlspecialchars($productData['SaleRate'] ?? '') ?></span></p>
            <?php } ?>
            <?php if (!in_array('ReceiptQty', $hiddenColumns)) { ?>
                <p><strong>Receipt Qty:</strong> <span id="receiptQty"><?= htmlspecialchars($productData['ReceiptQty'] ?? '') ?></span></p>
            <?php } ?>
            <?php if (!in_array('IssueQty', $hiddenColumns)) { ?>
                <p><strong>Issue Qty:</strong> <span id="issueQty"><?= htmlspecialchars($productData['IssueQty'] ?? '') ?></span></p>
            <?php } ?>
            <?php if (!in_array('ClosingQty', $hiddenColumns)) { ?>
                <p><strong>Closing Qty:</strong> <span id="closingQty"><?= htmlspecialchars($productData['ClosingQty'] ?? '') ?></span></p>
            <?php } ?>
            <?php if (!in_array('Location', $hiddenColumns)) { ?>
                <p><strong>Location:</strong> <span id="location"><?= htmlspecialchars($productData['Location'] ?? '') ?></span></p>
            <?php } ?>
                    
            <form onsubmit="addToCart(event, this)">
                <input type="hidden" name="customer_id" value="<?= $customer_id ?>">
                <input type="hidden" name="PartNo" value="<?= $productData['PartNo'] ?>">
                <input type="hidden" name="Product" value="<?= $productData['Product'] ?>">
                <input type="hidden" name="Batch" value="<?= $productData['Batch'] ?>">
                <input type="hidden" name="Company" value="<?= $productData['Company'] ?>">
                <input type="hidden" name="PurchaseRate" value="<?= $productData['PurchaseRate'] ?>">
                <input type="hidden" name="GST" value="<?= $productData['GST'] ?>">
                <input type="hidden" name="EXP" value="<?= $productData['Exp'] ?>">
                <input type="hidden" name="Margin" value="<?= $productData['Margin'] ?>">
                <input type="hidden" name="SaleRate" value="<?= $productData['SaleRate'] ?>">
                <input type="hidden" name="ReceiptQty" value="<?= $productData['ReceiptQty'] ?>">
                <input type="hidden" name="IssueQty" value="<?= $productData['IssueQty'] ?>">
                <input type="hidden" name="ClosingQty" value="<?= $productData['ClosingQty'] ?>">
                <input type="hidden" name="Location" value="<?= $productData['Location'] ?>">
                <input type="hidden" name="imagePath" value="../admin folders/<?= $productData['imagePath'] ?? '' ?>">
                <textarea name="feedback" class="feedbackText" placeholder="Enter Feedback Here" rows="4"></textarea>
                <div style="display: flex; justify-content: center; align-items: center; gap: 10px;">
                    <button type="button" class="quantity-btn minus" onclick="updateQuantity(this, -1)">-</button>
                    <input type="number" name="quantity" value="1" min="1" style="width: 50px; text-align: center;" id="quantity-<?= htmlspecialchars($productData['PartNo']) ?>">
                    <button type="button" class="quantity-btn plus" onclick="updateQuantity(this, 1)">+</button>
                </div>
                <button type="submit" class="addToCart">Add To Cart</button>
            </form>
        </div>
    <?php else: ?>
        <p style="margin-top:100px; font-size:25px; background-color:white; padding:15px; border-radius:10px; box-shadow:2px 2px 10px rgba(0,0,0,0.5);">No product found for the given Part Number.</p>
    <?php endif; ?>
</body>
</html>