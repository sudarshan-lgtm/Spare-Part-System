<?php
session_start();
include '../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    if (isset($data['id']) && isset($_SESSION['id'])) {
        $productId = $data['id'];
        $customer_id = $_SESSION['id'];

    // Delete the product from the cart table
    $query = "DELETE FROM kolhapur_cart WHERE id = ? AND customer_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $productId, $customer_id);

    if ($stmt->execute()) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false, "error" => $stmt->error]);
    }

    $stmt->close();
} else {
    echo json_encode(["success" => false, "error" => "Invalid request"]);
}
} else {
echo json_encode(["success" => false, "error" => "Invalid method"]);
}
$conn->close();
?>
