<?php
    session_start(); 
    include '../db.php'; 

    if (!isset($_SESSION['id'])) {
        header("Location: kolhapur_login.php"); 
        exit();
    }
    
    // Initialize cart count
    $cart_count = 0;

    // Fetch cart count from database
    $result = $conn->query("SELECT COUNT(*) as count FROM kolhapur_cart");
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $cart_count = $row['count'];
    }

    $fullname = "";
    $customer_id = "";
    if (isset($_SESSION['id'])) {
        $customer_id = $_SESSION['id'];
        $query = "SELECT fullname FROM kolhapur_customer WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $customer_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $fullname = htmlspecialchars($row['fullname']);
        }
        $stmt->close();
    }

    // Fetch hidden columns for customer
    $hiddenColumns = [];
    $query = "SELECT column_name FROM hiddencolumns WHERE user_id = ? AND user_type = ?";
    $stmt = $conn->prepare($query);
    $userType = 'kolhapur_customer';
    $stmt->bind_param("is", $customer_id, $userType);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $hiddenColumns[] = $row['column_name'];
    }
    $stmt->close();
    // Fetch products with offers
    $products = [];
    if (isset($_GET['single_product'])) {
        $productName = trim($_GET['single_product']);
        $query = "SELECT p.*, COALESCE(o.Discount, 0) AS Discount, COALESCE(o.module, '') AS module
                  FROM kolhapurdata p
                  LEFT JOIN offers o ON p.Product = o.Product AND o.module = 'Kolhapur_Customer'
                  WHERE p.Product = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $productName);
    } else {
        $groupName = isset($_GET['group']) ? trim($_GET['group']) : '';
        if (empty($groupName)) {
            echo "<h1>No Product Group Provided</h1>";
            exit;
        }
        $query = "SELECT p.*, COALESCE(o.Discount, 0) AS Discount, COALESCE(o.module, '') AS module
                  FROM kolhapurdata p
                  LEFT JOIN offers o ON p.Product = o.Product AND o.module = 'Kolhapur_Customer'
                  WHERE p.ProductGroup = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $groupName);
    }

    $stmt->execute();
    $result = $stmt->get_result();

    // Filter valid images
    while ($row = $result->fetch_assoc()) {
        $imagePath = "../admin folders/" . $row['imagePath'];
        if (!empty($row['imagePath']) && file_exists($imagePath)) {
            $row['imagePath'] = $imagePath;
        } else {
            $row['imagePath'] = '../assets/images/no-image.png';
        }
        $products[] = $row;
    }
    $stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../kolhapur customer/css/display_product_group.css">
    <title>Display Products</title>
</head>
<body>
    <?php include("preloader.html"); ?>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <a href='kolhapur_dashboard.php' class='back-button'><img src="../image/h1.png" class="home" alt="ok"></a>
        <img src="../image/RJ bg.png" class="logo" alt="RJ">
        <a href="#" onclick="toggleCalculator()">
            <img src="../image/logo/calculator.png" alt="calculator" class="calculator">
        </a>
        <?php if (!empty($fullname)): ?>
            <span class="customer"><i class="fa fa-user"></i> <?php echo $fullname; ?></span>
        <?php endif; ?>
        <a href="../kolhapur customer/cart_product.php" class="cart-icon" onclick="openCart()">
            <img src="../image/shopping-cart.png" class="cart" alt="tau">
            <span id="cart-count" class="cart-number"><?php echo $cart_count; ?></span>
        </a>
    </nav>    
    <!-- Search Bar -->
    <div class="search-container">
        <input type="text" id="searchInput" class="searchInput" placeholder="Search the data" style="float:right; margin-top: 80px; margin-right: 10px; padding: 8px;">
        <button id="searchButton" class="searchButton" style="padding: 10px; margin-top: 80px; float:right;">Search</button>
    </div>
    <!-- Image Popup Modal -->
    <div id="imagePopup" class="image-popup">
        <div class="image-popup-content">
            <span class="image-close-btn" onclick="closeImagePopup()">×</span>
            <button class="nav-btn prev-btn" onclick="navigateImage(-1)">❮</button>
            <img id="popupImage" src="" alt="Product Image" class="popup-image">
            <button class="nav-btn next-btn" onclick="navigateImage(1)">❯</button>
            <h3 id="popupProductName"></h3>
        </div>
    </div>
    <!-- Calculator Modal -->
    <div id="calculatorPopup" class="popup">
        <div class="popup-content">
            <span class="close-btn"></span>
            <input type="text" id="display" class="display" readonly>
            <div class="buttons">
                <button onclick="clearDisplay()" class="clear">C</button>
                <button onclick="backspace()">⌫</button>
                <button onclick="appendToDisplay('%')">%</button>
                <button onclick="appendToDisplay('/')">÷</button>
                <button onclick="appendToDisplay('7')">7</button>
                <button onclick="appendToDisplay('8')">8</button>
                <button onclick="appendToDisplay('9')">9</button>
                <button onclick="appendToDisplay('*')">×</button>
                <button onclick="appendToDisplay('4')">4</button>
                <button onclick="appendToDisplay('5')">5</button>
                <button onclick="appendToDisplay('6')">6</button>
                <button onclick="appendToDisplay('-')">−</button>
                <button onclick="appendToDisplay('1')">1</button>
                <button onclick="appendToDisplay('2')">2</button>
                <button onclick="appendToDisplay('3')">3</button>
                <button onclick="appendToDisplay('+')">+</button>
                <button onclick="appendToDisplay('0')">0</button>
                <button onclick="appendToDisplay('.')">.</button>
                <button onclick="calculateResult()" class="equal">=</button>
            </div>
        </div>
    </div>
    <!-- Product Display -->
    <?php
    if (isset($groupName) && !empty($groupName)) {
        echo "<h1 style='margin-top: 130px;'>Search Results for Product Group: $groupName</h1>";
    } elseif (isset($_GET['single_product']) && !empty($_GET['single_product'])) {
        $productName = htmlspecialchars($_GET['single_product']);
        echo "<h1 style='margin-top: 130px;'>Search Results for Product: $productName</h1>";
    }
    echo "<div class='file-container' style='display: flex; flex-wrap: wrap; gap: 20px;'>";
    if (!empty($products)) {
        $isSingleProduct = isset($_GET['single_product']) && count($products) === 1;
        if ($isSingleProduct) {
            echo "<div style='display: flex; justify-content: center; align-items: center; height: 100vh;'>";
        } else {
            echo "<div class='file-container' style='display: flex; flex-wrap: wrap; gap: 20px;'>";
        }
        foreach ($products as $index => $product) {
            echo "<div class='card' style='border: 1px solid #ccc; padding: 20px; width: 300px; text-align: center;'>
                <div class='image-container' style='position: relative; display: inline-block;'>    
                    <img src='{$product['imagePath']}' alt='{$product['Product']}' loading='lazy' style='width: 100%; height: auto;' onclick='openImagePopup($index)'>";
                    if (!empty($product['Discount'])) {
                        echo "<div class='offer-popup'>{$product['Discount']}% Off</div>";
                    }
                    echo "</div>
                    <h4>{$product['Product']}</h4>";        
                    if (!in_array('Batch', $hiddenColumns) && isset($product['Batch'])) {
                        echo "<p><strong>Batch:</strong> {$product['Batch']}</p>";
                    }
                    if (!in_array('Company', $hiddenColumns) && isset($product['Company'])) {
                        echo "<p><strong>Company:</strong> {$product['Company']}</p>";
                    }
                    if (!in_array('PartNo', $hiddenColumns) && isset($product['PartNo'])) {
                        echo "<p><strong>Part No:</strong> {$product['PartNo']}</p>";
                    }
                    if (!in_array('GST', $hiddenColumns) && isset($product['GST'])) {
                        echo "<p><strong>GST:</strong> {$product['GST']}%</p>";
                    }
                    if (!in_array('Exp', $hiddenColumns) && isset($product['Exp'])) {
                        echo "<p><strong>Exp:</strong> {$product['Exp']}</p>";
                    }
                    if (!in_array('Margin', $hiddenColumns) && isset($product['Margin'])) {
                        echo "<p><strong>Margin:</strong> {$product['Margin']}%</p>";
                    }
                    if (!in_array('SaleRate', $hiddenColumns) && isset($product['SaleRate'])) {
                        echo "<p><strong>Sale Rate:</strong> ₹{$product['SaleRate']}</p>";
                    }
                    if (!in_array('PurchaseRate', $hiddenColumns) && isset($product['PurchaseRate'])) {
                        echo "<p><strong>Purchase Rate:</strong> ₹{$product['PurchaseRate']}</p>";
                    }
                    if (!in_array('ReceiptQty', $hiddenColumns) && isset($product['ReceiptQty'])) {
                        echo "<p><strong>Receipt Qty:</strong> {$product['ReceiptQty']}</p>";
                    }
                    if (!in_array('IssueQty', $hiddenColumns) && isset($product['IssueQty'])) {
                        echo "<p><strong>Issue Qty:</strong> {$product['IssueQty']}</p>";
                    }
                    if (!in_array('ClosingQty', $hiddenColumns) && isset($product['ClosingQty'])) {
                        echo "<p><strong>Closing Qty:</strong> {$product['ClosingQty']}</p>";
                    }
                    if (!in_array('Location', $hiddenColumns) && isset($product['Location'])) {
                        echo "<p><strong>Location:</strong> {$product['Location']}</p>";
                    }
                    echo "<form id='addToCartForm-{$product['PartNo']}' onsubmit='addToCart(event, this)'>
                        <input type='hidden' name='Product' value='{$product['Product']}'>
                        <input type='hidden' name='Customer' value='$fullname'> 
                        <input type='hidden' name='Batch' value='{$product['Batch']}'>
                        <input type='hidden' name='Company' value='{$product['Company']}'>
                        <input type='hidden' name='PartNo' value='{$product['PartNo']}'>
                        <input type='hidden' name='GST' value='{$product['GST']}'>
                        <input type='hidden' name='Exp' value='{$product['Exp']}'>
                        <input type='hidden' name='Margin' value='{$product['Margin']}'>
                        <input type='hidden' name='SaleRate' value='{$product['SaleRate']}'>
                        <input type='hidden' name='PurchaseRate' value='{$product['PurchaseRate']}'>
                        <input type='hidden' name='ReceiptQty' value='{$product['ReceiptQty']}'>
                        <input type='hidden' name='IssueQty' value='{$product['IssueQty']}'>
                        <input type='hidden' name='ClosingQty' value='{$product['ClosingQty']}'>
                        <input type='hidden' name='Location' value='{$product['Location']}'>
                        <input type='hidden' name='imagePath' value='{$product['imagePath']}'>
                        <textarea name='feedback' class='feedbackText' placeholder='Share your valuable experience with us!' rows='10'></textarea>
                        <div style='display: flex; justify-content: center; align-items: center; gap: 10px;'>
                            <button type='button' class='quantity-btn minus' onclick='updateQuantity(this, -1)'>-</button>
                            <input type='number' name='quantity' value='1' min='1' style='width: 50px; text-align: center;' id='quantity-{$product['PartNo']}'>
                            <button type='button' class='quantity-btn plus' onclick='updateQuantity(this, 1)'>+</button>
                        </div>
                        <button type='submit' class='add-to-cart-btn'>Add To Cart</button>
                    </form>
                </div>";
        }
        echo "</div>";
    } else {
        echo "<p>No products found for the selected group or no images available.</p>";
    }
    ?>
    <script>
        // Store products for popup navigation
        const products = <?php echo json_encode($products); ?>;
        let currentImageIndex = 0;

        function openImagePopup(index) {
            currentImageIndex = index;
            const product = products[index];
            document.getElementById('popupImage').src = product.imagePath;
            document.getElementById('popupProductName').innerText = product.Product;
            document.getElementById('imagePopup').style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }

        function closeImagePopup() {
            document.getElementById('imagePopup').style.display = 'none';
            document.body.style.overflow = 'auto';
        }

        function navigateImage(direction) {
            currentImageIndex += direction;
            if (currentImageIndex < 0) {
                currentImageIndex = products.length - 1;
            } else if (currentImageIndex >= products.length) {
                currentImageIndex = 0;
            }
            const product = products[currentImageIndex];
            document.getElementById('popupImage').src = product.imagePath;
            document.getElementById('popupProductName').innerText = product.Product;
        }

        // Keyboard navigation
        document.addEventListener('keydown', function(event) {
            const popup = document.getElementById('imagePopup');
            if (popup.style.display === 'flex') {
                if (event.key === 'ArrowRight') {
                    navigateImage(1);
                } else if (event.key === 'ArrowLeft') {
                    navigateImage(-1);
                } else if (event.key === 'Escape') {
                    closeImagePopup();
                }
            }
        });

        function updateQuantity(button, change) {
            const input = button.parentElement.querySelector("input[name='quantity']");
            let currentValue = parseInt(input.value);
            currentValue += change;
            if (currentValue < 1) currentValue = 1;
            input.value = currentValue;
        }

        async function addToCart(event, form) {
            event.preventDefault();
            const formData = new FormData(form);
            const feedbackTextarea = form.querySelector("textarea[name='feedback']");
            if (feedbackTextarea) {
                formData.append("feedback", feedbackTextarea.value);
            }
            const submitButton = form.querySelector(".add-to-cart-btn");
            const originalBackground = submitButton.style.backgroundColor;
            const originalText = submitButton.innerText;

            try {
                const response = await fetch('cart_product.php', {
                    method: 'POST',
                    body: formData,
                });
                if (response.ok) {
                    submitButton.style.backgroundColor = '#28a745';
                    submitButton.innerText = 'Added To Cart!';
                    submitButton.disabled = true;
                    setTimeout(() => {
                        submitButton.style.backgroundColor = originalBackground;
                        submitButton.innerText = originalText;
                        submitButton.disabled = false;
                    }, 3000);
                } else {
                    alert('Failed to add product to cart. Please try again.');
                }
            } catch (error) {
                console.error('Error adding product to cart:', error);
                alert('An error occurred. Please try again.');
            }
        }

        document.addEventListener("DOMContentLoaded", function () {
            const searchInput = document.getElementById("searchInput");
            const searchButton = document.getElementById("searchButton");

            function filterProducts() {
                const searchText = searchInput.value.toLowerCase().trim();
                const cards = document.querySelectorAll(".card");
                cards.forEach(card => {
                    const cardText = card.innerText.toLowerCase();
                    card.style.display = cardText.includes(searchText) ? "block" : "none";
                });
            }

            searchInput.addEventListener("keyup", function (event) {
                if (event.key === "Enter") {
                    filterProducts();
                }
            });
            searchButton.addEventListener("click", filterProducts);
        });

        function updateCartCount() {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "cart_product_count.php", true);
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    let count = xhr.responseText.trim();
                    let cartBadge = document.getElementById("cart-count");
                    if (cartBadge.innerText !== count) {
                        cartBadge.innerText = count;
                        cartBadge.classList.add("updated");
                        setTimeout(() => cartBadge.classList.remove("updated"), 300);
                    }
                }
            };
            xhr.send();
        }

        setInterval(updateCartCount, 2000);
        updateCartCount();

        function toggleCalculator() {
            let popup = document.getElementById("calculatorPopup");
            popup.style.display = (popup.style.display === "block") ? "none" : "block";
        }

        function appendToDisplay(value) {
            document.getElementById("display").value += value;
        }

        function clearDisplay() {
            document.getElementById("display").value = "";
        }

        function calculateResult() {
            try {
                let expression = document.getElementById("display").value;
                expression = expression.replace(/%/g, "/100");
                document.getElementById("display").value = eval(expression);
            } catch {
                document.getElementById("display").value = "Error";
            }
        }

        function backspace() {
            let display = document.getElementById("display");
            display.value = display.value.slice(0, -1);
        }

        if (!document.cookie.split('; ').find(row => row.startsWith('visited='))) {
            document.cookie = "visited=true; max-age=" + 60 * 60 * 24 * 7 + "; path=/";
            console.log("First-time visit: full content loading");
        } else {
            console.log("Returning visitor: use optimized content if needed");
        }
    </script>
</body>
</html>