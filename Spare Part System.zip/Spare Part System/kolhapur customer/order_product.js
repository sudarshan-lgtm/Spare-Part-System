// delete button work into table
document.addEventListener('DOMContentLoaded', () => {
    // Select all delete buttons
    document.querySelectorAll('.delete-btn').forEach(button => {
        button.addEventListener('click', function () {
            const row = this.closest ('tr');
            const id = row.getAttribute('data-order-id'); // Get product ID

            // Send delete request to the server
            fetch('order_delete.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ id: id }) // Send product ID
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    row.remove();
                    alert('Order removed from orders successfully!');
                } else {
                    alert('Failed to remove Order from Orders!');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while removing the order.');
            });
        });
    });
});

//Delete selected all orders
document.addEventListener("DOMContentLoaded", function () {
    const selectAllCheckbox = document.getElementById("select-all-orders");
    const checkboxes = document.querySelectorAll('#ordersTable tbody input[type="checkbox"]');
    const deleteButton = document.querySelector('.delete-btn');

    // Select All Checkbox Functionality
    selectAllCheckbox.addEventListener('change', function () {
        checkboxes.forEach(checkbox => {
            checkbox.checked = selectAllCheckbox.checked;
        });
    });

    // Delete Selected Orders
    deleteButton.addEventListener('click', function () {
        const selectedCheckboxes = document.querySelectorAll('#ordersTable tbody input[type="checkbox"]:checked');
        const idsToDelete = Array.from(selectedCheckboxes).map(cb => cb.closest('tr').getAttribute('data-order-id'));

        if (idsToDelete.length === 0) {
            alert('Please select at least one order to delete.');
            return;
        }

        if (confirm('Are you sure you want to delete the selected orders?')) {
            fetch('order_delete_selected.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ids: idsToDelete })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    idsToDelete.forEach(id => document.querySelector(`tr[data-order-id="${id}"]`).remove());
                    alert('Orders deleted successfully!');
                } else {
                    alert('Failed to delete orders.');
                }
            }).catch(error => console.error('Error:', error));
        }
    });
});
