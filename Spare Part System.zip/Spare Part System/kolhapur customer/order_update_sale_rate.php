<?php
include '../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $orderId = intval($_POST['orderId']);
    $newSaleRate = floatval($_POST['newSaleRate']);

    // Update the database with the new sale rate
    $updateQuery = "UPDATE kolhapur_orders SET enterSaleRate = ?, updatedSaleRate = ? WHERE id = ?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("ddi", $newSaleRate, $newSaleRate, $orderId);

    if ($stmt->execute()) {
        echo json_encode(["success" => true, "updatedSaleRate" => $newSaleRate]);
    } else {
        echo json_encode(["success" => false, "error" => "Database update failed"]);
    }
    $stmt->close(); // Added to close the prepared statement
    $conn->close();
}
?>
