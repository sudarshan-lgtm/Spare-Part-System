<?php
include '../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $submitId = $_POST['submitId'];
    $newSaleRate = floatval($_POST['newSaleRate']);

    // Update based on submit_id, not id
    $updateQuery = "UPDATE orders SET enterSaleRate = ?, updatedSaleRate = ? WHERE submit_id = ?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("dds", $newSaleRate, $newSaleRate, $submitId);

    if ($stmt->execute()) {
        echo json_encode(["success" => true, "updatedSaleRate" => $newSaleRate]);
    } else {
        echo json_encode(["success" => false, "error" => "Database update failed"]);
    }
    $stmt->close();
}
?>
