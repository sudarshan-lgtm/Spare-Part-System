<?php
session_start();
include '../../db.php';

if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}
$fullname = "Admin";
$account_type = "Admin";

if (isset($_GET['name'])) {
    $fullname = htmlspecialchars($_GET['name']);

    // Fetch account_type from the database based on the fullname
    $query = "SELECT account_type FROM admission WHERE fullname = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $fullname);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $account_type);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);
}

// Get the list of images from the folder
$image_dir = "../uploads/folders/";
$images = array_diff(scandir($image_dir), array('.', '..'));

// Function to get cards from a table
function getCompanyCards($conn, $tableName, $images, $image_dir) {
    $cards = [];
    $sql = "SELECT DISTINCT company FROM $tableName";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $company_name = strtolower($row['company']);
            foreach ($images as $image) {
                $image_name = strtolower(pathinfo($image, PATHINFO_FILENAME));
                if ($image_name === $company_name) {
                    $cards[] = [
                        'image' => $image_dir . $image,
                        'company' => $row['company'],
                        'source' => $tableName
                    ];
                    break;
                }
            }
        }
    }
    return $cards;
}

$productInventoryCards = getCompanyCards($conn, 'productinventory', $images, $image_dir);
$kolhapurDataCards = getCompanyCards($conn, 'kolhapurdata', $images, $image_dir);

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <title>Companies</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #EEF2FE; /* Light teal */
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            color: white;
            border-radius: 50%;
            text-decoration: none;
            font-size: 22px;
            transition: all 0.3s ease;
            position: fixed; /* Optional: fixed position */
            top: 10px;
            left: 20px;
            z-index: 999;
        }
        .back-button:hover {
            transform: scale(1.1);
            color: #fff;
        }
        .back-button .home {
            height: 55px; 
            width: auto;  
            margin-right: 10px; 
            vertical-align: middle;
            object-fit: contain;
        }
        .header-container {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
        }

        .header-content {
            flex-grow: 1;
            text-align: center;
        }
        h1 {
            margin: 0 auto;
            font-size: 24px;
            text-align: center;
            margin-left: 8% !important;
        }
        .addCustomer {
            padding: 10px 15px;
            border: none;
            float: right;
            border-radius: 5px;
            background-color: #007bff;
            color: white;
            font-size: 16px;
            text-decoration: none;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out;
        }

        .addCustomer:hover {
            background-color: rgb(0, 102, 211);
        }

        .fullname-container {
            text-align: center;
            font-size: 18px;
            color: #333;
            margin-top: 10px;
            width: 100%;
        }
        .cards-container {
            
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }
        .card {
            width: 280px;
            margin: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            text-align: center;
            overflow: hidden;
            background-color: #fff;
        }
        .card img {
            width: 100%;
            height: 160px;
            object-fit: cover;
        }
        .card h3 {
            margin: 10px 0;
        }
        .card p {
            color: #555;
        }
        /* Responsive Design */
        /* For tablets and smaller laptops */
        @media screen and (max-width: 1024px) {
            h1 {
                font-size: 22px;
            }

            .fullname-container {
                font-size: 14px;
                padding: 8px 15px;
            }

            .card {
                width: 250px;
            }

            .addCustomer {
                font-size: 14px;
                padding: 8px;
            }
        }

        /* For smartphones */
        @media screen and (max-width: 768px) {
            .header-content {
                flex-direction: column;
                text-align: center;
            }

            h1 {
                font-size: 20px;
                margin: 5px 0;
            }

            .back-button, .addCustomer {
                width: 90%;
                text-align: center;
                margin: 5px 0;
            }

            .fullname-container {
                text-align: center;
                width: 90%;
                margin: 5px auto;
                font-size: 14px;
            }

            .cards-container {
                margin-top: 30%;
            }

            .card {
                width: 45%;
            }
        }

        /* For small smartphones */
        @media screen and (max-width: 480px) {
            .header-container{
                width: 100%;
            }
            .companyname {
                width: 90% !important;
            }
            h1 {
                font-size: 18px;
                margin-top: 40px;
                text-align: center;
                margin-left: 35% !important;
            }

            .fullname-container {
                font-size: 13px;
                display: none;
            }
            .back-button {
                width: 14%;
                float: left;
            }
            .addCustomer {
                font-size: 13px;
                padding: 9px;
                width: 30%;
                margin-top: 0;
            }
            .cards-container {
                display: grid;
                grid-template-columns: repeat(2, 1fr);
                justify-content: center;
                margin-top: 5%;
            }
            .card {
                width: 90%;
            }
        }

        /* Landscape mode adjustments */
        @media screen and (max-width: 768px) and (orientation: landscape) {
            .header-container {
                padding: 5px;
            }

            .back-button, .addCustomer {
                font-size: 14px;
                padding: 6px;
            }

            .fullname-container {
                font-size: 14px;
                padding: 6px 12px;
            }

            .cards-container {
                margin-top: 10%;
            }

            .card {
                width: 40%;
            }
        }
    </style>
</head>
<body>
    <?php include("preloader.html"); ?>
<div class="header-container">
    <div class="header-content">
    <a href='../admin_dashboard.php' class='back-button'><img src="../../image/h1.png" class="home" alt="ok"></a>
        <a href="company_admission.php" class="btn btn-primary addCustomer">Add Customer</a>
        <h1>Companies</h1>
    </div>
    <?php if (!empty($fullname)): ?>
        <h2 class="fullname-container">Welcome, <?= htmlspecialchars($fullname) ?> (<?= htmlspecialchars($account_type) ?>)!</h2>
    <?php endif; ?>
</div>
<!-- ProductInventory Section -->
<h2 class="companyname" style="background-color:rgba(3, 163, 255, 0.78); color: white; padding: 7px 0; border-radius: none; width: 40%; margin: 0 auto; text-align: center; margin-top: 10px;">Solapur Companies</h2>
<div class="cards-container">
    <?php if (count($productInventoryCards) > 0): ?>
        <?php foreach ($productInventoryCards as $card): ?>
            <div class="card">
                <a href="display_company_products.php?company=<?= urlencode($card['company']) ?>&fullname=<?= urlencode($fullname) ?>&account_type=<?= urlencode($account_type) ?>&source=productinventory" style="text-decoration:none; color:#333;">
                    <img src="<?= $card['image'] ?>" alt="Company Image" loading="lazy">
                    <h3><?= $card['company'] ?></h3>
                </a>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No companies found in ProductInventory.</p>
    <?php endif; ?>
</div>

<!-- KolhapurData Section -->
<h2 class="companyname" style="background-color:rgba(3, 163, 255, 0.78); color: white; padding: 7px 0; border-radius: none; width: 40%; margin: 0 auto; text-align: center; margin-top: 10px;">Kolhapur Companies</h2>
<div class="cards-container">
    <?php if (count($kolhapurDataCards) > 0): ?>
        <?php foreach ($kolhapurDataCards as $card): ?>
            <div class="card">
                <a href="display_company_products.php?company=<?= urlencode($card['company']) ?>&fullname=<?= urlencode($fullname) ?>&account_type=<?= urlencode($account_type) ?>&source=kolhapurdata" style="text-decoration:none; color:#333;">
                    <img src="<?= $card['image'] ?>" alt="Company Image" loading="lazy">
                    <h3><?= $card['company'] ?></h3>
                </a>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No companies found in KolhapurData.</p>
    <?php endif; ?>
</div>
<script>
    document.addEventListener("keydown", function(event) {
        if (event.key === "Backspace") {
            event.preventDefault(); // Default action थांबवते (text field मध्ये backspace काम करणे थांबते)
            window.history.back(); // Previous page ला जायला लावते
        }
    });
</script>
<script>
  // Check if the cookie exists
  if (!document.cookie.split('; ').find(row => row.startsWith('visited='))) {
    // Set cookie for 7 days
    document.cookie = "visited=true; max-age=" + 60 * 60 * 24 * 7 + "; path=/";
    console.log("First-time visit: full content loading");
  } else {
    console.log("Returning visitor: use optimized content if needed");
    // तुम्ही इथे placeholder images किंवा low-res images लावू शकता
  }
</script>

</body>
</html>