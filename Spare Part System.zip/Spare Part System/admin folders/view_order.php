<?php
session_start();
include '../db.php';

if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}

if (isset($_GET['submit_id'])) {
    $submit_id = $_GET['submit_id'];

    // Mark this specific order as seen
    $stmt = $conn->prepare("UPDATE orders SET is_seen = 1 WHERE submit_id = ?");
    $stmt->bind_param("s", $submit_id);
    $stmt->execute();
    $stmt->close();

    // Redirect to order page with highlight
    header("Location: ../admin folders/order.php?highlight_submit_id=" . urlencode($submit_id));
    exit();
} else {
    // If no submit_id provided, redirect back
    header("Location: notification.php");
    exit();
}
?>
