<?php
session_start();

// Only allow logged-in users
if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}

// Connect to database
try {
    $pdo = new PDO("mysql:host=127.0.0.1:3306;dbname=u494849712_part", "u494849712_patilnagesh007", "Password@1381");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // List of tables to truncate
    $tables = [
        'closing_balance',
        'opening_balance',
        'statement_all_data',
        'statement_total_amt',
        'statement_user_name'
    ];

    // Disable foreign key checks
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");

    // Truncate each table
    foreach ($tables as $table) {
        $pdo->exec("TRUNCATE TABLE `$table`");
    }

    // Re-enable foreign key checks
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");

    echo "<script>alert('All ledger data has been deleted successfully!'); window.location.href='import_csv_statement.php';</script>";

} catch (PDOException $e) {
    echo "<script>alert('Error deleting ledger data: " . $e->getMessage() . "'); window.history.back();</script>";
}
?>
