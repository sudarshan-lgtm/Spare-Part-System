<?php
session_start();
include '../db.php';

if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}
// Initialize cart count
$cart_count = 0;

// Fetch cart count from database
$result = $conn->query("SELECT COUNT(*) as count FROM cart");
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $cart_count = $row['count'];
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="../admin folders/css/search_partNo.css">
    <title>Part No</title>
</head>
<body>
    <?php include("preloader.html"); ?>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <a href='admin_dashboard.php' class='back-button'><img src="../image/h1.png" class="home" alt="ok"></a>
        <img src="../image/RJ bg.png" class="logo" alt="RJ">
        <a href="../admin folders/cart.php" class="cart-icon" onclick="openCart()"> <img src="../image/shopping-cart.png" class="cart" alt="tau">
            <span id="cart-count" class="cart-number"><?php echo $cart_count; ?></span>
        </a>
    </nav>
    <?php
    include '../db.php'; // Include database connection

    // Fetch partNo from GET parameter
    $fullname = isset($_GET['name']) ? htmlspecialchars($_GET['name']) : '';
    $account_type = isset($_GET['account_type']) ? htmlspecialchars($_GET['account_type']) : "";
    $partNo = isset($_GET['partNo']) ? trim($_GET['partNo']) : '';

    if (empty($partNo)) {
        echo "<h1>No Part No Provided</h1>";
        exit;
    }

    $folderPath = 'Uploads/folders/';
    $products = [];
    $tableUsed = ""; // This will track which table the product was found in

    // 1. Search in Kolhapur data
    $queryKolhapur = "SELECT * FROM kolhapurdata WHERE PartNo = ?";
    $stmt = $conn->prepare($queryKolhapur);
    $stmt->bind_param("s", $partNo);
    $stmt->execute();
    $resultKolhapur = $stmt->get_result();

    while ($row = $resultKolhapur->fetch_assoc()) {
        $imagePath = $row['imagePath'];
        $row['imagePath'] = (!empty($imagePath) && file_exists($imagePath)) ? $imagePath : '';
        $products[] = $row;
        $tableUsed = "Kolhapur";
    }
    $resultKolhapur->free();
    $stmt->close();

    // 2. If not found in Kolhapur, search in ProductInventory
    if (empty($products)) {
        $querySolapur = "SELECT * FROM productinventory WHERE PartNo = ?";
        $stmt = $conn->prepare($querySolapur);
        $stmt->bind_param("s", $partNo);
        $stmt->execute();
        $resultSolapur = $stmt->get_result();

        while ($row = $resultSolapur->fetch_assoc()) {
            $imagePath = $row['imagePath'];
            $row['imagePath'] = (!empty($imagePath) && file_exists($imagePath)) ? $imagePath : '';
            $products[] = $row;
            $tableUsed = "Solapur";
        }
        $resultSolapur->free();
        $stmt->close();
    }
    $conn->close();

    // 3. Heading message
    if ($tableUsed == "Kolhapur") {
        echo "<h1 style='margin-top: 130px;'>Kolhapur Product - Search Results for Part No: $partNo</h1>";
    } else if ($tableUsed == "Solapur") {
        echo "<h1 style='margin-top: 130px;'>Solapur Product - Search Results for Part No: $partNo</h1>";
    } else {
        echo "<h1 style='margin-top: 130px;'>Search Results for Part No: $partNo</h1>";
    }

    echo "<div class='file-container' style='display: flex; flex-wrap: wrap; gap: 20px;'>";

    if (!empty($products)) {
        foreach ($products as $product) {
            echo "<div class='card' style='border: 1px solid #ccc; padding: 20px; width: 300px; text-align: center;'>
                    <img src='{$product['imagePath']}' alt='{$product['Product']}' style='width: 100%; height: auto; cursor: pointer;' onclick=\"openPopup('{$product['imagePath']}', '{$product['Product']}')\">
                    <h4>{$product['Product']}</h4>
                    <p><strong>Batch:</strong> {$product['Batch']}</p>
                    <p><strong>Company:</strong> {$product['Company']}</p>
                    <p><strong>Part No:</strong> {$product['PartNo']}</p>
                    <p><strong>Purchase Rate:</strong> ₹{$product['PurchaseRate']}</p>
                    <p><strong>GST:</strong> {$product['GST']}%</p>
                    <p><strong>Exp:</strong> {$product['Exp']}</p>
                    <p><strong>Margin:</strong> {$product['Margin']}%</p>
                    <p><strong>Sale Rate:</strong> ₹{$product['SaleRate']}</p>
                    <p><strong>Closing Qty:</strong> {$product['ClosingQty']}</p>
                    <p><strong>Location:</strong> {$product['Location']}</p>
                    <textarea name='feedback' class='feedbackText' placeholder='Enter Feedback Here' rows='10'></textarea>
                    <form id='addToCartForm-{$product['PartNo']}' onsubmit='addToCart(event, this)'>
                        <input type='hidden' name='fullname' value='{$fullname}'>
                        <input type='hidden' name='account_type' value='{$account_type}'>
                        <input type='hidden' name='Product' value='{$product['Product']}'>
                        <input type='hidden' name='Batch' value='{$product['Batch']}'>
                        <input type='hidden' name='Company' value='{$product['Company']}'>
                        <input type='hidden' name='PartNo' value='{$product['PartNo']}'>
                        <input type='hidden' name='PurchaseRate' value='{$product['PurchaseRate']}'>
                        <input type='hidden' name='GST' value='{$product['GST']}'>
                        <input type='hidden' name='Exp' value='{$product['Exp']}'>
                        <input type='hidden' name='Margin' value='{$product['Margin']}'>
                        <input type='hidden' name='SaleRate' value='{$product['SaleRate']}'>
                        <input type='hidden' name='ClosingQty' value='{$product['ClosingQty']}'>
                        <input type='hidden' name='Location' value='{$product['Location']}'>
                        <input type='hidden' name='imagePath' value='{$product['imagePath']}'>  
                        <div style='display: flex; justify-content: center; align-items: center; gap: 10px;'>
                            <button type='button' class='quantity-btn minus' onclick='updateQuantity(this, -1)'>-</button>
                            <input type='number' name='quantity' value='1' min='1' style='width: 50px; text-align: center;' id='quantity-{$product['PartNo']}'>
                            <button type='button' class='quantity-btn plus' onclick='updateQuantity(this, 1)' >+</button>
                        </div>
                        <button type='submit' class='add-to-cart-btn'>Add To Cart</button>
                    </form>
                </div>";
        }
    } else {
        echo "<p style='margin-top:100px; font-size:25px;background-color:white; padding: 15px; border-radius: 10px; box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.5);'>No products found for the provided Part No.</p>";
    }
    echo "</div>";
    ?>
    <!-- Popup Modal -->
    <div id="imagePopup" class="popup">
        <div class="popup-content">
            <span class="close-btn" onclick="closePopup()">&times;</span>
            <img id="popupImage" src="" alt="Product Image">
            <h3 id="popupProductName"></h3>
        </div>
    </div>

    <script>
        function updateQuantity(button, change) {
            const input = button.parentElement.querySelector("input[name='quantity']");
            let currentValue = parseInt(input.value);
            currentValue += change;
            if (currentValue < 1) currentValue = 1; // Prevent values less than 1
            input.value = currentValue;
        }
        
        // Add To Cart
        async function addToCart(event, form) {
            event.preventDefault();

            const formData = new FormData(form);
            formData.append('feedback', form.closest('.card').querySelector("textarea[name='feedback']").value);

            const button = form.querySelector('.add-to-cart-btn');
            const originalColor = button.style.backgroundColor;

            try {
                const response = await fetch('cart.php', {
                    method: 'POST',
                    body: formData,
                });

                if (response.ok) {
                    // Change button color to green and show success
                    button.style.backgroundColor = 'green';
                    button.textContent = 'Added To Cart!';
                    
                    // After 3 seconds, revert back to original
                    setTimeout(() => {
                        button.style.backgroundColor = originalColor || ''; // fallback if no background was set
                        button.textContent = 'Add To Cart';
                    }, 3000);
                } else {
                    alert('Failed to add product to cart. Please try again.');
                }
            } catch (error) {
                console.error('Error:', error);
                alert('An error occurred while adding to cart.');
            }
        }
        // Update Cart Count
        function updateCartCount() {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "cart_count.php", true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    let count = xhr.responseText.trim();
                    let cartBadge = document.getElementById("cart-count");

                    if (cartBadge.innerText !== count) {
                        cartBadge.innerText = count;
                        cartBadge.classList.add("updated"); // Apply animation effect
                        setTimeout(() => cartBadge.classList.remove("updated"), 300);
                    }
                }
            };
            xhr.send();
        }

        // Auto-update every 5 seconds
        setInterval(updateCartCount, 2000);

        // Keyboard Shortcut Key
        document.addEventListener("keydown", function(event) {
            const activeElement = document.activeElement;
            
            // Check if the active element is an input field
            if (event.key === "Backspace" && (activeElement.tagName !== "INPUT" && activeElement.tagName !== "TEXTAREA")) {
                event.preventDefault();
                window.history.back(); 
            }
        });

        // Popup Functions
        function openPopup(imageSrc, productName) {
            const popup = document.getElementById('imagePopup');
            const popupImage = document.getElementById('popupImage');
            const popupProductName = document.getElementById('popupProductName');
            
            popupImage.src = imageSrc;
            popupProductName.textContent = productName;
            popup.style.display = 'flex';
            document.body.style.overflow = 'hidden'; // Prevent scrolling
        }

        function closePopup() {
            const popup = document.getElementById('imagePopup');
            popup.style.display = 'none';
            document.body.style.overflow = 'auto'; // Restore scrolling
        }

        // Close popup when clicking outside the popup content
        window.onclick = function(event) {
            const popup = document.getElementById('imagePopup');
            if (event.target == popup) {
                closePopup();
            }
        }
    </script>
</body>
</html>