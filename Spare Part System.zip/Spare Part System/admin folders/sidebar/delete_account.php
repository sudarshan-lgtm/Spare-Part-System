<?php
require '../../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;
    $type = $_POST['type'] ?? null;

    if (!$id || !$type) {
        echo "Missing parameters.";
        exit;
    }

    $tableMapping = [
        'admin' => 'users',
        'member' => 'member',
        'customer' => 'customer',
        'kolhapur_customer' => 'kolhapur_customer',
        'kolhapur_member' => 'kolhapur_member'
    ];

    if (!array_key_exists($type, $tableMapping)) {
        echo "Invalid type.";
        exit;
    }

    $table = $tableMapping[$type];
    $id = intval($id);

    $stmt = $conn->prepare("DELETE FROM `$table` WHERE id = ?");
    if (!$stmt) {
        echo "Prepare failed.";
        exit;
    }

    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "DB delete error.";
    }

    $stmt->close();
    $conn->close();
} else {
    echo "Invalid request method.";
}
?>