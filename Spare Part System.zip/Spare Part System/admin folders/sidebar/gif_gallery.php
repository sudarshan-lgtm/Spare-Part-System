<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}

    $Directory = "../../admin folders/uploads/folders/";
    $files  = array_diff(scandir($Directory), array('..', '.')); // Get all files in the uploads folder
    
    $gifs = array_filter($files, function ($files) use ($Directory) {
        return preg_match('/\.(gif)$/i', $files); // Adjust formats as needed
    });
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #EEF2FE; /* Light teal */
        }
        .gallery {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            margin-top: 75px;
        }
        .gif-container {
            background: white;
            padding: 10px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            text-align: center;
        }
        img {
            width: 300px;
            height: auto;
            border-radius: 8px;
        }
        p {
            text-align: center;
        }
    </style>
    <script>
        // Disable right-click on the entire page
        document.addEventListener('contextmenu', (event) => event.preventDefault());

        // Prevent screenshot shortcuts
        document.addEventListener('keydown', (event) => {
            if (event.key === "PrintScreen") {
                event.preventDefault();
                alert("Screenshots are disabled.");
            }
            if ((event.ctrlKey && event.key === "s") || (event.metaKey && event.key === "s")) {
                event.preventDefault();
                alert("Saving is disabled.");
            }
            if ((event.ctrlKey && event.key === "p") || (event.metaKey && event.key === "p")) {
                event.preventDefault();
                alert("Printing is disabled.");
            }
        });
    </script>
</head>
<body>
    <?php include("../preloader.html"); ?>
    <?php if (!empty($gifs)): ?>
        <div class="gallery">
            <?php foreach ($gifs as $gifs): ?>
                <div class="gif-container">
                    <source src="<?= $Directory . $gifs; ?>" type="gif">
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p class="no-videos">No GIFs available in the folder.</p>
    <?php endif; ?>
</body>
</html>