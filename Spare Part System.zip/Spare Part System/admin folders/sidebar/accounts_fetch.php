<?php
require '../../db.php';

if (isset($_GET['type'])) {
    $type = $_GET['type'];
    $tableMapping = [
        'admin' => 'users',
        'member' => 'member',
        'customer' => 'customer',
        'kolhapur_customer' => 'kolhapur_customer',
        'kolhapur_member' => 'kolhapur_member'
    ];

    if (!isset($tableMapping[$type])) {
        echo "Invalid selection.";
        exit;
    }

    $table = $tableMapping[$type];

    $sql = "SELECT id, username, password, fullname, email, mobile, dob, status FROM `$table`";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<h2 style='text-align:center; margin-top:20px; color:#333;'>" . ucfirst(str_replace('_', ' ', $type)) . " Accounts</h2>";
        echo "<table border='1' cellspacing='0' cellpadding='10' style='width:80%; margin:auto;'>
                <tr>
                    <th>Username</th>
                    <th class='password-column'>Password</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Mobile</th>
                    <th>Date of Birth</th>
                    <th>Edit</th>
                    <th>Status</th>
                    <th>Delete</th>
                </tr>";
        while ($row = $result->fetch_assoc()) {
            $status = $row['status'];
            $isBlocked = $status == 0;
            echo "<tr id='row_" . $row['id'] . "'>
                    <td>" . htmlspecialchars($row['username']) . "</td>
                    <td class='password-column'>********</td>
                    <td>" . htmlspecialchars($row['fullname']) . "</td>
                    <td>" . htmlspecialchars($row['email']) . "</td>
                    <td>" . htmlspecialchars($row['mobile']) . "</td>
                    <td>" . htmlspecialchars($row['dob']) . "</td>
                    <td><button onclick='editAccount(" . $row['id'] . ")'>Edit</button></td>
                    <td>
                       <button id='blockBtn_" . $row['id'] . "' onclick='blockAccount(" . $row['id'] . ")' 
                            style='display:" . ($isBlocked ? "none" : "inline-block") . ";
                                background-color:#e74c3c;
                                color:white;
                                border:none;
                                padding:8px 10px;
                                border-radius:5px;
                                cursor:pointer;'>Block</button>
                        <button id='unblockBtn_" . $row['id'] . "' onclick='unblockAccount(" . $row['id'] . ")' 
                            style='display:" . ($isBlocked ? "inline-block" : "none") . ";
                                background-color:#2ecc71;
                                color:white;
                                border:none;
                                padding:8px 10px;
                                border-radius:5px;
                                cursor:pointer;'>Unblock</button>
                    </td>
                    <td>
                        <button onclick='deleteAccount(" . $row['id'] . ", \"$type\")' style='background-color:#c0392b; color:white; border:none; padding:8px 10px; border-radius:5px;'>Delete</button>
                    </td>
                  </tr>";
        }
        echo "</table>";
    } else {
        echo "<p style='text-align:center;'>No records found.</p>";
    }

    $conn->close();
}
?>