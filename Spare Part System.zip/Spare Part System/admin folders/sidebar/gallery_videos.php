<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}

$Directory = "../../admin folders/uploads/folders/";
    $videos  = array_diff(scandir($Directory), array('..', '.')); // Get all files in the uploads folder
    
    $videos = array_filter($videos, function ($video) use ($Directory) {
        return preg_match('/\.(mp4|avi|mov|mkv)$/i', $video); // Adjust formats as needed
    });
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #EEF2FE; /* Light teal */
        }
        .gallery {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            margin-top: 75px;
        }
        .video-container {
            background: white;
            padding: 10px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            text-align: center;
        }
        video {
            width: 300px;
            height: auto;
            border-radius: 8px;
        }
        p {
            text-align: center;
        }
    </style>
    <script>
        // Disable right-click on the entire page
        document.addEventListener('contextmenu', (event) => event.preventDefault());

        // Prevent screenshot shortcuts
        document.addEventListener('keydown', (event) => {
            if (event.key === "PrintScreen") {
                event.preventDefault();
                alert("Screenshots are disabled.");
            }
            if ((event.ctrlKey && event.key === "s") || (event.metaKey && event.key === "s")) {
                event.preventDefault();
                alert("Saving is disabled.");
            }
            if ((event.ctrlKey && event.key === "p") || (event.metaKey && event.key === "p")) {
                event.preventDefault();
                alert("Printing is disabled.");
            }
        });
    </script>
</head>
<body> 
<?php include("../preloader.html"); ?>
    <?php if (!empty($videos)): ?>
        <div class="gallery">
            <?php foreach ($videos as $video): ?>
                <div class="video-container">
                    <video controls>
                        <source src="<?= $Directory . $video; ?>" type="video/mp4">
                    </video>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p class="no-videos">No videos available in the folder.</p>
    <?php endif; ?>
</body>
</html>