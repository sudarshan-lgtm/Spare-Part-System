<?php
session_start();
$pdo = new PDO("mysql:host=127.0.0.1:3306;dbname=u494849712_part", "u494849712_patilnagesh007", "Password@1381");

// Insert slogan
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['slogan'])) {
    $slogan = trim($_POST['slogan']);
    if (!empty($slogan)) {
        $stmt = $pdo->prepare("INSERT INTO slogans (text) VALUES (:slogan)");
        $stmt->execute(['slogan' => $slogan]);
         $stmt->closeCursor();
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
}

// Select a slogan
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['select_slogan'])) {
    $selected = trim($_POST['select_slogan']);
    $pdo->exec("UPDATE slogans SET is_selected = 0");
    $stmt = $pdo->prepare("UPDATE slogans SET is_selected = 1 WHERE text = :text");
    $stmt->execute(['text' => $selected]);
     $stmt->closeCursor();
    exit;
}

// Fetch all slogans
$stmt = $pdo->query("SELECT * FROM slogans ORDER BY id DESC");
$slogans = $stmt->fetchAll(PDO::FETCH_ASSOC);
$stmt->closeCursor();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Slogan Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .slogan-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            cursor: pointer;
        }
        .slogan-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
        }
        .slogan-hover {
            padding: 20px;
            background: linear-gradient(135deg, #e3f2fd, #ffffff);
            border-left: 4px solid #0d6efd;
            transition: background 0.3s ease;
        }
        .slogan-hover:hover {
            background: linear-gradient(135deg, #d0ebff, #ffffff);
        }
        .delete-btn {
            position: absolute;
            top: 10px;
            right: 10px;
        }
    </style>
</head>
<body>

<div class="container py-5">
    <h2 class="text-center mb-4 text-primary fw-bold">✨ Add a New Slogan</h2>

    <form method="post" class="row justify-content-center mb-5">
        <div class="col-md-6">
            <div class="input-group shadow-sm">
                <input type="text" name="slogan" class="form-control form-control-lg" placeholder="Enter your awesome slogan..." required>
                <button type="submit" class="btn btn-primary btn-lg">Add ➕</button>
            </div>
        </div>
    </form>

    <h3 class="text-center text-success mb-4">💡 Suggestions</h3>
    
    <div class="row justify-content-center">
        <?php foreach ($slogans as $s): ?>
            <div class="col-md-8 mb-3">
                <div class="card slogan-card shadow-sm border-0" onclick="selectSlogan('<?= htmlspecialchars($s['text']) ?>')">
                    <div class="card-body bg-light rounded-3 slogan-hover">
                        <h5 class="card-text text-center m-0">
                            <?= htmlspecialchars($s['text']) ?>
                            <?php if ($s['is_selected']): ?>
                                <span class="badge bg-success ms-2">Selected</span>
                            <?php endif; ?>
                        </h5>
                        <form method="post" action="delete_slogan.php" onsubmit="return confirm('Are you sure you want to delete this slogan?');" class="delete-btn">
                            <input type="hidden" name="delete_id" value="<?= $s['id'] ?>">
                            <button type="submit" class="btn btn-sm btn-danger">🗑️</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<script>
function selectSlogan(text) {
    fetch('slogan.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'select_slogan=' + encodeURIComponent(text)
    }).then(() => {
        window.location.href = 'slogan.php';
    });
}
</script>
</body>
</html>
