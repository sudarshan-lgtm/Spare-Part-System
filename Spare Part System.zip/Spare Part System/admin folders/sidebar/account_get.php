<?php
require '../../db.php';

if (isset($_GET['id']) && isset($_GET['type'])) {
    $id = $_GET['id'];
    $type = $_GET['type'];

    // Mapping user type to the correct table
    $tableMapping = [
        'admin' => 'users',
        'member' => 'member',
        'customer' => 'customer',
        'kolhapur_customer' => 'kolhapur_customer',
        'kolhapur_member' => 'kolhapur_member'
    ];

    if (!isset($tableMapping[$type])) {
        echo json_encode(["error" => "Invalid selection."]);
        exit;
    }

    $table = $tableMapping[$type];

    // Fetch user details
    $sql = "SELECT id, username, password, fullname, email, mobile, dob FROM $table WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();

    if ($data) {
        // Password should be already hashed in the database
        $data['password'] = '********'; // Hide password from frontend response
    }
        echo json_encode($data);
        
    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["error" => "Invalid request."]);
}
?>
