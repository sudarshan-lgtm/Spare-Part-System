<?php
require '../../db.php';

if (isset($_POST['id'], $_POST['type'], $_POST['action'])) {
    $id = intval($_POST['id']);
    $type = $_POST['type'];
    $action = $_POST['action'];

    $tableMapping = [
        'admin' => 'users',
        'member' => 'member',
        'customer' => 'customer',
        'kolhapur_customer' => 'kolhapur_customer',
        'kolhapur_member' => 'kolhapur_member'
    ];

    if (!isset($tableMapping[$type])) {
        echo "Invalid table.";
        exit;
    }

    $table = $tableMapping[$type];
    $newStatus = ($action === "block") ? 0 : 1;

    $stmt = $conn->prepare("UPDATE $table SET status = ? WHERE id = ?");
    $stmt->bind_param("ii", $newStatus, $id);

    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "error";
    }

    $stmt->close();
    $conn->close();
}
?>
