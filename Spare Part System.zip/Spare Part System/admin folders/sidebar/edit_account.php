<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../sidebar/css/service.css">
    <title>Edit Account</title>
    <style>
       body {
            background-color: #EEF2FE; /* Light teal */
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #4CAF50, #2E7D32);
            color: white;
            border-radius: 50%;
            text-decoration: none;
            font-size: 22px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
            position: fixed; /* Optional: fixed position */
            top: 10px;
            left: 20px;
            z-index: 999;
        }
        
        .back-button:hover {
            background: linear-gradient(135deg, #66BB6A, #388E3C);
            transform: scale(1.1);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.3);
            color: #fff;
        }
        .container {
            width: 90%;
            margin: 20px auto;
            overflow-x: auto; /* Enables horizontal scrolling on small screens */
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 1);
        }
        th, td {
            padding: 12px;
            text-align: left;
            background-color: #fff;
            white-space: nowrap; /* Prevents text wrapping */
            border-collapse: collapse;
        }
        th {
            background-color: #007BFF;
            color: white;
            text-transform: uppercase;
            border: 2px solid black;
        }
        .password-column {
            width: 120px; /* Adjust width as needed */
            max-width: 120px;
            overflow: hidden;
            text-overflow: ellipsis; /* Adds "..." if text overflows */
            white-space: nowrap; /* Prevents text from wrapping */
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #e9ecef;
        }
        button {
            border: none;
            border-radius: 5px;
            padding: 12px;
            margin: 15px;
            width: auto;
            background-color: #007BFF;
            color: white;
            cursor: pointer;
            transition: 0.3s ease-in-out;
        }
        button:hover {
            background-color: #0056b3;
        }
        select {
            padding: 10px;
            width: 30%;
            margin: 20px;
            border-radius: 5px;
            border: 1px solid #ccc;
            background: white;
            cursor: pointer;
        }
        #accountTable {
            display: none;
            margin-top: 20px;
        }
        /* Modal Background */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            max-width: 1800px;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            justify-content: center !important;
            align-items: center !important;
            overflow-x: auto;
        }
        /* Modal Content */
        .modal-content {
            background: white;
            padding: 20px !important;
            border-radius: 10px;
            width: 50%;
            max-width: 600px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.3);
            animation: fadeIn 0.3s ease-in-out;
        }
        /* Modal Heading */
        .modal-content h3 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 1.5em;
        }
        /* Input Fields */
        .modal-content input {
            width: 90%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1em;
        }
        /* Buttons */
        .modal-content button {
            width: 90%;
            padding: 12px;
            margin-top: 10px;
            border: none;
            border-radius: 5px;
            background-color: #007BFF;
            color: white;
            font-size: 1em;
            cursor: pointer;
            transition: background 0.3s;
        }
        .modal-content button:hover {
            background-color: #0056b3;
        }
       /* Responsive Design */
        @media (max-width: 1200px) {
            .modal-content {
                width: 60%;
            }
        
            form h3 {
                font-size: 1.5rem;
            }
        
            input, select, textarea, button {
                font-size: 1rem;
            }
        }
        
        /* 1024px and below - Medium Laptops/Tablets */
        @media (max-width: 1024px) {
            .modal-content {
                width: 70%;
            }
        
            form h3 {
                font-size: 1.4rem;
                text-align: center;
                margin-left: 0;
            }
        
            label {
                font-size: 1rem;
            }
        
            input, select, textarea, button {
                font-size: 0.95rem;
            }
        }
        
        /* 768px and below - Small Tablets */
        @media (max-width: 768px) {
            .modal-content {
                width: 80%;
                padding: 20px;
            }
        
            form h3 {
                font-size: 1.3rem;
            }
        
            input, select, textarea, button {
                width: 100%;
                font-size: 0.95rem;
                padding: 10px;
            }
        
            label {
                font-size: 0.95rem;
            }
        }
        
        /* 600px and below - Large Phones */
        @media (max-width: 600px) {
            .modal-content {
                width: 90%;
                margin: 20% auto;
                padding: 15px;
            }
        
            form h3 {
                font-size: 1.2rem;
                text-align: center;
            }
        
            label {
                display: block;
                font-size: 0.9rem;
                margin-left: 0;
            }
        
            input, select, textarea, button {
                width: 100%;
                font-size: 0.9rem;
                padding: 10px;
            }
        }
        
        /* 480px and below - Phones */
        @media (max-width: 480px) {
            .modal-content {
                width: 95%;
                margin: 25% auto;
                padding: 10px;
            }
        
            form h3 {
                font-size: 1rem;
            }
        
            label, input, button {
                font-size: 0.85rem;
            }
        
            button {
                width: 100%;
                margin-bottom: 10px;
            }
        }


        /* Smartphone and Tablet (Landscape Mode) */
        @media screen and (max-width: 912px) and (orientation: landscape) {
            table {
                width: 100%;
                font-size: 14px;
            }
            th, td {
                padding: 8px;
                font-size: 12px;
            }
            .modal-content {
                width: 60%;
            }
        }
        /* Fade-in Animation */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
    <?php include("../preloader.html"); ?>
<form class="container mt-4">
    <h3 class="mb-3 text-center text-md-start">Change And Edit Details Of Accounts</h3>

    <div class="row mb-3">
        <div class="col-12 col-md-6">
            <label for="accountType" class="form-label">Select Account Type:</label>
            <select id="accountType" class="form-select" onchange="fetchAccounts()">
                <option value="">-- Select --</option>
                <option value="admin">Admin</option>
                <option value="member">Member</option>
                <option value="customer">Customer</option>
                <option value="kolhapur_customer">Kolhapur Customer</option>
                <option value="kolhapur_member">Kolhapur Member</option>
            </select>
        </div>
    </div>
</form>

<div class="container mb-5">
    <div id="accountTable" class="table-responsive"></div>
</div>

<!-- Edit Modal -->
<div id="editModal" class="modal fade" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content p-4">
            <h3 class="mb-3">Edit Account</h3>
            <form id="editForm">
                <input type="hidden" id="editId" name="id">
                <input type="hidden" id="editType" name="type">
                
                <div class="mb-3">
                    <label class="form-label">Username:</label>
                    <input type="text" id="editUsername" name="username" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Password:</label>
                    <input type="text" id="editPassword" name="password" class="form-control" placeholder="Enter New Password" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Full Name:</label>
                    <input type="text" id="editFullname" name="fullname" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Email:</label>
                    <input type="email" id="editEmail" name="email" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Mobile:</label>
                    <input type="text" id="editMobile" name="mobile" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Date of Birth:</label>
                    <input type="date" id="editDob" name="dob" class="form-control" required>
                </div>

                <div class="d-flex justify-content-end gap-2">
                    <button type="button" class="btn btn-primary" onclick="saveAccount()">Save</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onclick="closeModal()">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Fetch Accounts Select
    function fetchAccounts() {
        let type = document.getElementById("accountType").value;
        if (type !== "") {
            fetch(`accounts_fetch.php?type=${type}`)
            .then(response => response.text())
            .then(data => {
                document.getElementById("accountTable").innerHTML = data;
                document.getElementById("accountTable").style.display = "block";
            });
        } else {
             document.getElementById("accountTable").style.display = "none";
        }
    }
//Edit Accounts
    function editAccount(id) {
    let type = document.getElementById("accountType").value;
    fetch(`account_get.php?id=${id}&type=${type}`)
    .then(response => response.json())
    .then(data => {
        document.getElementById("editId").value = data.id;
        document.getElementById("editType").value = type;
        document.getElementById("editUsername").value = data.username;
        document.getElementById("editFullname").value = data.fullname;
        document.getElementById("editEmail").value = data.email;
        document.getElementById("editMobile").value = data.mobile;
        document.getElementById("editDob").value = data.dob;
        document.getElementById("editModal").style.display = "block";
    });
}
//Close form
    function closeModal() {
        document.getElementById("editModal").style.display = "none";
    }
//Save Data
    function saveAccount() {
        let formData = new FormData(document.getElementById("editForm"));

        fetch("account_edit.php", {
            method: "POST",
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            if (data === "success") {
                alert("Account updated successfully!");
                closeModal();
                fetchAccounts(); // Refresh table
            } else {
                alert("Error updating account.");
            }
        });
    }
    document.addEventListener("keydown", function(event) {
        const activeElement = document.activeElement;
        
        // Check if the active element is an input field
        if (event.key === "Backspace" && (activeElement.tagName !== "INPUT" && activeElement.tagName !== "TEXTAREA")) {
            event.preventDefault();
            window.history.back(); 
        }
    });
    
    // Triggered by each “Delete” button
    window.deleteAccount = function(id){
      const type = document.getElementById('accountType').value;
      if(!confirm('Are you sure you want to delete this account?')) return;
      fetch('delete_account.php', {
         method:'POST',
         headers:{'Content-Type':'application/x-www-form-urlencoded'},
         body:'id='+encodeURIComponent(id)+'&type='+encodeURIComponent(type)
      })
      .then(r=>r.text())
      .then(resp=>{
           if(resp.trim()==='success'){ document.getElementById('row_'+id)?.remove(); }
           else alert(resp);
      })
      .catch(err=>alert(err));
    };
</script>
<script>
    function blockAccount(id) {
    let type = document.getElementById("accountType").value;
    fetch("account_status.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `id=${id}&type=${type}&action=block`
    })
    .then(res => res.text())
    .then(data => {
        if (data === "success") {
            document.getElementById(`blockBtn_${id}`).style.display = "none";
            document.getElementById(`unblockBtn_${id}`).style.display = "inline-block";
        } else {
            alert("Error blocking account.");
        }
    });
}

function unblockAccount(id) {
    let type = document.getElementById("accountType").value;
    fetch("account_status.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `id=${id}&type=${type}&action=unblock`
    })
    .then(res => res.text())
    .then(data => {
        if (data === "success") {
            document.getElementById(`unblockBtn_${id}`).style.display = "none";
            document.getElementById(`blockBtn_${id}`).style.display = "inline-block";
        } else {
            alert("Error unblocking account.");
        }
    });
}

</script>
</body>
</html>