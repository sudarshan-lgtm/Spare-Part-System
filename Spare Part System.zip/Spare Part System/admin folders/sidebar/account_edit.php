<?php
require '../../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $dob = $_POST['dob'];
    $type = $_POST['type'];

    // Mapping user type to the correct table
    $tableMapping = [
        'admin' => 'users',
        'member' => 'member',
        'customer' => 'customer',
        'kolhapur_customer' => 'kolhapur_customer',
        'kolhapur_member' => 'kolhapur_member'
    ];

    if (!isset($tableMapping[$type])) {
        echo "Invalid selection.";
        exit;
    }

    $table = $tableMapping[$type];
    // Fetch existing password from database
    $sql = "SELECT password FROM $table WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($existingPassword);
    $stmt->fetch();
    $stmt->close();

    // Check if a new password is provided
    if (!empty($password)) {
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT); // Hash new password
    } else {
        $hashedPassword = $existingPassword; // Keep old password if not changed
    }

    // Update query
    $sql = "UPDATE $table SET username=?, password=?, fullname=?, email=?, mobile=?, dob=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssi", $username, $hashedPassword, $fullname, $email, $mobile, $dob, $id);

    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "error";
    }

    $stmt->close();
    $conn->close();
}
?>
