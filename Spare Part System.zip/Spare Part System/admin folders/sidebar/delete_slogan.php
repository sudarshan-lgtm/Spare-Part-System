<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    try {
        // Database connection
        $pdo = new PDO("mysql:host=127.0.0.1:3306;dbname=u494849712_part", "u494849712_patilnagesh007", "Password@1381");
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Correct DELETE query with parameterized statement
        $stmt = $pdo->prepare("DELETE FROM slogans WHERE id = :id");
        $stmt->execute(['id' => $_POST['delete_id']]);

        $stmt->closeCursor();
        
        if ($stmt->rowCount() > 0) {
            $stmt->closeCursor();
            // Successfully deleted the slogan
            header('Location: slogan.php');
            exit();
        } else {
            echo "No slogan found with that ID.";
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    echo "Invalid Request";
}
?>
