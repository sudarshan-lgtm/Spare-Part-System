<?php
session_start();
include '../db.php'; // Database connection

if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}

    // Handle form submission
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $product = isset($_POST['product']) ? trim($_POST['product']) : '';
        $discount = isset($_POST['discount']) ? intval($_POST['discount']) : 0;
        $module = isset($_POST['module']) ? trim($_POST['module']) : '';

        if (!empty($product) && $discount > 0 && !empty($module)) {
            // Insert or update offer
            $query = "INSERT INTO offers (Product, Discount, Module) 
                    VALUES (?, ?, ?) 
                    ON DUPLICATE KEY UPDATE Discount = VALUES(Discount), Module = VALUES(Module)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("sis", $product, $discount, $module);
            if ($stmt->execute()) {
                echo "<script>alert('Offer added successfully!');</script>;
                      <script>window.location.href='add_offers.php';</script>"; // Refresh page
                      $stmt->close();
                exit;
            } else {
                echo "<script>alert('Error adding offer!');</script>";
            }
            $stmt->close();
        } else {
            echo "<script>alert('Please select a product, enter a valid discount, and select a module.');</script>";
        }
    }
    // Handle offer deletion
    if (isset($_GET['delete'])) {
        $offerId = intval($_GET['delete']);
        $query = "DELETE FROM Offers WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $offerId);
        if ($stmt->execute()) {
            echo "<script>alert('Offer deleted successfully!');</script>;
                <script>window.location.href='add_offers.php';</script>"; // Refresh page
                $stmt->close();
            exit;
        }
        $stmt->close();
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Offers</title>
    <link rel="stylesheet" href="../admin folders/css/offers.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
</head>
<body>
    <?php include("preloader.html"); ?>
    <h2>Add Offers</h2>
    <nav class="navbar">
    <a href='admin_dashboard.php' class='back-button'><img src="../image/h1.png" class="home" alt="ok"></a>
    <img src="../image/RJ bg.png" class="logo" alt="RJ">
    </nav>
    <form method="POST">
        <label for="product">Select Product:</label>
        <select name="product" id="productDropdown" required style="width: 100%;">
            <option value="">--Select Product--</option>
        </select>
        <label for="discount">Offer Percentage:</label>
        <input type="number" name="discount" required min="1" max="100" oninput="validateNumbers(this)">
        <label for="module">Select Module:</label>
        <select name="module" required>
            <option value="">--Select Module--</option>
            <option value="Customer">Customer</option>
            <option value="Member">Member</option>
            <option value="Kolhapur_Customer">Kolhapur Customer</option>
            <option value="Kolhapur_Member">Kolhapur Member</option>
        </select>
        <button type="submit">Save Offer</button>
    </form>
    <h2>Existing Offers</h2>

    <div id="offers-container">
        <?php
        $modules = ["Customer", "Member", "Kolhapur_Customer", "Kolhapur_Member"];
        foreach ($modules as $module) {
            echo "<h3>$module Offers</h3>";
            echo "<table border='1'>";
            echo "<tr><th>Product</th><th>Discount (%)</th><th>Actions</th></tr>";

            $offersQuery = "SELECT * FROM offers WHERE Module = ?";
            $stmt = $conn->prepare($offersQuery);
            $stmt->bind_param("s", $module);
            $stmt->execute();
            $offersResult = $stmt->get_result();

            if ($offersResult->num_rows > 0) {
                while ($offer = $offersResult->fetch_assoc()) {
                    echo "<tr>
                            <td>{$offer['Product']}</td>
                            <td>{$offer['Discount']}%</td>
                            <td>
                                <a href='?delete=" . urlencode($offer['id']) . "' onclick='return confirm(\"Are you sure you want to delete this offer?\")'>Delete</a>
                            </td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='3'>No offers available for $module</td></tr>";
            }
            
            $offersResult->close(); // <-- added
            $stmt->close();

            echo "</table>";
        }
        ?>
    </div>
    <script>
         $(document).ready(function () {
        // Initialize select2 dropdown
        $("#productDropdown").select2({
            placeholder: "--Search Product--",
            minimumInputLength: 1,
            ajax: {
                url: "add_offers_fetch.php",
                type: "GET",
                dataType: "json",
                delay: 250,
                data: function (params) {
                    return { q: params.term };
                },
                processResults: function (data) {
                    return { results: data };
                },
                cache: true
            }
        });

        // Fetch and display offers based on the selected module
        function fetchOffers(module) {
                $.ajax({
                    url: "add_offers_fetch.php",
                    type: "GET",
                    data: { module: module },
                    dataType: "json",
                    success: function (data) {
                        let offersTable = $("#offersTable");
                        offersTable.empty();

                        if (data.length === 0) {
                            offersTable.append("<tr><td colspan='4'>No offers available for this module.</td></tr>");
                        } else {
                            data.forEach(function (offer) {
                                offersTable.append(`
                                    <tr>
                                        <td>${offer.product}</td>
                                        <td>${offer.discount}%</td>
                                        <td>${offer.module}</td>
                                        <td>
                                            <a href="?delete=${offer.id}" onclick="return confirm('Are you sure?')">Delete</a>
                                        </td>
                                    </tr>
                                `);
                            });
                        }
                    }
                });
            }

            $("#moduleDropdown").change(function () {
                let selectedModule = $(this).val();
                fetchOffers(selectedModule);
            });

            fetchOffers($("#moduleDropdown").val());
        });

//Validation
        function validateNumbers(input)  {
            input.value = input.value.replace(/[^0-9]/g, '').substring(0,3);
        }
//Shortcut Key
        document.addEventListener("keydown", function(event) {
            const activeElement = document.activeElement;
            
            // Check if the active element is an input field
            if (event.key === "Backspace" && (activeElement.tagName !== "INPUT" && activeElement.tagName !== "TEXTAREA")) {
                event.preventDefault();
                window.history.back(); 
            }
        });
    </script>
</body>
</html>