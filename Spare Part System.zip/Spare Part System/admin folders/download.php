<?php
session_start();
include '../db.php';

if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}

$query = "SELECT ProductGroup, Product, Company, PartNo, SaleRate FROM productinventory";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="../admin folders/css/download.css">
    <title>Download Data</title>
</head>
<body>
    <?php include("preloader.html"); ?>
<a href='admin_dashboard.php' class='back-button'><img src="../image/h1.png" class="home" alt="ok"></a>
    <h2>Downloaded Data</h2>
    <div class="download-links">
        <a href="download_data.php?type=excel">Download Excel</a>
        <a href="download_data.php?type=pdf">Download PDF</a>
        <a href="download_data.php?type=csv">Download CSV</a>
    </div>
    <div class="search-container">
        <input type="text" id="searchInput" class="searchInput" placeholder="Search the data" style="float:right; margin-top: 80px; margin-right: 10px; padding: 8px;">
        <button id="searchButton" class="searchButton" style="padding: 10px; margin-top: 80px; float:right;">Search</button>
    </div>
    <div class="table-container">
    <table id="dataTable">
        <tr>
            <!--<th>Sr. No</th>-->
            <th>Product Group</th>
            <th>Product</th>
            <th>Company</th>
            <th>Part No</th>
            <th>Sale Rate</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) : ?>
            <tr>
                <!--<td><?= htmlspecialchars($row['']) ?></td>-->
                <td><?= htmlspecialchars($row['ProductGroup']) ?></td>
                <td><?= htmlspecialchars($row['Product']) ?></td>
                <td><?= htmlspecialchars($row['Company']) ?></td>
                <td><?= htmlspecialchars($row['PartNo']) ?></td>
                <td><?= htmlspecialchars($row['SaleRate']) ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
    </div>
    <script>
        function searchTable() {
            let filter = document.getElementById('searchInput').value.toLowerCase();
            let rows = document.querySelectorAll('#dataTable tbody tr');

            rows.forEach(row => {
                let text = row.textContent.toLowerCase();
                row.style.display = text.includes(filter) ? '' : 'none';
            });
        }

        // Search when button is clicked
        document.getElementById('searchButton').addEventListener('click', searchTable);

        // Search when Enter key is pressed inside the search input
        document.getElementById('searchInput').addEventListener('keypress', function(event) {
            if (event.key === 'Enter') {
                searchTable();
            }
        });
//Shortcut Key
        document.addEventListener("keydown", function(event) {
            const activeElement = document.activeElement;
            
            // Check if the active element is an input field
            if (event.key === "Backspace" && (activeElement.tagName !== "INPUT" && activeElement.tagName !== "TEXTAREA")) {
                event.preventDefault();
                window.history.back(); 
            }
        });
    </script>
</body>
</html>
