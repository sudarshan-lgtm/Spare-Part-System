<?php
include '../db.php';
// Fetch last 7 days orders
$sql = "SELECT  Product, SaleRate, UpdatedSaleRate, DATE(UpdatedSaleRate) as update_date FROM submitted_orders WHERE 
    UpdatedSaleRate >= CURDATE() - INTERVAL 7 DAY 
    ORDER BY update_date DESC";

$result = $conn->query($sql);

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[$row['order_date']] = $row['order_count'];
}

// Return data as JSON
echo json_encode($data);
$conn->close();
?>
