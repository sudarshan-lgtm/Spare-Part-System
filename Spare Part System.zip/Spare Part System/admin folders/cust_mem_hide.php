<?php
session_start();
include '../db.php';

// Admin authentication check
if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}

// Get the current visibility status from the database
$query = "SELECT download_visibility FROM settings WHERE id = 1";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);
$current_visibility = $row ? $row['download_visibility'] : 0;

// Function to get column names based on user type
function getColumnsByUserType($userType) {
    global $conn;
    $table = in_array($userType, ['kolhapur_member', 'kolhapur_customer']) ? 'kolhapurdata' : 'productinventory';
    $query = "DESCRIBE $table";
    $result = mysqli_query($conn, $query);
    $columns = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $columns[] = $row['Field'];
    }
    return $columns;
}

// Function to fetch users by type
function getUsersByType($userType) {
    global $conn;
    $query = "SELECT id, fullname FROM $userType";
    $result = mysqli_query($conn, $query);
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

// Function to check hidden columns for a specific user and user type
function getHiddenColumns($userType, $userId) {
    global $conn;
    $query = "SELECT column_name FROM hiddencolumns WHERE user_type = ? AND user_id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "si", $userType, $userId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $hiddenColumns = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $hiddenColumns[] = $row['column_name'];
    }
    mysqli_stmt_close($stmt);
    return $hiddenColumns;
}

// Function to check if a column is already hidden for a user and user type
function isColumnHidden($column, $userType, $userId) {
    global $conn;
    $query = "SELECT COUNT(*) as count FROM hiddencolumns WHERE column_name = ? AND user_type = ? AND user_id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "ssi", $column, $userType, $userId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);
    return $row['count'] > 0;
}

// Function to hide default columns for new customer/kolhapur_customer accounts
function hideDefaultColumns($userType, $userId) {
    global $conn;
    if (!in_array($userType, ['customer', 'kolhapur_customer'])) {
        return; // Only apply to customer and kolhapur_customer
    }
    $defaultHiddenColumns = [
        'Batch', 'PurchaseRate', 'Exp', 'Margin', 'PurchaseCode',
        'SaleRate', 'ReceiptQty', 'IssueQty', 'ClosingQty', 'Location'
    ];
    $inserted = false;
    foreach ($defaultHiddenColumns as $column) {
        if (!isColumnHidden($column, $userType, $userId)) {
            $query = "INSERT INTO hiddencolumns (column_name, user_type, user_id) VALUES (?, ?, ?)";
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, "ssi", $column, $userType, $userId);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            $inserted = true;
        }
    }
    return $inserted;
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle hide/unhide columns
    if (isset($_POST['hide_data']) || isset($_POST['unhide_data'])) {
        $userType = $_POST['user_type'] ?? '';
        $selectedUser = $_POST['selected_user'] ?? null;
        $selectedColumns = $_POST['columns'] ?? [];
        $new_visibility = $_POST['download_visibility'] ?? $current_visibility;

        // Update download visibility status
        $updateQuery = "UPDATE settings SET download_visibility = ? WHERE id = 1";
        $stmt = mysqli_prepare($conn, $updateQuery);
        mysqli_stmt_bind_param($stmt, "i", $new_visibility);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        if ($userType && $selectedUser && !empty($selectedColumns)) {
            if (isset($_POST['hide_data'])) {
                $inserted = false;
                foreach ($selectedColumns as $column) {
                    $column = mysqli_real_escape_string($conn, $column);
                    if (!isColumnHidden($column, $userType, $selectedUser)) {
                        $query = "INSERT INTO hiddencolumns (column_name, user_type, user_id) VALUES (?, ?, ?)";
                        $stmt = mysqli_prepare($conn, $query);
                        mysqli_stmt_bind_param($stmt, "ssi", $column, $userType, $selectedUser);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);
                        $inserted = true;
                    }
                }
                if ($inserted) {
                    echo "<script>alert('Selected columns hidden successfully.'); window.location='cust_mem_hide.php';</script>";
                } else {
                    echo "<script>alert('No new columns were hidden as they are already hidden.'); window.location='cust_mem_hide.php';</script>";
                }
            } elseif (isset($_POST['unhide_data'])) {
                foreach ($selectedColumns as $column) {
                    $column = mysqli_real_escape_string($conn, $column);
                    $query = "DELETE FROM hiddencolumns WHERE column_name = ? AND user_type = ? AND user_id = ?";
                    $stmt = mysqli_prepare($conn, $query);
                    mysqli_stmt_bind_param($stmt, "ssi", $column, $userType, $selectedUser);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                }
                echo "<script>alert('Selected columns unhidden successfully.'); window.location='cust_mem_hide.php';</script>";
            }
        }
    }

    // Handle account creation (for testing or admin acceptance)
    if (isset($_POST['create_account'])) {
        $newUserType = $_POST['new_user_type'] ?? '';
        $fullname = $_POST['fullname'] ?? '';
        if ($newUserType && $fullname && in_array($newUserType, ['customer', 'kolhapur_customer'])) {
            // Insert new user into the appropriate table
            $query = "INSERT INTO $newUserType (fullname) VALUES (?)";
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, "s", $fullname);
            mysqli_stmt_execute($stmt);
            $newUserId = mysqli_insert_id($conn);
            mysqli_stmt_close($stmt);

            // Hide default columns
            if (hideDefaultColumns($newUserType, $newUserId)) {
                echo "<script>alert('Account created and default columns hidden successfully.'); window.location='cust_mem_hide.php';</script>";
            } else {
                echo "<script>alert('Account created, but no new columns hidden (already hidden).'); window.location='cust_mem_hide.php';</script>";
            }
        } else {
            echo "<script>alert('Invalid user type or missing fullname.'); window.location='cust_mem_hide.php';</script>";
        }
    }
}

// Get hidden columns for the selected user and type (if provided)
$hiddenColumns = [];
if (!empty($_POST['user_type']) && !empty($_POST['selected_user'])) {
    $hiddenColumns = getHiddenColumns($_POST['user_type'], $_POST['selected_user']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <title>Visibility Functions</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 10px;
            box-sizing: border-box;
            overflow-x: auto;
            background-color: #EEF2FE;
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            color: white;
            border-radius: 50%;
            text-decoration: none;
            font-size: 22px;
            transition: all 0.3s ease;
            position: fixed;
            top: 10px;
            left: 20px;
            z-index: 999;
        }
        .back-button:hover {
            transform: scale(1.1);
            color: #fff;
        }
        .back-button .home {
            height: 55px;
            width: auto;
            margin-right: 10px;
            vertical-align: middle;
            object-fit: contain;
        }
        h2 {
            text-align: center;
            margin-top: 30px;
            margin-bottom: 30px;
            color: #333;
        }
        form {
            width: 90%;
            max-width: 500px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            background-color: #fff;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.90);
        }
        label {
            display: block;
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 5px;
            color: #333;
        }
        select, input[type="text"] {
            width: 100%;
            padding: 8px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #fff;
            cursor: pointer;
            transition: border-color 0.3s ease-in-out;
        }
        select:focus, input[type="text"]:focus {
            border-color: #007bff;
            outline: none;
        }
        #user_type {
            margin-bottom: 15px;
        }
        table {
            width: 100%;
            margin: 20px auto;
            border-collapse: collapse;
            text-align: center;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        button {
            padding: 10px;
            margin-top: 20px;
            background-color: rgba(0, 89, 255, 0.83);
            border: none;
            border-radius: 4px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.7);
            transition: transform 0.3s ease-in-out;
            display: block;
            width: 100%;
            max-width: 200px;
            margin-left: auto;
            margin-right: auto;
            color: white;
            cursor: pointer;
        }
        button:hover {
            background-color: rgb(0, 29, 214);
            transform: scale(1.05);
        }
        .unhide-btn {
            background-color: #28a745;
        }
        .unhide-btn:hover {
            background-color: #1e7e34;
        }
        .create-btn {
            background-color: #ff9800;
        }
        .create-btn:hover {
            background-color: #e68900;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            width: 90%;
            max-width: 350px;
            margin: 30px auto;
            text-align: center;
        }
        input[type="radio"] {
            transform: scale(1.3);
            margin-right: 5px;
        }
        @media (max-width: 768px) {
            table {
                width: 100%;
                font-size: 14px;
            }
            th, td {
                padding: 8px;
            }
            .container {
                width: 95%;
            }
            button {
                width: 100%;
            }
        }
        @media (max-width: 480px) {
            table, thead, tbody, th, td, tr {
                display: block;
            }
            tr {
                margin-bottom: 10px;
                border: 1px solid #ddd;
                padding: 5px;
            }
            td {
                display: flex;
                justify-content: space-between;
                padding: 5px;
                border: none;
                border-bottom: 1px solid #ddd;
            }
            td:last-child {
                border-bottom: none;
            }
        }
        @media (orientation: landscape) and (max-width: 768px) {
            table {
                font-size: 13px;
            }
        }
    </style>
</head>
<body>
    <?php include("preloader.html"); ?>
    <a href='admin_dashboard.php' class='back-button'><img src="../image/h1.png" class="home" alt="ok"></a>
    <h2>Hide/Unhide Data for Specific User</h2>
    <form method="POST">
        <label>Select User Type:</label>
        <select id="user_type" name="user_type" onchange="updateUserDropdown()">
            <option value="">Select Type</option>
            <option value="customer" <?= ($_POST['user_type'] ?? '') == 'customer' ? 'selected' : '' ?>>Customer</option>
            <option value="member" <?= ($_POST['user_type'] ?? '') == 'member' ? 'selected' : '' ?>>Member</option>
            <option value="kolhapur_member" <?= ($_POST['user_type'] ?? '') == 'kolhapur_member' ? 'selected' : '' ?>>Kolhapur Member</option>
            <option value="kolhapur_customer" <?= ($_POST['user_type'] ?? '') == 'kolhapur_customer' ? 'selected' : '' ?>>Kolhapur Customer</option>
        </select>

        <label>Select User:</label>
        <select name="selected_user" id="userDropdown">
            <option value="">Select User</option>
            <?php
            if (!empty($_POST['user_type'])) {
                $users = getUsersByType($_POST['user_type']);
                foreach ($users as $user) {
                    $selected = ($_POST['selected_user'] ?? '') == $user['id'] ? 'selected' : '';
                    echo "<option value='{$user['id']}' $selected>{$user['fullname']}</option>";
                }
            }
            ?>
        </select>
        <table>
            <thead>
                <tr>
                    <th>Select</th>
                    <th>Column Name</th>
                </tr>
            </thead>
            <tbody>
            <?php 
                $columns = getColumnsByUserType($_POST['user_type'] ?? 'customer');
                foreach ($columns as $column): 
                    $isChecked = in_array($column, $hiddenColumns) ? 'checked' : '';
            ?>
                    <tr>
                        <td><input type="checkbox" class="checkbox" name="columns[]" value="<?= htmlspecialchars($column) ?>" <?= $isChecked ?>></td>
                        <td><?= htmlspecialchars($column) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <button type="submit" name="hide_data">Hide Data</button>
        <button type="submit" name="unhide_data" class="unhide-btn">Unhide Data</button>
    </form>

    <div class="container">
        <form method="POST">
            <label>Enable Download Option:</label>
            <label><input type="radio" name="download_visibility" value="1" <?= ($current_visibility == '1') ? 'checked' : '' ?>> ON</label>
            <label><input type="radio" name="download_visibility" value="0" <?= ($current_visibility == '0') ? 'checked' : '' ?>> OFF</label>
            <button type="submit">Save</button>
        </form>        
    </div>

    <!-- New section for creating accounts (for testing or admin acceptance) -->
    <div class="container">
        <h2>Create New Account</h2>
        <form method="POST">
            <label>Select User Type:</label>
            <select name="new_user_type">
                <option value="">Select Type</option>
                <option value="customer">Customer</option>
                <option value="kolhapur_customer">Kolhapur Customer</option>
            </select>
            <label>Full Name:</label>
            <input type="text" name="fullname" placeholder="Enter full name" required>
            <button type="submit" name="create_account" class="create-btn">Create Account</button>
        </form>
    </div>

    <script>
        let users = {
            customer: <?= json_encode(getUsersByType('customer')) ?>,
            member: <?= json_encode(getUsersByType('member')) ?>,
            kolhapur_member: <?= json_encode(getUsersByType('kolhapur_member')) ?>,
            kolhapur_customer: <?= json_encode(getUsersByType('kolhapur_customer')) ?>
        };

        function updateUserDropdown() {
            const userType = document.getElementById("user_type").value;
            const userDropdown = document.getElementById("userDropdown");
            userDropdown.innerHTML = '<option value="">Select User</option>';
            if (userType in users) {
                users[userType].forEach(user => {
                    const option = document.createElement("option");
                    option.value = user.id;
                    option.textContent = user.fullname;
                    userDropdown.appendChild(option);
                });
            }
            // Submit form to refresh column checkboxes
            document.querySelector('form').submit();
        }

        document.addEventListener("keydown", function(event) {
            const activeElement = document.activeElement;
            if (event.key === "Backspace" && (activeElement.tagName !== "INPUT" && activeElement.tagName !== "TEXTAREA")) {
                event.preventDefault();
                window.history.back();
            }
        });

        // Auto-submit form when user is selected to refresh column checkboxes
        document.getElementById("userDropdown").addEventListener("change", function() {
            document.querySelector('form').submit();
        });
    </script>
</body>
</html>