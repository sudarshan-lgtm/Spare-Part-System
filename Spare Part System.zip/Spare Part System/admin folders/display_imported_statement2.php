<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}

try {
    $pdo = new PDO("mysql:host=127.0.0.1:3306;dbname=u494849712_part", "u494849712_patilnagesh007", "Password@1381");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Latest import
$stmt = $pdo->query("SELECT DATE_FORMAT(MAX(created_at), '%Y-%m-%d %H:%i') as latest_import_minute FROM statement_user_name2");
$latest_import_minute = $stmt->fetch(PDO::FETCH_ASSOC)['latest_import_minute'];
$stmt->closeCursor();

$customers = [];
if ($latest_import_minute) {
    $stmt = $pdo->prepare("SELECT * FROM statement_user_name2 WHERE DATE_FORMAT(created_at, '%Y-%m-%d %H:%i') = :latest_import_minute ORDER BY statement_id");
    $stmt->execute([':latest_import_minute' => $latest_import_minute]);
    $customers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Latest Account Statements</title>
    <link rel="icon" href="../image/icon.png" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .summary-row {
            background-color: #f8f9fa;
            font-weight: bold;
        }
        .customer-section {
            border: 1px solid #dee2e6;
            padding: 20px;
            margin-bottom: 30px;
            border-radius: 8px;
            background-color: #ffffff;
            box-shadow: 0 0 10px rgba(0,0,0,0.05);
        }
    </style>
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3">Last Imported Account Statements</h1>
            <a href="admin_dashboard.php" class="btn btn-outline-primary">Back to Dashboard</a>
        </div>

        <div class="mb-4">
            <input type="text" id="searchInput" class="form-control" placeholder="Search by customer name..." onkeyup="filterCustomers()">
        </div>

        <?php if (empty($customers)): ?>
            <div class="alert alert-warning">No data available.</div>
        <?php else: ?>
            <div class="mb-3 text-muted">Showing data from: <strong><?php echo htmlspecialchars($latest_import_minute); ?></strong></div>

            <?php foreach ($customers as $customer): ?>
                <div class="customer-section" data-customer-name="<?php echo htmlspecialchars(strtolower($customer['user_name'])); ?>">
                    <h4><?php echo htmlspecialchars($customer['user_name']); ?></h4>
                    <p>Period: <?php echo htmlspecialchars($customer['from_date']); ?> to <?php echo htmlspecialchars($customer['to_date']); ?></p>

                    <?php
                    $stmt = $pdo->prepare("SELECT * FROM opening_balance2 WHERE statement_id = :statement_id");
                    $stmt->execute([':statement_id' => $customer['statement_id']]);
                    $opening_balance = $stmt->fetch(PDO::FETCH_ASSOC);
                    $stmt->closeCursor();

                    $stmt = $pdo->prepare("SELECT * FROM statement_all_data2 WHERE statement_id = :statement_id ORDER BY date");
                    $stmt->execute([':statement_id' => $customer['statement_id']]);
                    $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    $stmt->closeCursor();

                    $stmt = $pdo->prepare("SELECT * FROM statement_total_amt2 WHERE statement_id = :statement_id");
                    $stmt->execute([':statement_id' => $customer['statement_id']]);
                    $total_amt = $stmt->fetch(PDO::FETCH_ASSOC);
                    $stmt->closeCursor();

                    $stmt = $pdo->prepare("SELECT * FROM closing_balance2 WHERE statement_id = :statement_id");
                    $stmt->execute([':statement_id' => $customer['statement_id']]);
                    $closing_balance = $stmt->fetch(PDO::FETCH_ASSOC);
                    $stmt->closeCursor();
                    ?>

                    <div class="table-responsive">
                        <table class="table table-bordered table-striped table-sm">
                            <thead class="table-dark">
                                <tr>
                                    <th>Date</th>
                                    <th>Doc/Chq. No.</th>
                                    <th>Type</th>
                                    <th>Particulars</th>
                                    <th>Credit</th>
                                    <th>Debit</th>
                                    <th>Closing Balance</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="summary-row">
                                    <td colspan="3"></td>
                                    <td>Opening Balance:</td>
                                    <td><?php echo number_format($opening_balance['credit_amt'] ?? 0, 2); ?></td>
                                    <td><?php echo number_format($opening_balance['debit_amt'] ?? 0, 2); ?></td>
                                    <td><?php echo htmlspecialchars($opening_balance['closer_balance'] ?? 'N/A'); ?></td>
                                </tr>

                                <?php foreach ($transactions as $transaction): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($transaction['date']); ?></td>
                                        <td><?php echo htmlspecialchars($transaction['doc_no'] ?? ''); ?></td>
                                        <td><?php echo htmlspecialchars($transaction['type'] ?? ''); ?></td>
                                        <td><?php echo htmlspecialchars($transaction['particulars']); ?></td>
                                        <td><?php echo $transaction['credit'] !== null ? number_format($transaction['credit'], 2) : ''; ?></td>
                                        <td><?php echo $transaction['debit'] !== null ? number_format($transaction['debit'], 2) : ''; ?></td>
                                        <td><?php echo htmlspecialchars($transaction['closing_balance'] ?? ''); ?></td>
                                    </tr>
                                <?php endforeach; ?>

                                <tr class="summary-row">
                                    <td colspan="3"></td>
                                    <td>Total:</td>
                                    <td><?php echo number_format($total_amt['credit_amt'] ?? 0, 2); ?></td>
                                    <td><?php echo number_format($total_amt['debit_amt'] ?? 0, 2); ?></td>
                                    <td></td>
                                </tr>

                                <tr class="summary-row">
                                    <td colspan="6">Closing Balance:</td>
                                    <td><?php echo htmlspecialchars($closing_balance['closing_balance'] ?? 'N/A'); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <script>
        function filterCustomers() {
            const searchValue = document.getElementById('searchInput').value.toLowerCase();
            const customerSections = document.getElementsByClassName('customer-section');
            for (let i = 0; i < customerSections.length; i++) {
                const name = customerSections[i].getAttribute('data-customer-name');
                customerSections[i].style.display = name.includes(searchValue) ? 'block' : 'none';
            }
        }
    </script>
</body>
</html>
