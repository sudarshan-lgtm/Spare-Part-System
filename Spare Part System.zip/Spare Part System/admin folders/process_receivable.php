<?php
session_start();
require '../vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\IOFactory;

// Prevent accessing this page after logout
if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}

$pdo = new PDO("mysql:host=127.0.0.1:3306;dbname=u494849712_part", "u494849712_patilnagesh007", "Password@1381");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$message = "";
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file']) && $_FILES['file']['error'] === 0) {
    try {
        $spreadsheet = IOFactory::load($_FILES['file']['tmp_name']);
        $data = $spreadsheet->getActiveSheet()->toArray();

        // Minimal file validation
        $valid = false;
        foreach ($data as $row) {
            if (strpos($row[0], "A/c. Receivable Detail Report") !== false) {
                $valid = true;
                break;
            }
        }

        if (!$valid) {
            throw new Exception("Invalid file. Please upload the correct Receivable report.");
        }

        // Initialize variables
        $reportTitle = null;
        $reportDate = null;
        $currentCustomer = null;
        $reportId = null;
        $customerId = null;

        foreach ($data as $row) {
            if (strpos($row[0], "A/c. Receivable Detail Report") !== false) {
                $reportTitle = $row[0];
            }

            if (strpos($row[0], "As On Date") !== false) {
                $dateStr = trim(str_replace("As On Date", "", $row[0]));
                $reportDate = DateTime::createFromFormat('d/m/Y', $dateStr) ?: DateTime::createFromFormat('d-m-Y', $dateStr);
                $reportDate = $reportDate ? $reportDate->format('Y-m-d') : null;

                $stmt = $pdo->prepare("INSERT INTO receivable_report_info (report_title, report_date) VALUES (?, ?)");
                $stmt->execute([$reportTitle, $reportDate]);
                $reportId = $pdo->lastInsertId();
                $stmt->closeCursor();
            }

            if (!empty($row[0]) && empty($row[1]) && empty($row[2]) && !is_numeric($row[0])) {
                $currentCustomer = trim($row[0]);
                $stmt = $pdo->prepare("INSERT INTO receivable_customers (report_id, customer_name) VALUES (?, ?)");
                $stmt->execute([$reportId, $currentCustomer]);
                $customerId = $pdo->lastInsertId();
                $stmt->closeCursor();
                continue;
            }

            if (preg_match('/^\d{2}[\/-]\d{2}[\/-]\d{4}$/', $row[0])) {
                $billDateObj = DateTime::createFromFormat('d/m/Y', $row[0]) ?: DateTime::createFromFormat('d-m-Y', $row[0]);
                $billDate = $billDateObj ? $billDateObj->format('Y-m-d') : null;

                $stmt = $pdo->prepare("INSERT INTO receivable_entries (
                    customer_id, bill_date, bill_no, type, due_days, bill_amount, adv_amount, adjusted_amount, pending_amount, cumulative_balance
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

                $stmt->execute([
                    $customerId,
                    $billDate,
                    $row[1] ?? null,
                    $row[2] ?? null,
                    is_numeric($row[3]) ? $row[3] : null,
                    $row[4] ?? null,
                    $row[5] ?? null,
                    $row[6] ?? null,
                    $row[7] ?? null,
                    $row[8] ?? null
                ]);
                $stmt->closeCursor();
            }

            if (trim($row[0]) === '' && strtolower(trim($row[2])) !== 'opening' && is_numeric($row[3])) {
                $stmt = $pdo->prepare("INSERT INTO receivable_totals (
                    customer_id, due_days, bill_amount, adv_amount, adjusted_amount, pending_amount, cumulative_balance
                ) VALUES (?, ?, ?, ?, ?, ?, ?)");

                $stmt->execute([
                    $customerId,
                    $row[3] ?? null,
                    $row[4] ?? null,
                    $row[5] ?? null,
                    $row[6] ?? null,
                    $row[7] ?? null,
                    $row[8] ?? null
                ]);
                $stmt->closeCursor();
            }
        }
        
        $message = "<div class='alert alert-success text-center mt-3'>✅ Data imported successfully!</div>";

    } catch (Exception $e) {
        $error = "<div class='alert alert-danger text-center mt-3'>❌ " . $e->getMessage() . "</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Upload Receivable Excel</title>
    <link rel="icon" href="../image/icon.png" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'>
    <style>
        .back-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #4CAF50, #2E7D32);
            color: white;
            border-radius: 50%;
            text-decoration: none;
            font-size: 22px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
            position: fixed; /* Optional: fixed position */
            top: 10px;
            left: 20px;
            z-index: 999;
        }
        
        .back-button:hover {
            background: linear-gradient(135deg, #66BB6A, #388E3C);
            transform: scale(1.1);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.3);
            color: #fff;
        }
    </style>
</head>
<?php include("preloader.html"); ?>
<body class="bg-light">
    <a href='admin_dashboard.php' class='back-button'><i class='fa fa-home' aria-hidden='true'></i></a>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow-lg p-4">
                    <h4 class="text-center mb-4">Upload Receivable Excel File</h4>

                    <?= $error ?>
                    <?= $message ?>

                    <form action="" method="post" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="file" class="form-label">Select Excel File:</label>
                            <input type="file" name="file" id="file" class="form-control" required>
                        </div>
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">Upload File</button>
                        </div>
                    </form>
                </div>
                <div class="text-center mt-3">
                    <a href="display_receivable.php" class="btn btn-outline-secondary">Go to Receivable Report</a>
                    <form action='delete_all_receivable.php' method='POST' onsubmit="return confirm('Are you sure you want to delete all data?');">
                        <button type='submit' name='delete_all' class='btn btn-danger mt-3'>
                            Delete All Receivable Data
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
