<?php
include '../db.php'; // Connect your database

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $submit_id = $_POST['submit_id'] ?? '';
    $admin_remark = $_POST['admin_remark'] ?? '';

    if (!empty($submit_id) && !empty($admin_remark)) {
        $submit_id = trim($submit_id);
        $admin_remark = trim($admin_remark);

        // Prepare update query safely
        $stmt = $conn->prepare("UPDATE orders SET admin_remark = ? WHERE submit_id = ?");
        if ($stmt) {
            $stmt->bind_param('ss', $admin_remark, $submit_id);
            if ($stmt->execute()) {
                echo 'success';
            } else {
                echo 'error';
            }
            $stmt->close();
        } else {
            echo 'error';
        }
    } else {
        echo 'error';
    }
} else {
    echo 'error';
}
$conn->close();
?>
