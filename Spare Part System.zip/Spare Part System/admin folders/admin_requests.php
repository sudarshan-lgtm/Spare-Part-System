<?php
session_start();
include '../db.php';

// Prevent accessing this page after logout
if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}

// Fetch all pending requests
$result = $conn->query("SELECT * FROM requests WHERE status = 'pending'");

if ($result) {
    $result->free();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <title>Requests</title>
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #EEF2FE;
            margin: 0;
            padding: 20px;
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            color: white;
            border-radius: 50%;
            text-decoration: none;
            font-size: 22px;
            transition: all 0.3s ease;
            position: fixed;
            top: 10px;
            left: 20px;
            z-index: 999;
        }
        .back-button:hover {
            transform: scale(1.1);
            color: #fff;
        }
        .back-button .home {
            height: 55px;
            width: auto;
            margin-right: 10px;
            vertical-align: middle;
            object-fit: contain;
        }
        /* Heading */
        h2 {
            text-align: center;
            color: #333;
        }
        /* Table Styles */
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #d4f1ff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            overflow: hidden;
        }
        table, th, td {
            border: 1px solid #ddd;
            background-color: #fff;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #007bff;
            color: white;
            text-transform: uppercase;
        }
        td:nth-child(2) { /* Password column */
            max-width: 120px;
            word-break: break-word;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        /* Buttons */
        td button {
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            font-size: 14px;
            border-radius: 5px;
            transition: 0.3s;
        }
        .btn-success {
            background-color: #28a745;
            color: white;
        }
        .btn-danger {
            background-color: #dc3545;
            color: white;
        }
        .btn-success:hover {
            background-color: #218838;
        }
        .btn-danger:hover {
            background-color: #c82333;
        }
        /* Responsive Styles */
        @media screen and (max-width: 1024px) {
            body {
                padding: 10px;
            }
            table {
                font-size: 16px;
            }
        }
        @media screen and (max-width: 768px) {
            table {
                display: block;
                overflow-x: auto;
                white-space: nowrap;
            }
            th, td {
                padding: 10px;
                font-size: 14px;
            }
            td button {
                font-size: 12px;
                padding: 6px 10px;
            }
        }
        @media screen and (max-width: 480px) {
            body {
                padding: 5px;
            }
            table {
                width: 100%;
                font-size: 14px;
            }
            th, td {
                padding: 8px;
                font-size: 14px;
                line-height: 3;
            }
            td button {
                font-size: 10px;
                padding: 5px 8px;
            }
            td:nth-child(2) {
                max-width: 120px;
                word-break: break-word;
                overflow: hidden;
            }
        }
        @media screen and (max-width: 768px) and (orientation: landscape) {
            table {
                font-size: 14px;
            }
            th, td {
                padding: 8px;
            }
            td button {
                font-size: 12px;
                padding: 6px 10px;
            }
        }
        @media screen and (min-width: 1440px) {
            table {
                font-size: 18px;
            }
            th, td {
                padding: 14px;
            }
            td button {
                font-size: 16px;
                padding: 10px 14px;
            }
        }
    </style>
</head>
<body>
    <?php include("preloader.html"); ?>
    <a href='admin_dashboard.php' class='back-button'><img src="../image/h1.png" class="home" alt="Home"></a>
    <h2>Pending Requests for Users and Members</h2>
    <table border="1">
        <tr>
            <th>Username</th>
            <th>Password</th>
            <th>Full Name</th>
            <th>Email</th>
            <th>Mobile</th>
            <th>Address</th>
            <th>City</th>
            <th>Area</th>
            <th>GSTIN</th>
            <th>DOB</th>
            <th>Account Type</th>
            <th>Action</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?= htmlspecialchars($row['username']) ?></td>
            <td><?= htmlspecialchars($row['password']) ?></td>
            <td><?= htmlspecialchars($row['fullname']) ?></td>
            <td><?= htmlspecialchars($row['email']) ?></td>
            <td><?= htmlspecialchars($row['mobile']) ?></td>
            <td><?= htmlspecialchars($row['address']) ?></td>
            <td><?= htmlspecialchars($row['city']) ?></td>
            <td><?= htmlspecialchars($row['area']) ?></td>
            <td><?= htmlspecialchars($row['gstin']) ?></td>
            <td><?= htmlspecialchars($row['dob']) ?></td>
            <td><?= htmlspecialchars(ucfirst($row['account_type'])) ?></td>
            <td>
                <form action="admin_process_request.php" method="POST">
                    <input type="hidden" name="id" value="<?= htmlspecialchars($row['id']) ?>">
                    <input type="hidden" name="username" value="<?= htmlspecialchars($row['username']) ?>">
                    <input type="hidden" name="password" value="<?= htmlspecialchars($row['password']) ?>">
                    <input type="hidden" name="fullname" value="<?= htmlspecialchars($row['fullname']) ?>">
                    <input type="hidden" name="email" value="<?= htmlspecialchars($row['email']) ?>">
                    <input type="hidden" name="mobile" value="<?= htmlspecialchars($row['mobile']) ?>">
                    <input type="hidden" name="address" value="<?= htmlspecialchars($row['address']) ?>">
                    <input type="hidden" name="city" value="<?= htmlspecialchars($row['city']) ?>">
                    <input type="hidden" name="area" value="<?= htmlspecialchars($row['area']) ?>">
                    <input type="hidden" name="gstin" value="<?= htmlspecialchars($row['gstin']) ?>">
                    <input type="hidden" name="dob" value="<?= htmlspecialchars($row['dob']) ?>">
                    <input type="hidden" name="account_type" value="<?= htmlspecialchars($row['account_type']) ?>">
                    <button type="submit" name="approve" class="btn btn-success" style="border-radius:8px; margin-bottom: 5px;">Approve</button><br>
                    <button type="submit" name="reject" class="btn btn-danger" style="border-radius:8px;">Reject</button>
                </form>
            </td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>