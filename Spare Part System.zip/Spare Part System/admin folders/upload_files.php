<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include '../db.php';
require '../vendor/autoload.php'; // Include PhpSpreadsheet

// Verify database connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Handle Image Folder Upload
if (isset($_POST['upload_folder'])) {
    $targetBase = 'uploads/folders/';

    if (!is_dir($targetBase)) {
        mkdir($targetBase, 0777, true);
    }

    $files = $_FILES['folder'];
    $total = count($files['name']);

    for ($i = 0; $i < $total; $i++) {
        $tmpPath = $files['tmp_name'][$i];
        $filename = basename($files['name'][$i]);

        if (!empty($filename) && is_uploaded_file($tmpPath)) {
            $destination = $targetBase . $filename;
            if (file_exists($destination)) {
                unlink($destination);
            }
            if (!move_uploaded_file($tmpPath, $destination)) {
                echo "<script>alert('❌ Failed to upload file: $filename'); window.location.href='upload_folder_excel.php';</script>";
                exit;
            }
        }
    }

    echo "<script>alert('✅ Folder Upload Complete!'); window.location.href='upload_folder_excel.php';</script>";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    function uploadExcel($fileKey, $tableName, $conn) {
        if (!empty($_FILES[$fileKey]['tmp_name'])) {
            try {
                // Log file details
                error_log("File uploaded: " . $_FILES[$fileKey]['name'] . ", Size: " . $_FILES[$fileKey]['size']);
                file_put_contents('debug_rows.txt', "File: " . $_FILES[$fileKey]['name'] . "\n", FILE_APPEND);

                $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($_FILES[$fileKey]['tmp_name']);
                $sheet = $spreadsheet->getActiveSheet();
                $highestRow = $sheet->getHighestRow();
                $highestColumn = 'P'; // Fixed to 16 columns (A-P)
                $rows = $sheet->rangeToArray("A1:$highestColumn$highestRow", null, true, false, false);

                // Log total rows and first/last few rows
                error_log("Total rows in Excel (including header): " . count($rows));
                file_put_contents('debug_rows.txt', "Total rows: " . count($rows) . "\n", FILE_APPEND);
                for ($i = 0; $i < min(5, count($rows)); $i++) {
                    error_log("Raw row " . ($i + 1) . ": " . json_encode($rows[$i]));
                    file_put_contents('debug_rows.txt', "Raw row " . ($i + 1) . ": " . json_encode($rows[$i]) . "\n", FILE_APPEND);
                }
                // Log last row (footer)
                $lastRow = end($rows);
                error_log("Last raw row: " . json_encode($lastRow));
                file_put_contents('debug_rows.txt', "Last raw row: " . json_encode($lastRow) . "\n", FILE_APPEND);

                // Skip header and filter empty rows or footer
                $rows = array_slice($rows, 1); // Remove header
                $rows = array_filter($rows, function($row) {
                    // Log ProductGroup for debugging
                    $productGroup = isset($row[0]) ? json_encode($row[0]) : 'null';
                    error_log("Checking row with ProductGroup: " . $productGroup);
                    file_put_contents('debug_rows.txt', "Checking row with ProductGroup: " . $productGroup . "\n", FILE_APPEND);

                    // Skip rows where first column is 'Total' (case-insensitive) or resembles footer
                    if (isset($row[0]) && is_string($row[0]) && strtolower(trim($row[0])) === 'total') {
                        error_log("Footer row detected and skipped: " . json_encode($row));
                        file_put_contents('debug_rows.txt', "Footer row skipped: " . json_encode($row) . "\n", FILE_APPEND);
                        return false;
                    }
                    // Fallback: Skip rows with large numeric values typical of totals (e.g., ReceiptQty = 20595)
                    if (isset($row[11]) && is_numeric($row[11]) && $row[11] > 10000) {
                        error_log("Potential footer row skipped (large ReceiptQty): " . json_encode($row));
                        file_put_contents('debug_rows.txt', "Potential footer row skipped (large ReceiptQty): " . json_encode($row) . "\n", FILE_APPEND);
                        return false;
                    }

                    // Keep rows with at least one non-empty cell
                    return !empty(array_filter($row, function($cell) {
                        return !is_null($cell) && (is_string($cell) ? trim($cell) !== '' : $cell !== '');
                    }));
                });

                error_log("Rows after filtering: " . count($rows));
                file_put_contents('debug_rows.txt', "Filtered rows: " . count($rows) . "\n", FILE_APPEND);

                $sequence = 1;
                $inserted = 0;
                $updated = 0;
                $skipped = 0;

                // Log initial row count
                $initialCountQuery = $conn->query("SELECT COUNT(*) FROM $tableName");
                $initialCount = $initialCountQuery->fetch_row()[0];
                error_log("Initial row count in $tableName: $initialCount");
                file_put_contents('debug_rows.txt', "Initial count: $initialCount\n", FILE_APPEND);

                // Start transaction
                $conn->begin_transaction();

                foreach ($rows as $row) {
                    try {
                        // Sanitize and validate data
                        $ProductGroup = !empty($row[0]) && is_string($row[0]) && strlen(trim($row[0])) <= 255 ? trim($row[0]) : '';
                        $Product = !empty($row[1]) && is_string($row[1]) && strlen(trim($row[1])) <= 255 ? trim($row[1]) : '';
                        $Batch = !empty($row[2]) && is_string($row[2]) && strlen(trim($row[2])) <= 255 ? trim($row[2]) : '';
                        $Company = !empty($row[3]) && is_string($row[3]) && strlen(trim($row[3])) <= 255 ? trim($row[3]) : '';
                        $PartNo = !empty($row[4]) && is_string($row[4]) && strlen(trim($row[4])) <= 255 ? trim($row[4]) : '';
                        $PurchaseRate = is_numeric($row[5]) && $row[5] >= 0 ? floatval($row[5]) : 0.0;
                        $GST = is_numeric($row[6]) && $row[6] >= 0 ? floatval($row[6]) : 0.0;
                        $Exp = !empty($row[7]) && is_string($row[7]) && strlen(trim($row[7])) <= 50 ? trim($row[7]) : '';
                        $Margin = is_numeric($row[8]) && $row[8] >= 0 ? floatval($row[8]) : 0.0;
                        $PurchaseCode = !empty($row[9]) && is_string($row[9]) && strlen(trim($row[9])) <= 255 ? trim($row[9]) : '';
                        $SaleRate = is_numeric($row[10]) && $row[10] >= 0 ? floatval($row[10]) : 0.0;
                        $ReceiptQty = is_numeric($row[11]) && $row[11] >= 0 ? intval($row[11]) : 0;
                        $IssueQty = is_numeric($row[12]) && $row[12] >= 0 ? intval($row[12]) : 0;
                        $ClosingQty = is_numeric($row[13]) && $row[13] >= 0 ? intval($row[13]) : 0;
                        $Location = !empty($row[14]) && is_string($row[14]) && strlen(trim($row[14])) <= 255 ? trim($row[14]) : '';
                        $imagePath = !empty($row[15]) && is_string($row[15]) && strlen(trim($row[15])) <= 255 ? 'uploads/folders/' . trim($row[15]) : '';

                        // Validate data
                        if (strlen($ProductGroup) > 255 || strlen($Product) > 255 || strlen($Batch) > 255 || 
                            strlen($Company) > 255 || strlen($PartNo) > 255 || strlen($PurchaseCode) > 255 || 
                            strlen($Location) > 255 || strlen($imagePath) > 255 || strlen($Exp) > 50 ||
                            !is_numeric($PurchaseRate) || !is_numeric($GST) || !is_numeric($Margin) ||
                            !is_numeric($SaleRate) || !is_numeric($ReceiptQty) || !is_numeric($IssueQty) ||
                            !is_numeric($ClosingQty)) {
                            error_log("Row $sequence skipped due to invalid data: " . json_encode($row));
                            file_put_contents('debug_rows.txt', "Row $sequence skipped: invalid data\n", FILE_APPEND);
                            $skipped++;
                            $sequence++;
                            continue;
                        }

                        // Log row data
                        error_log("Row $sequence PartNo: '$PartNo'");
                        file_put_contents('debug_rows.txt', "Row $sequence PartNo: '$PartNo'\n", FILE_APPEND);

                        // Insert new record
                        $query = $conn->prepare("INSERT INTO $tableName (ProductGroup, Product, Batch, Company, PartNo, PurchaseRate, GST, Exp, Margin, PurchaseCode, SaleRate, ReceiptQty, IssueQty, ClosingQty, Location, imagePath, sequence) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                        if (!$query) {
                            throw new Exception("Insert query prepare failed: " . $conn->error);
                        }
                        $query->bind_param("sssssdddsdsiiissi", $ProductGroup, $Product, $Batch, $Company, $PartNo, $PurchaseRate, $GST, $Exp, $Margin, $PurchaseCode, $SaleRate, $ReceiptQty, $IssueQty, $ClosingQty, $Location, $imagePath, $sequence);
                        if ($query->execute()) {
                            $affectedRows = $query->affected_rows;
                            error_log("Row $sequence (PartNo: '$PartNo') inserted, affected rows: $affectedRows");
                            file_put_contents('debug_rows.txt', "Row $sequence inserted: $affectedRows\n", FILE_APPEND);
                            $inserted += $affectedRows;
                        } else {
                            error_log("Insert failed for row $sequence (PartNo: '$PartNo'): " . $query->error);
                            file_put_contents('debug_rows.txt', "Row $sequence insert failed: " . $query->error . "\n", FILE_APPEND);
                            $skipped++;
                        }
                        $query->close();

                        $sequence++;
                    } catch (Exception $e) {
                        error_log("Error processing row $sequence: " . $e->getMessage());
                        file_put_contents('debug_rows.txt', "Row $sequence error: " . $e->getMessage() . "\n", FILE_APPEND);
                        $skipped++;
                        $sequence++;
                        continue;
                    }
                }

                // Commit transaction
                if (!$conn->commit()) {
                    throw new Exception("Transaction commit failed: " . $conn->error);
                }

                // Log final row count
                $finalCountQuery = $conn->query("SELECT COUNT(*) FROM $tableName");
                $finalCount = $finalCountQuery->fetch_row()[0];
                error_log("Final row count in $tableName: $finalCount");
                file_put_contents('debug_rows.txt', "Final count: $finalCount\n", FILE_APPEND);

                // Log summary
                error_log("Upload summary: Inserted=$inserted, Updated=$updated, Skipped=$skipped, Total processed=" . ($inserted + $updated + $skipped));
                file_put_contents('debug_rows.txt', "Summary: Inserted=$inserted, Updated=$updated, Skipped=$skipped, Total=" . ($inserted + $updated + $skipped) . "\n", FILE_APPEND);

                return [
                    'success' => true,
                    'message' => "Excel data processed: $inserted rows inserted, $updated rows updated, $skipped rows skipped.",
                    'updated' => $updated,
                    'inserted' => $inserted,
                    'skipped' => $skipped
                ];
            } catch (Exception $e) {
                $conn->rollback();
                error_log("Error processing Excel file: " . $e->getMessage());
                file_put_contents('debug_rows.txt', "Error: " . $e->getMessage() . "\n", FILE_APPEND);
                return [
                    'success' => false,
                    'message' => "Failed to process Excel file: " . $e->getMessage()
                ];
            }
        }
        return [
            'success' => false,
            'message' => "No file uploaded."
        ];
    }

    // Handle ProductInventory Upload
    if (isset($_POST['upload_excel'])) {
        $result = uploadExcel('excelFile', 'productinventory', $conn);
        if ($result['success']) {
            $countQuery = $conn->query("SELECT COUNT(*) FROM productinventory");
            $rowCount = $countQuery->fetch_row()[0];
            $updated = $result['updated'] ?? 0;
            $inserted = $result['inserted'] ?? 0;
            $totalProcessed = $inserted + $updated;
            $result['message'] .= " Database now contains $rowCount rows ($inserted inserted + $updated updated, total processed: $totalProcessed).";
            echo "<script>alert('{$result['message']} 🚀📊 Ready for action!'); window.location.href='upload_folder_excel.php';</script>";
        } else {
            echo "<script>alert('{$result['message']} Please check the file and try again.'); window.location.href='upload_folder_excel.php';</script>";
        }
    }

    // Handle Solapur Upload
    if (isset($_POST['upload_solapur'])) {
        $result = uploadExcel('solapurExcel', 'solapurdata', $conn);
        if ($result['success']) {
            $countQuery = $conn->query("SELECT COUNT(*) FROM solapurdata");
            $rowCount = $countQuery->fetch_row()[0];
            $updated = $result['updated'] ?? 0;
            $inserted = $result['inserted'] ?? 0;
            $totalProcessed = $inserted + $updated;
            $result['message'] .= " Database now contains $rowCount rows ($inserted inserted + $updated updated, total processed: $totalProcessed).";
            echo "<script>alert('{$result['message']} 🚀📊 Ready for action!'); window.location.href='upload_folder_excel.php';</script>";
        } else {
            echo "<script>alert('{$result['message']} Please check the file and try again.'); window.location.href='upload_folder_excel.php';</script>";
        }
    }

    // Handle Kolhapur Upload
    if (isset($_POST['upload_kolhapur'])) {
        $result = uploadExcel('kolhapurExcel', 'kolhapurdata', $conn);
        if ($result['success']) {
            $countQuery = $conn->query("SELECT COUNT(*) FROM kolhapurdata");
            $rowCount = $countQuery->fetch_row()[0];
            $updated = $result['updated'] ?? 0;
            $inserted = $result['inserted'] ?? 0;
            $totalProcessed = $inserted + $updated;
            $result['message'] .= " Database now contains $rowCount rows ($inserted inserted + $updated updated, total processed: $totalProcessed).";
            echo "<script>alert('{$result['message']} 🚀📊 Ready for action!'); window.location.href='upload_folder_excel.php';</script>";
        } else {
            echo "<script>alert('{$result['message']} Please check the file and try again.'); window.location.href='upload_folder_excel.php';</script>";
        }
    }
}

$conn->close();
?>