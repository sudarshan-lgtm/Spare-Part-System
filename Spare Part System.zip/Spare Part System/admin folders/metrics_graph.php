<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');

include "../db.php"; // Database connection file

$response = array();

// Function to count total rows
function getRowCount($tableName, $conn) {
    $query = "SELECT COUNT(id) as total_count FROM $tableName";
    $result = mysqli_query($conn, $query);
    if (!$result) {
        die(json_encode(["error" => "Query failed: " . mysqli_error($conn)]));
    }
    $row = mysqli_fetch_assoc($result);
    return $row['total_count'] ? (int)$row['total_count'] : 0;
}

// **Total Products Count** (productinventory + kolhapurdata)
$totalProducts = getRowCount("productinventory", $conn) + getRowCount("kolhapurdata", $conn);

// **Total Sales Count**
$totalSales = getRowCount("submitted_orders", $conn);

// **Today's Date**
$todayDate = date('Y-m-d');

// **Today's Money (Fixed Query)**
$todaysMoneyQuery = "SELECT SUM(totalSaleRate) as today_money FROM submitted_orders WHERE DATE(order_date) = CURDATE()";
$todaysMoneyResult = mysqli_query($conn, $todaysMoneyQuery);
$todaysMoneyRow = mysqli_fetch_assoc($todaysMoneyResult);
$todaysMoney = $todaysMoneyRow['today_money'] ? (float)$todaysMoneyRow['today_money'] : 0;


// **Total Money Calculation**
$totalMoneyQuery = "SELECT SUM(totalSaleRate) as total_money FROM submitted_orders";
$totalMoneyResult = mysqli_query($conn, $totalMoneyQuery);
$totalMoneyRow = mysqli_fetch_assoc($totalMoneyResult);
$totalMoney = $totalMoneyRow['total_money'] ? (float)$totalMoneyRow['total_money'] : 0;

// **Today's Sales Count**
$todayDate = date('Y-m-d');
$todaysSalesQuery = "SELECT COUNT(*) as today_sales FROM submitted_orders WHERE DATE(order_date) = '$todayDate'";
$todaysSalesResult = mysqli_query($conn, $todaysSalesQuery);
$todaysSalesRow = mysqli_fetch_assoc($todaysSalesResult);
$todaysSales = $todaysSalesRow['today_sales'] ? (int)$todaysSalesRow['today_sales'] : 0;

// **Final Response**
$response = array(
    "totalProducts" => $totalProducts,
    "totalSales" => $totalSales,
    "todaysMoney" => $todaysMoney,
    "totalMoney" => $totalMoney,
    "todaysSales" => $todaysSales
);

echo json_encode($response);
?>
