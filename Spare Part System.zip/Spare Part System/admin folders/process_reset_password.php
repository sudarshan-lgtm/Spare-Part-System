<?php
require_once("../db.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = mysqli_real_escape_string($conn, $_POST['token'] ?? '');
    $newPassword = $_POST['new_password'] ?? '';

    if (!$token || !$newPassword) {
        echo "<script>alert('Missing token or password.'); window.location='admin_forget_password.php';</script>";
        exit;
    }

    // Check if token is valid and not expired
    $checkQuery = "SELECT * FROM users WHERE reset_token = '$token' AND token_expiry > NOW()";
    $result = mysqli_query($conn, $checkQuery);

    if (mysqli_num_rows($result) === 1) {
        // Hash new password
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

        // Update password and clear token
        $updateQuery = "UPDATE users SET password = '$hashedPassword', reset_token = NULL, token_expiry = NULL WHERE reset_token = '$token'";
        if (mysqli_query($conn, $updateQuery)) {
            echo "<script>alert('✅ Password reset successfully.'); window.location='admin_login.php';</script>";
        } else {
            echo "<script>alert('❌ Failed to reset password. Try again.'); window.location='admin_forget_password.php';</script>";
        }
    } else {
        echo "<script>alert('⛔ Invalid or expired token.'); window.location='admin_forget_password.php';</script>";
    }
} else {
    echo "<script>alert('Invalid request.'); window.location='admin_forget_password.php';</script>";
}
?>
