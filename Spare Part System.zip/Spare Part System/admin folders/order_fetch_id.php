<?php
include '../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['fullname'])) {
    $fullname = trim($_POST['fullname']);
    $response = array("success" => false);

    $query = "SELECT submit_id, order_date FROM submitted_orders WHERE fullname = ? ORDER BY order_date DESC LIMIT 1";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $fullname);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        $response["success"] = true;
        $response["submit_id"] = $row["submit_id"];
        $response["order_date"] = $row["order_date"];
    }

    $stmt->close();
    $conn->close();

    echo json_encode($response);
}
?>
