<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}

$pdo = new PDO("mysql:host=127.0.0.1:3306;dbname=u494849712_part", "u494849712_patilnagesh007", "Password@1381");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$search = $_GET['search'] ?? '';
$search = trim($search);

if ($search !== '') {
    $stmt = $pdo->prepare("SELECT DISTINCT customer_name FROM receivable_customers2 WHERE customer_name LIKE :search LIMIT 10");
    $stmt->execute([':search' => $search . '%']);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    echo json_encode($results);
} else {
    echo json_encode([]);
}
?>
