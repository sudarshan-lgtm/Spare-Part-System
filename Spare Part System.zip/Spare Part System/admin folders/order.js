// delete button work into table
document.addEventListener('DOMContentLoaded', function () {
    const deleteButtons = document.querySelectorAll('.delete-btn');

    deleteButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            const submitId = this.getAttribute('data-submit-id');

            if (confirm("Are you sure you want to delete this order?")) {
                fetch('order_delete.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ submit_id: submitId })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Order deleted successfully.');
                        location.reload(); // or remove the row from DOM
                    } else {
                        alert('Failed to delete order: ' + data.error);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
            }
        });
    });
});
// Update Sale Rate
function updateSaleRate(inputElement, submitId) {
    const newValue = parseFloat(inputElement.value);
    if (!isNaN(newValue)) {
        $.ajax({
            url: "../admin folders/order_update_sale_rate.php",
            method: "POST",
            data: {
                newSaleRate: newValue,
                submitId: submitId
            },
            success: function (response) {
                const res = JSON.parse(response);
                if (res.success) {
                    const updatedCell = $(inputElement).closest('tr').find('.updated-sale-rate');
                    updatedCell.text(res.updatedSaleRate.toFixed(2));
                } else {
                    alert("Update failed: " + res.error);
                }
            },
            error: function () {
                alert("Error occurred while updating the sale rate.");
            }
        });
    }
}
//Highlight Orders
document.addEventListener("DOMContentLoaded", function () {
    let highlightedOrder = "<?php echo $highlight_order; ?>";
    if (highlightedOrder) {
        let row = document.getElementById("order-" + highlightedOrder);
        if (row) {
            row.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }
});
//Validation
    function validateNumbers(input)  {
            input.value = input.value.replace(/[^0-9]/g, '').substring(0,10);
    }    
//Feedback column Expanded
document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".feedback-column, .remark-column, .admin-remark-cell").forEach(function (element) {
        element.addEventListener("click", function () {
            this.classList.toggle("expanded");
        });
    });
});
//Keyboard Shortcut Key
document.addEventListener("keydown", function(event) {
    const activeElement = document.activeElement;
    
    // Check if the active element is an input field
    if (event.key === "Backspace" && (activeElement.tagName !== "INPUT" && activeElement.tagName !== "TEXTAREA")) {
        event.preventDefault();
        window.history.back(); 
    }
});