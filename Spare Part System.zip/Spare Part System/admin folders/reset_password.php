<?php
require_once("../db.php");

$token = $_GET['token'] ?? '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reset Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fa;
        }
        .reset-card {
            max-width: 450px;
            margin: 60px auto;
            padding: 30px;
            box-shadow: 0 0 12px rgba(0,0,0,0.15);
            border-radius: 10px;
            background-color: white;
        }
    </style>
</head>
<body>

<div class="container">
    <?php
    if ($token) {
        $query = "SELECT * FROM users WHERE reset_token = '$token' AND token_expiry > NOW()";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) == 1) {
            ?>
            <div class="reset-card">
                <h4 class="text-center mb-4">🔐 Reset Your Password</h4>
                <form action="process_reset_password.php" method="POST">
                    <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
                    <div class="mb-3">
                        <label for="new_password" class="form-label">New Password</label>
                        <input type="password" name="new_password" class="form-control" placeholder="Enter new password" required minlength="8" maxlength="20">
                        <div class="form-text">Must be 8-20 characters long.</div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Reset Password</button>
                </form>
            </div>
            <?php
        } else {
            echo '<div class="alert alert-danger mt-5 text-center">⛔ Invalid or expired token.</div>';
        }
    } else {
        echo '<div class="alert alert-warning mt-5 text-center">⚠️ Token is missing.</div>';
    }
    ?>
</div>

</body>
</html>