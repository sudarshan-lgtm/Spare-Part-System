<?php
include '../db.php';
require '../vendor/autoload.php'; // Include PhpSpreadsheet

use PhpOffice\PhpSpreadsheet\IOFactory;
$uploadDir = '../uploads/excel/';
$files = glob($uploadDir . '*.{xls,xlsx}', GLOB_BRACE);
$fileToDisplay = null;
$rows = [];
if (isset($_GET['file'])) {
    $fileToDisplay = basename($_GET['file']);
    $filePath = $uploadDir . $fileToDisplay;

    if (file_exists($filePath)) {
        // Load the Excel file
        $spreadsheet = IOFactory::load($filePath);
        $sheet = $spreadsheet->getActiveSheet();
        $rows = $sheet->toArray();
    } else {
        $fileToDisplay = null;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uploaded Excel Files</title>
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
            text-align: center;
        }
        h2 {
            color: #333;
        }
        
        /* File Cards */
        .file-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 15px;
            margin-top: 20px;
        }
        .card {
            width: 250px;
            background-color: #fff;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            transition: transform 0.2s ease-in-out;
            text-align: center;
        }
        .card:hover {
            transform: scale(1.05);
        }
        .card img {
            height: 40px;
            width: auto;
        }
        .card a {
            display: block;
            text-decoration: none;
            color: #333;
            font-size: 16px;
            font-weight: bold;
            margin-top: 10px;
        }

        /* Responsive Table */
        .table-container {
            max-width: 100%;
            overflow-x: auto; 
            overflow-y: auto; 
            max-height: 500px; 
            border: 1px solid #ccc; 
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        th, td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }
        th {
            background-color: #007BFF;
            color: white;
            text-transform: uppercase;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
         /* Search Box */
        .search-container {
            margin-top: 20px;
            text-align: center;
        }
        #searchInput {
            width: 80%;
            max-width: 500px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        #searchButton {
            padding: 10px 15px;
            font-size: 16px;
            border: none;
            background-color: #007BFF;
            color: white;
            cursor: pointer;
            border-radius: 5px;
            margin-left: 10px;
        }
        #searchButton:hover {
            background-color: #0056b3;
        }
        /* Responsive Design */
        @media screen and (max-width: 768px) {
            .card {
                width: 90%;
            }
            table {
                font-size: 14px;
            }
            th, td {
                padding: 8px;
            }
        }
        @media screen and (max-width: 480px) {
            table {
                font-size: 12px;
            }
            th, td {
                padding: 6px;
            }
        }
    </style>
</head>
<body>
    <h2>Uploaded Excel Files</h2>
    <div class="file-container">
        <?php if (!empty($files)) {
            foreach ($files as $file) {
                $fileName = basename($file);
                $fileDate = date("d-M-Y", filemtime($file)); // Get file upload date
                echo "<a href='ledger_display.php?file=$fileName'>
                <div class='card'>
                <img src='../image/logo/xls.png' alt='xls'>$fileName</a>
                <p class='upload-date'>Uploaded on: $fileDate</p>
                </div>";
            }
        } else {
            echo "<p>No files uploaded yet.</p>";
        } ?>
    </div>
    <?php if ($fileToDisplay): ?>
        <div class="search-container">
            <input type="text" id="searchInput" placeholder="Search Account Statement...">
            <button type="button" id="searchButton">Search</button>
        </div>
    <?php endif; ?>
    <?php if ($fileToDisplay && isset($rows)): ?>
        <h3>Displaying: <?php echo $fileToDisplay; ?></h3>
        <div class="table-container">
            <table id="excelTable">
                <?php foreach ($rows as $index => $row): ?>
                    <tr>
                        <?php foreach ($row as $cell): ?>
                            <td><?php echo htmlspecialchars($cell); ?></td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    <?php endif; ?>
    <script>
      function searchTable() {
        let searchValue = document.getElementById('searchInput').value.toLowerCase();
        let table = document.getElementById('excelTable');
        let rows = table.getElementsByTagName('tr');

        let found = false; // Track if search value is found
        let nextAccountStatementFound = false; // Track the next account statement

        for (let i = 0; i < rows.length; i++) {
            let row = rows[i];
            let cells = row.getElementsByTagName('td');
            let rowText = "";

            for (let j = 0; j < cells.length; j++) {
                rowText += cells[j].innerText.toLowerCase() + " ";
            }

            if (rowText.includes(searchValue)) {
                found = true; // Start showing rows from this point
            }

            if (found && rowText.includes("account statement for") && !rowText.includes(searchValue)) {
                nextAccountStatementFound = true; // Stop when the next account statement starts
            }

            if (found && !nextAccountStatementFound) {
                row.style.display = ""; // Show this row
            } else {
                row.style.display = "none"; // Hide other rows
            }
        }
    }

    // Attach event listeners
    document.getElementById('searchButton').addEventListener('click', searchTable);
    document.getElementById('searchInput').addEventListener('keypress', function(event) {
        if (event.key === "Enter") {
            searchTable();
        }
    });
    </script>
</body>
</html>