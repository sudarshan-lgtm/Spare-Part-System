<?php
session_start();
require '../db.php';
if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <title>Account</title>
    <style>
       body {
            background-color: #EEF2FE; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center; 
            align-items: center;     
            min-height: 100vh;       
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            color: white;
            border-radius: 50%;
            text-decoration: none;
            font-size: 22px;
            transition: all 0.3s ease;
            position: fixed; /* Optional: fixed position */
            top: 10px;
            left: 20px;
            z-index: 999;
        }
        .back-button:hover {
            transform: scale(1.1);
            color: #fff;
        }
        .back-button .home {
            height: 55px; 
            width: auto;  
            margin-right: 10px; 
            vertical-align: middle;
            object-fit: contain;
        }
        .card {
            display: flex;
            flex-direction: row;
            align-items: center;
            background-color: #fff;
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
            max-width: 550px;
            width: 90%;
            gap: 20px;
        }

        /* QR Image Section */
        .qr-section {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .qr-section img {
            width: 180px;
            height: auto;
            border-radius: 8px;
            border: 1px solid #ccc;
            cursor: pointer;
        }

        /* Text Section */
        .details-section {
            flex: 2;
        }

        .details-section h2 {
            color: #d60000;
            margin-bottom: 20px;
            font-size: 24px;
        }

        .details-section p {
            font-size: 18px;
            margin: 10px 0;
        }

        .label {
            font-weight: bold;
            color: #333;
        }

        /* Popup styles */
        .popup {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.4);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 999;
        }

        .popup-content {
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }

        .popup-content h3 {
            margin-bottom: 20px;
        }

        .popup-content button {
            padding: 10px 20px;
            margin: 10px;
            font-size: 16px;
            border: none;
            background-color: #007bff;
            color: white;
            border-radius: 6px;
            cursor: pointer;
        }

        .popup-content button:hover {
            background-color: #0056b3;
        }

        .container {
            width: 90%;
            margin: 20px auto;
            overflow-x: auto; /* Enables horizontal scrolling on small screens */
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 1);
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
            white-space: nowrap; /* Prevents text wrapping */
            border-collapse: collapse;
        }
        th {
            background-color: #007BFF;
            color: white;
            text-transform: uppercase;
        }
        .password-column {
            width: 120px; /* Adjust width as needed */
            max-width: 120px;
            overflow: hidden;
            text-overflow: ellipsis; /* Adds "..." if text overflows */
            white-space: nowrap; /* Prevents text from wrapping */
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #e9ecef;
        }
        button {
            border: none;
            border-radius: 5px;
            padding: 12px;
            margin: 15px;
            width: auto;
            background-color: #007BFF;
            color: white;
            cursor: pointer;
            transition: 0.3s ease-in-out;
        }
        button:hover {
            background-color: #0056b3;
        }
        select {
            padding: 10px;
            width: 30%;
            margin: 20px;
            border-radius: 5px;
            border: 1px solid #ccc;
            background: white;
            cursor: pointer;
        }
        #accountTable {
            display: none;
            margin-top: 20px;
        }
        /* Modal Background */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            max-width: 1800px;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
            overflow-x: auto;
        }
        /* Modal Content */
        .modal-content {
            background: white;
            padding: 20px !important;
            border-radius: 10px;
            width: 50%;
            max-width: 600px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.3);
            animation: fadeIn 0.3s ease-in-out;
        }
        /* Modal Heading */
        .modal-content h3 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 1.5em;
        }
        /* Input Fields */
        .modal-content input {
            width: 90%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1em;
        }
        /* Buttons */
        .modal-content button {
            width: 90%;
            padding: 12px;
            margin-top: 10px;
            border: none;
            border-radius: 5px;
            background-color: #007BFF;
            color: white;
            font-size: 1em;
            cursor: pointer;
            transition: background 0.3s;
        }
        .modal-content button:hover {
            background-color: #0056b3;
        }
       /* Responsive Design */
       /* Large Screens (Desktops) */
        @media screen and (min-width: 1200px) {
            .modal-content {
                width: 40%;
            }
        }
        /* Tablet (Portrait) */
        @media screen and (max-width: 1024px) {
            .container {
                width: 95%;
            }
            th, td {
                padding: 10px;
                font-size: 14px;
            }
            .modal-content {
                width: 50%;
            }
        }
        /* Small Screens and Mobile Devices */
        @media screen and (max-width: 768px) {
            .card {
                flex-direction: column;
                padding: 20px;
                max-width: 90%;
            }

            .qr-section img {
                width: 160px;
                margin-bottom: 20px;
            }

            .details-section h2 {
                font-size: 22px;
                text-align: center;
            }

            .details-section p {
                font-size: 16px;
                text-align: center;
            }
            .table-container {
                width: 100%;
                overflow-x: auto;
            }
            table {
                display: block;
                width: 100%;
                overflow-x: auto;
                white-space: nowrap;
            }
            th, td {
                font-size: 12px;
                padding: 8px;
            }
            select, button {
                width: 100%;
                padding: 10px;
            }
            .modal-content {
                width: 70%;
                padding: 15px;
            }
            .modal-content h3 {
                font-size: 1.3em;
            }
            .modal-content input {
                font-size: 0.9em;
                padding: 8px;
            }
            .modal-content button {
                font-size: 0.9em;
                padding: 10px;
            }
        }
        /* Smallest Devices (Landscape & Portrait) */
        @media screen and (max-width: 480px) {
            .qr-section img {
                width: 140px;
            }

            .details-section h2 {
                font-size: 20px;
            }

            .details-section p {
                font-size: 15px;
            }

            .popup-content {
                width: 90%;
                padding: 20px;
            }

            .popup-content button {
                width: 100%;
                margin: 10px 0;
            }
            .container {
                width: 100%;
                padding: 5px;
            }
            table {
                display: block;
                overflow-x: auto;
                width: 100%;
                white-space: nowrap;
            }
            th, td {
                font-size: 10px;
                padding: 6px;
            }
            select {
                font-size: 12px;
            }
            button {
                font-size: 12px;
                padding: 10px;
            }
            .modal-content {
                width: 90%;
                padding: 10px;
            }
            .modal-content h3 {
                font-size: 1.2em;
            }
            .modal-content input {
                font-size: 0.8em;
                padding: 7px;
            }
            .modal-content button {
                font-size: 0.8em;
                padding: 8px;
            }
        }
        /* Smartphone and Tablet (Landscape Mode) */
        @media screen and (max-width: 912px) and (orientation: landscape) {
            table {
                width: 100%;
                font-size: 14px;
            }
            th, td {
                padding: 8px;
                font-size: 12px;
            }
            .modal-content {
                width: 60%;
            }
        }
        /* Fade-in Animation */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>    
<?php include("preloader.html"); ?>
<a href='admin_dashboard.php' class='back-button'><img src="../image/h1.png" class="home" alt="ok"></a>
<div class="card">
    <div class="qr-section">
      <img src="../image/logo/QR.jpg" alt="QR" id="qr-image" onclick="openPopup()">
    </div>
    <div class="details-section">
      <h2>Bank Details</h2>
      <p><span class="label">Account Holder:</span> RJ AUTO HEAVEN</p>
      <p><span class="label">Bank Name:</span> HDFC BANK</p>
      <p><span class="label">A/C No:</span> 50200075320026</p>
      <p><span class="label">IFSC Code:</span> HDFC0007281</p>
      <p><span class="label">Address:</span> MOHOL</p>
    </div>
  </div>
  <!-- Popup -->
  <div class="popup" id="popup" >
    <div class="popup-content">
      <h3>Select Payment App</h3>
        <button onclick="payUPI('patilnagesh007-1@okhdfcbank')">Pay on PhonePay</button><br><br>
        <button onclick="payUPI('patilnagesh007-1@okhdfcbank')">Pay on GooglePay</button><br><br>
        <button onclick="closePopup()">Cancel</button>
    </div>
  </div>

<script>

//Payment JS
    // Show popup on QR click
    document.getElementById('qr-image').addEventListener('click', function () {
    document.getElementById('popup').style.display = 'flex';
    });

    // Close popup
    function closePopup() {
    document.getElementById('popup').style.display = 'none';
    }

    document.addEventListener('contextmenu', e => e.preventDefault());
        document.onkeydown = function(e) {
        if(e.key === "F12" || (e.ctrlKey && e.shiftKey && (e.key === "I" || e.key === "J"))) {
            return false;
        }
    }
    
    function openPopup() {
      document.getElementById('popup').style.display = 'block';
    }
    
    function closePopup() {
      document.getElementById('popup').style.display = 'none';
    }
    
    function payUPI(upiID) {
      window.location.href = `upi://pay?pa=${upiID}&pn=RJ%20AUTO%20HEAVEN&am=&cu=INR`;
    }
</script>
</body>
</html>