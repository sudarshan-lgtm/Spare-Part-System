<?php
include '../db.php';
require '../vendor/autoload.php'; // Correct path

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

$type = isset($_GET['type']) ? $_GET['type'] : 'csv';

$query = "SELECT id, ProductGroup, Product, Company, PartNo, SaleRate FROM productinventory";
$result = $conn->query($query);

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

if ($type == 'csv') {
    ob_clean(); // Clean output buffer to avoid extra whitespace
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="download.csv"');

    $output = fopen('php://output', 'w');
    echo "\xEF\xBB\xBF"; 

    // Set column headers
    fputcsv($output, ['ID', 'Product Group', 'Product', 'Company', 'Part No', 'Sale Rate']);

    // Add data rows
    foreach ($data as $row) {
        fputcsv($output, [$row['id'], $row['ProductGroup'], $row['Product'], $row['Company'], $row['PartNo'], $row['SaleRate']]);
    }

    fclose($output);
    exit;
}

if ($type == 'excel') {
    // Set column headers
    $headers = ['ID', 'Product Group', 'Product', 'Company', 'Part No', 'Sale Rate'];
    $sheet->fromArray([$headers], NULL, 'A1');

    // Add data rows
    $rowIndex = 2;
    foreach ($data as $row) {
        $sheet->fromArray([$row['id'], $row['ProductGroup'], $row['Product'], $row['Company'], $row['PartNo'], $row['SaleRate']], NULL, 'A' . $rowIndex);
        $rowIndex++;
    }

    // Set headers to force download
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="download.xlsx"');

    $writer = new Xlsx($spreadsheet);
    $writer->save('php://output');
    exit;
    }

if ($type == 'pdf') {
    require '../vendor/autoload.php'; // Include TCPDF Library
    $pdf = new TCPDF();
    $pdf->AddPage();
    $pdf->SetFont('helvetica', '', 12);
    
    $html = '<h2 style="text-align: center; color: #333;">Product Inventory</h2>';
    $html .= '<table border="1" cellpadding="5" cellspacing="0" style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr style="background-color: #f4f4f4; text-align: center; font-weight: bold;">
                        <th width="10%">ID</th>
                        <th width="20%">Product Group</th>
                        <th width="20%">Product</th>
                        <th width="20%">Company</th>
                        <th width="15%">Part No</th>
                        <th width="15%">Sale Rate</th>
                    </tr>
                </thead>
                <tbody>';
    foreach ($data as $row) {
        $html .= '<tr>
                    <td>'.$row['id'].'</td>
                    <td>'.$row['ProductGroup'].'</td>
                    <td>'.$row['Product'].'</td>
                    <td>'.$row['Company'].'</td>
                    <td>'.$row['PartNo'].'</td>
                    <td>'.$row['SaleRate'].'</td>
                  </tr>';
    }
    $html .= '</tbody></table>';
    
    $pdf->writeHTML($html, true, false, true, false, '');
    $pdf->Output('Download.pdf', 'D');
    exit;
}
?>
