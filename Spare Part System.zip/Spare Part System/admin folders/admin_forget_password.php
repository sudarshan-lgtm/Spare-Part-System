<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forget Password</title>
    <style>
        /* General Styling */
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #EEF2FE;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        /* Forget Password Form */
        .forget-password-form {
            background: #fff;
            backdrop-filter: blur(10px);
            padding: 30px;
            border-radius: 18px;
            text-align: center;
            width: 90%;
            max-width: 400px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            animation: fadeIn 0.5s ease-in-out;
        }
        /* Title */
        .forget-password-form h2 {
            color: #333;
            font-size: 22px;
            margin-bottom: 15px;
        }
        /* Back Button */
        .back {
            background: transparent;
            border: 2px solid black;
            color: #333;
            font-size: 20px;
            padding: 8px 15px;
            border-radius: 50%;
            cursor: pointer;
            transition: 0.3s;
            position: absolute;
            top: 15px;
            left: 15px;
        }
        .back:hover {
            background: linear-gradient(135deg, #1d3557, #457b9d, #a8dadc);
            color:rgb(0, 100, 167);
        }
        /* Input Field */
        input[type="email"] {
            width: 90%;
            padding: 12px;
            margin: 8px 0;
            border: 1px solid black;
            background: transparent;
            color: black;
            border-radius: 4px;
            font-size: 16px;
        }
        input[type="email"]::placeholder {
            color: gray;
        }
        /* Submit Button */
        button[type="submit"] {
            width: 80%;
            padding: 12px;
            background-color: #1d3557;
            color: #fff;
            border: none;
            border-radius: none;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }
        button[type="submit"]:hover {
             background-color: #457b9d;
        }
        .error {
            color: red;
            text-align: left;
            margin-left: 12px;
            font-size: 14px;
        }
        /* Animations */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: scale(0.9);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }
        /* Responsive Design */
        @media (max-width: 768px) {
            .forget-password-form {
                width: 80%;
            }
        
            .back {
                top: 10px;
                left: 10px;
            }
        }
        @media (max-width: 480px) {
            .forget-password-form {
                width: 80%;
            }
            input[type="email"] {
                font-size: 14px;
            }
            button[type="submit"] {
                font-size: 14px;
                padding: 10px;
            }
        }
        /* Landscape Mode Adjustments */
        @media screen and (max-width: 768px) and (orientation: landscape) {
            .forget-password-form {
                width: 50%;
            }
        }
    </style>
</head>
<body>
    <?php include("preloader.html"); ?>
    <div class="forget-password-form">
        <h2>🔐 Forget Password</h2>
        <a href="admin_login.php"><button class="back" type="button">←</button></a>
        <form action="admin_process_forget_password.php" method="POST">
            <label for="email">Enter your Registered Email:</label><br>
            <input type="email" id="email" name="email" placeholder="Email" required>
            <span id="emailError" class="error" style="color:red; text-align: left; margin-left:12px;">Enter a valid email address</span>
            <br><br>
            <button type="submit">Send Reset Link</button>
        </form>
    </div>
    <script>
        //Email Validation
        document.addEventListener("DOMContentLoaded", function () {
            let container = document.getElementById("container");
            let form = document.querySelector("form");
            let emailInput = document.getElementById("email");
            let emailError = document.getElementById("emailError");

            emailError.style.display = "none"; // Hide error message initially

            emailInput.addEventListener("input", function () {
                validateEmail();
            });

            form.addEventListener("submit", function (event) {
                if (!validateEmail()) {
                    event.preventDefault(); // Stop form submission if email is invalid
                }
            });

            function validateEmail() {
                let emailPattern = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;

                if (!emailPattern.test(emailInput.value)) {
                    emailError.style.display = "block";
                    return false;
                } else {
                    emailError.style.display = "none";
                    return true;
                }
            }
        });
    </script>
</body>
</html>
