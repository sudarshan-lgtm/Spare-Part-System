// Print table data
function printTableData() {
    // Get the table rows
    const table = document.querySelector('#ordersTable');
    const tableRows = table.querySelectorAll('tbody tr');

    // Prepare a new table for printing
    let printContent = `
    <table border="1" class="table table-bordered" style="width: 100%; border-collapse: collapse; text-align: left; margin-right:10px;">
        <thead>
            <tr>
                <th>Sr. No</th>
                <th>Product</th>
                <th>Account</th>
                <th>Customer Full Name</th>
                <th>Account Type</th>
                <th>Batch</th>
                <th>Company</th>
                <th>Part No</th>
                <th>Purchase Rate</th>
                <th>Total Sale Rate</th>
                <th>Enter Sale Rate</th>
                <th>Updated Sale Rate</th>
                <th>Closing Qty</th>
                <th>Location</th>
                <th>Quantity</th>
                <th>Feedback</th>
                <th>Order Date</th>
            </tr>
        </thead>
        <tbody>
    `;

    // Loop through each row to get data for printing
    tableRows.forEach((row, index) => {
        const columns = row.querySelectorAll('td');

        if (columns.length > 0) {
            const srNo = index + 1; // Corrected Sr. No

            const enterSaleRateInput = columns[11].querySelector('input'); // Select input field
            const enterSaleRate = enterSaleRateInput ? enterSaleRateInput.value : '';

            const updatedSaleRateCell = columns[12]; // Updated Sale Rate cell
            const updatedSaleRate = updatedSaleRateCell ? updatedSaleRateCell.textContent : '';

            printContent += `
            <tr>    
                <td>${srNo}</td>
                <td>${columns[2].textContent}</td>
                <td>${columns[3].textContent}</td>
                <td>${columns[4].textContent}</td>
                <td>${columns[5].textContent}</td>
                <td>${columns[6].textContent}</td>
                <td>${columns[7].textContent}</td>
                <td>${columns[8].textContent}</td>
                <td>${columns[9].textContent}</td>
                <td>${columns[10].textContent}</td>
                <td>${enterSaleRate}</td>
                <td>${updatedSaleRate}</td>
                <td>${columns[13].textContent}</td>
                <td>${columns[14].textContent}</td>
                <td>${columns[15].textContent}</td>
                <td>${columns[16].textContent}</td>
                <td>${columns[17].textContent}</td>
            </tr>
            `;
        }
    });

    // Close the table
    printContent += `
        </tbody>
    </table>
    `;

    // Open a new window and print
    const printWindow = window.open('', '', 'width=800, height=600');
    printWindow.document.write('<html><head><title>RJ AUTO HEAVEN</title>');
    printWindow.document.write('<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">');
    printWindow.document.write('</head><body>');
    printWindow.document.write('<h2 style="text-align: center; margin-bottom: 20px; margin-top:10px;">RJ AUTO HEAVEN</h2>');
    printWindow.document.write(printContent);
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.print();
}