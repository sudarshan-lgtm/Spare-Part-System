<?php
include '../db.php';

$result = $conn->query("SELECT COUNT(*) as count FROM cart");
$row = $result->fetch_assoc();
echo $row['count'];

$conn->close();
?>
