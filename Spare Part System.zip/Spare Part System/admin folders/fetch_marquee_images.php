<?php
include '../db.php';

$query = "SELECT imagePath FROM cart";  // Get all image paths from the cart
$result = $conn->query($query);

$images = [];

if ($result->num_rows > 0) {
    // Store all image paths in an array
    while ($row = $result->fetch_assoc()) {
        $images[] = $row['imagePath'];
    }

    // Return the images as a JSON response
    echo json_encode(['images' => $images]);
} else {
    // If no images found, return an empty array
    echo json_encode(['images' => []]);
}

$conn->close();
?>
