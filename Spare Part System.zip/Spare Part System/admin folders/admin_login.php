<?php
session_start();
require_once("../db.php");

// जर आधीच लॉगिन केले असेल तर डायरेक्ट डॅशबोर्डला पाठवा
if (isset($_SESSION["user_id"])) {
header("Location: admin_dashboard.php");
exit();
}

$login_success = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
$username = mysqli_real_escape_string($conn, $_POST["username"]);
$password = $_POST["password"];

// यूजर तपासणीसाठी SQL स्टेटमेंट तयार करा
$sql = "SELECT id, fullname, password FROM users WHERE username = ?";
$stmt = $conn->prepare($sql);

// जर prepare अयशस्वी झाले तर एरर दाखवा
if (!$stmt) {
die("Prepare failed: " . $conn->error);
}

$stmt->bind_param("s", $username);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($user_id, $fullname, $hashed_password);
$stmt->fetch();

if ($stmt->num_rows > 0 && password_verify($password, $hashed_password)) {
// युजर सेशन मध्ये सेट करा
$_SESSION["user_id"] = $user_id;
$_SESSION["fullname"] = $fullname;

// लॉग टेबल मध्ये entry घालणे
$login_time = date("Y-m-d H:i:s");
$log_sql = "INSERT INTO user_logs (user_id, fullname, login_time) VALUES (?, ?, ?)";
$log_stmt = $conn->prepare($log_sql);

if (!$log_stmt) {
die("Log insert prepare failed: " . $conn->error);
}

$log_stmt->bind_param("iss", $user_id, $fullname, $login_time);
$log_stmt->execute();
$log_stmt->close(); // ✅ स्टेटमेंट close करणे अत्यंत महत्वाचे आहे

$stmt->close(); // ✅ मुख्य स्टेटमेंट close करा

$login_success = true;

// यशस्वी लॉगिन झाल्यावर पुढील पेजला जा
echo "<script>localStorage.setItem('login_success', 'true'); window.location.href='admin_dashboard.php';</script>";
} else {
echo "<script>alert('Invalid username or password!');</script>";
$stmt->close(); // ❗ अयशस्वी attempt नंतर पण close करणे आवश्यक आहे
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<link rel="icon" href="../image/icon.png" type="image/png">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Icon Font Stylesheet -->
<!-- Bootstrap 5 CDN -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Font Awesome CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<link rel="stylesheet" href="../admin folders/css/admin_login.css">
<title>Admin</title>
</head>
<body>
<?php include("preloader.html"); ?>
<div class="login-card">
<h2>Admin Login</h2>
<form action="" method="POST">
<div class="input-group">
<span class="input-group-text"><i class="fas fa-user"></i></span>
<input type="text" class="form-control" name="username" placeholder="Username" required oninput="validateUsername(this)" minlength="4" maxlength="16" title="Username can only contain letters and numbers">
</div>
<div class="input-group">
<span class="input-group-text"><i class="fas fa-lock"></i></span>
<input type="password" class="form-control" name="password" placeholder="Password" required pattern="[A-Za-z0-9@#$%^&*()_+!]+" minlength="8" maxlength="20" title="Password can include letters, numbers, and special characters (@#$%^&*()_+=!).">
</div>
<button type="submit" class="btn btn-primary mt-2" name="SignIn">Sign In</button>
<div class="extra">
<a href="admin_forget_password.php">🔐 Forget Password?</a>
</div>
</form>
</div>

<!-- Optional: Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<?php
if (isset($_POST['SignIn'])) {
$login_success = false;

$username = mysqli_real_escape_string($conn, $_POST['username']);
$password = $_POST['password'];

$query = "SELECT * FROM `users` WHERE username = '$username'";
$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) == 1) {
$row = mysqli_fetch_assoc($result);
$hashed_password = $row['password'];

if (password_verify($password, $hashed_password)) {
$_SESSION['id'] = $row['id'];
} else {
$login_success = true;
echo "<script>localStorage.setItem('login_success', 'true'); window.location.href='admin_dashboard.php';</script>";
}
} else {
echo "<script>alert('No such user found. Please check the username.');</script>";
}
}
?>
<script>
function validateUsername(input) {
input.value = input.value.replace(/[^a-zA-Z0-9_]/g, '');
}
</script>
</body>
</html>