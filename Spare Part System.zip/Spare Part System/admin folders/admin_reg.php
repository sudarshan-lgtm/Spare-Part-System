<?php
require_once("../db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT); // Encrypt password
    $email = $_POST["email"];
    $fullname = $_POST["fullname"];
    $mobile = $_POST["mobile"];
    $dob = $_POST["dob"];
    $account_type = $_POST['account_type'];

    // Insert user data into the database
    $sql = "INSERT INTO users (username, password, email, fullname, mobile, dob, account_type) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssss", $username, $password, $email, $fullname, $mobile, $dob, $account_type);

    if ($stmt->execute()) {
        echo "Registration successful!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: #EEF2FE;
        }
        .container {
            width: 125%;
            max-width: 400px;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
            margin-top: 7%;
            margin-bottom: 7%;
        }
        
        /* Password Requirements */
        #password-requirements {
            text-align: left;
            margin-left: 10px;
            padding: 5px;
            border: 1px solid #ccc;
            background-color: transparent;
            margin-top: -5px;
        }

        #password-requirements label {
            display: block;
            color: red;
            font-size: 14px;
        }

        #password-requirements label.valid {
            color: green;
        }
        .error {
            color: red;
            text-align: left;
            margin-left: 12px;
            font-size: 14px;
        }
        .button:disabled {
            background: gray;
            cursor: not-allowed;
        }
        .container input[type="text"],
        .container input[type="email"],
        .container input[type="date"] {
            width: 90%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }
        .input-field input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }
        .input-field select {
            width: 95%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-top: 10px;
            margin-bottom: 10px;
            font-size: 16px;
            transition: all 0.3s ease;
        }
        .container button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        .container button:hover {
            background-color: #0056b3;
        }
        .container p a {
            color: #007bff;
            text-decoration: none;
            font-size: 14px;
        }
        .container p a:hover {
            text-decoration: underline;
        }
        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                max-width: 90%;
                padding: 15px;
            }
            .container input[type="text"],
            .container input[type="email"],
            .container input[type="date"],
            .container button {
                font-size: 14px;
            }
            .container p a {
                font-size: 12px;
            }
        }
        @media (max-width: 576px) {
            .container {
                max-width: 100%;
                padding: 10px;
            }
            .container input[type="text"],
            .container input[type="email"],
            .container input[type="date"],
            .container button {
                font-size: 12px;
            }
            .container p a {
                font-size: 10px;
            }
        }
    </style>
</head>
<body>
    <?php include("preloader.html"); ?>
    <form action="admin_reg.php" method="POST">
        <div class="container">
            <h2>Registration Form</h2>
            <label style="text-align:left;">Username :</label>
            <input type="text" placeholder="Username" name="username" required pattern="[A-Za-z0-9]+"  minlength="4" maxlength="16" title="Username can only contain letters and numbers"><br>
            <label>Password :</label>
            <input type="text" placeholder="Password" id="password" name="password" required pattern="[A-Za-z0-9@#$%^&*()_+!]+"  minlength="8" maxlength="20" title="Password can include letters, numbers, and special characters (@#$%^&*()_+=!).">
            <span id="passwordError" class="error" style="display: none;">This field is required</span>
            <br>
            <!-- Password Validation Messages -->
                <div id="password-requirements">
                    <label><input type="checkbox" id="length-check" disabled> Minimum 8 characters</label>
                    <label><input type="checkbox" id="uppercase-check" disabled> At least one uppercase letter</label>
                    <label><input type="checkbox" id="number-check" disabled> At least one number</label>
                    <label><input type="checkbox" id="special-check" disabled> At least one special character (~!@#$%^&*()_+)</label>
                </div>
                <label>Email :</label>
            <input type="email" placeholder="Email" id="email" name="email" required>
            <span id="emailError" class="error" style="color:red; text-align: left; margin-left:12px;">Enter a valid email address</span>
            <br>
            <label>Full Name :</label>
            <input type="text" placeholder="Full name" name="fullname" required oninput="validateLetters(this)" maxlength="40"><br>
            <label>Mobile Number :</label>
            <input type="text" placeholder="Mobile number" name="mobile" required oninput="validateNumbers(this)" maxlength="10"><br>
            <label>Date Of Birth :</label>
            <input type="date" placeholder="Date of birth" name="dob" required><br>
            <div class="input-field">
            <label>Account Type :</label>
                    <select name="account_type" required>
                        <option value="">Select Admin</option>
                        <option value="Admin">Admin</option>
                    </select>
                </div>
            <p><a href="admin_login.php">Already registered</a></p>
            <button type="submit"><a href="admin_login.php"></a>Submit</button>
        </div>
    </form>
    <script>
        function validateLetters(input) {
            input.value = input.value.replace(/[^a-zA-Z\s]/g, '');
        }
        function validateNumbers(input)  {
            input.value = input.value.replace(/[^0-9]/g, '').substring(0,10);
        }
        function validateUsername(input) {
            input.value = input.value.replace(/[^a-zA-Z0-9_]/g, '');
        }
//Email Validation
        document.addEventListener("DOMContentLoaded", function () {
            let container = document.getElementById("container");
            let form = document.querySelector("form");
            let emailInput = document.getElementById("email");
            let emailError = document.getElementById("emailError");

            emailError.style.display = "none"; // Hide error message initially

            emailInput.addEventListener("input", function () {
                validateEmail();
            });

            form.addEventListener("submit", function (event) {
                if (!validateEmail()) {
                    event.preventDefault(); // Stop form submission if email is invalid
                }
            });

            function validateEmail() {
                let emailPattern = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;

                if (!emailPattern.test(emailInput.value)) {
                    emailError.style.display = "block";
                    return false;
                } else {
                    emailError.style.display = "none";
                    return true;
                }
            }
        });
//Password Validation
        document.addEventListener("DOMContentLoaded", function () {
            let passwordInput = document.getElementById("password");
            let submitButton = document.getElementById("submitButton");
            let passwordError = document.getElementById("passwordError");

            // Checkboxes for password validation
            let lengthCheck = document.getElementById("length-check");
            let uppercaseCheck = document.getElementById("uppercase-check");
            let numberCheck = document.getElementById("number-check");
            let specialCheck = document.getElementById("special-check");

            function validatePassword() {
                let password = passwordInput.value;
                let isValid = true;

                // Check Length (Minimum 8 characters)
                if (password.length >= 8) {
                    lengthCheck.checked = true;
                    lengthCheck.parentElement.classList.add("valid");
                } else {
                    lengthCheck.checked = false;
                    lengthCheck.parentElement.classList.remove("valid");
                    isValid = false;
                }

                // Check Uppercase Letter
                if (/[A-Z]/.test(password)) {
                    uppercaseCheck.checked = true;
                    uppercaseCheck.parentElement.classList.add("valid");
                } else {
                    uppercaseCheck.checked = false;
                    uppercaseCheck.parentElement.classList.remove("valid");
                    isValid = false;
                }

                // Check Number
                if (/[0-9]/.test(password)) {
                    numberCheck.checked = true;
                    numberCheck.parentElement.classList.add("valid");
                } else {
                    numberCheck.checked = false;
                    numberCheck.parentElement.classList.remove("valid");
                    isValid = false;
                }

                // Check Special Character
                if (/[~!@#$%^&*()_+]/.test(password)) {
                    specialCheck.checked = true;
                    specialCheck.parentElement.classList.add("valid");
                } else {
                    specialCheck.checked = false;
                    specialCheck.parentElement.classList.remove("valid");
                    isValid = false;
                }

                // If any condition is false, show error, else hide it
                if (!isValid) {
                    passwordError.style.display = "block";
                    passwordInput.style.border = "1px solid red";
                    submitButton.disabled = true;
                } else {
                    passwordError.style.display = "none";
                    passwordInput.style.border = "1px solid green";
                    submitButton.disabled = false;
                }
            }

            passwordInput.addEventListener("input", validatePassword);

            // Prevent form submission if password is invalid
            document.getElementById("registrationForm").addEventListener("submit", function (event) {
                if (submitButton.disabled) {
                    event.preventDefault();
                    passwordError.style.display = "block";
                    passwordInput.style.border = "1px solid red";
                }
            });
        });
    </script>
</body>
</html>