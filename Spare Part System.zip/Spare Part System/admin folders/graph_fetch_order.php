<?php
session_start(); 
include '../db.php';

$fullname = "";
$customer_id = isset($_SESSION['id']) ? $_SESSION['id'] : null;

if ($customer_id) {
    $query = "SELECT fullname FROM customer WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $customer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $fullname = htmlspecialchars($row['fullname']);
    }
    $stmt->close();
}

$today = date('Y-m-d');
$weekStart = date('Y-m-d', strtotime('monday this week'));
$weekEnd = date('Y-m-d', strtotime('sunday this week'));
$lastWeekStart = date('Y-m-d', strtotime('monday last week'));
$lastWeekEnd = date('Y-m-d', strtotime('sunday last week'));
$sixMonthsAgo = date('Y-m-d', strtotime('-6 months'));
$thisYearStart = date('Y-01-01');
$lastYearStart = date('Y-01-01', strtotime('-1 year'));
$lastYearEnd = date('Y-12-31', strtotime('-1 year'));
$monthStart = date('Y-m-01');

$response = [
    'lastWeekOrders' => 0,
    'todayOrders' => 0,
    'thisWeekOrders' => 0,
    'thisMonthOrders' => 0,
    'thisSixMonthOrders' => 0,
    'thisYearOrders' => 0,
    'lastYearOrders' => 0,
];

$queries = [
    'todayOrders' => "SELECT COUNT(*) as count FROM submitted_orders WHERE DATE(order_date) = ?",
    'thisWeekOrders' => "SELECT COUNT(*) as count FROM submitted_orders WHERE DATE(order_date) BETWEEN ? AND ?",
    'lastWeekOrders' => "SELECT COUNT(*) as count FROM submitted_orders WHERE DATE(order_date) BETWEEN ? AND ?",
    'thisMonthOrders' => "SELECT COUNT(*) as count FROM submitted_orders WHERE DATE(order_date) BETWEEN ? AND ?",
    'thisSixMonthOrders' => "SELECT COUNT(*) as count FROM submitted_orders WHERE DATE(order_date) BETWEEN ? AND ?",
    'thisYearOrders' => "SELECT COUNT(*) as count FROM submitted_orders WHERE DATE(order_date) BETWEEN ? AND ?",
    'lastYearOrders' => "SELECT COUNT(*) as count FROM submitted_orders WHERE DATE(order_date) BETWEEN ? AND ?",
];

$params = [
    'todayOrders' => [$today],
    'thisWeekOrders' => [$weekStart, $weekEnd],
    'lastWeekOrders' => [$lastWeekStart, $lastWeekEnd],
    'thisMonthOrders' => [$monthStart, $today],
    'thisSixMonthOrders' => [$sixMonthsAgo, $today],
    'thisYearOrders' => [$thisYearStart, $today],
    'lastYearOrders' => [$lastYearStart, $lastYearEnd],
];

foreach ($queries as $key => $query) {
    $stmt = $conn->prepare($query);
    if (count($params[$key]) == 1) {
        $stmt->bind_param("s", $params[$key][0]);
    } else {
        $stmt->bind_param("ss", $params[$key][0], $params[$key][1]);
    }
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $response[$key] = $result['count'] ?? 0;
    $stmt->close();
}

echo json_encode($response);
$conn->close();
?>
