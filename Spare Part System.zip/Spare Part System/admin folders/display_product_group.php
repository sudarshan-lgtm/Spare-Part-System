<?php
session_start();
include '../db.php';

if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$fullname = "Admin";
$account_type = "Admin";
if (isset($_GET['name'])) {
    $fullname = mysqli_real_escape_string($conn, htmlspecialchars($_GET['name']));

    // Fetch account_type from the database based on the fullname
    $query = "SELECT account_type FROM admission WHERE fullname = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $fullname);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $account_type);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);
}

// Fetch distinct ProductGroups from ProductInventory
$query1 = "SELECT DISTINCT ProductGroup FROM productinventory";
$result1 = mysqli_query($conn, $query1);

// Fetch distinct ProductGroups from KolhapurData
$query2 = "SELECT DISTINCT ProductGroup FROM kolhapurdata";
$result2 = mysqli_query($conn, $query2);

// Combine all unique groups
$allGroups = [];

while ($row = mysqli_fetch_assoc($result1)) {
    $group = htmlspecialchars($row['ProductGroup']);
    if (!in_array($group, $allGroups)) {
        $allGroups[] = $group;
    }
}

while ($row = mysqli_fetch_assoc($result2)) {
    $group = htmlspecialchars($row['ProductGroup']);
    if (!in_array($group, $allGroups)) {
        $allGroups[] = $group;
    }
}

// Get all available images from folder
$imageFolderPath = "uploads/folders";
$imageFiles = glob("$imageFolderPath/*.{jpg,jpeg,png,gif,webp}", GLOB_BRACE);

// Match groups with images
$finalProductGroups = [];
foreach ($allGroups as $group) {
    $matchedImage = null;
    foreach ($imageFiles as $image) {
        $imageName = pathinfo($image, PATHINFO_FILENAME);
        if (strcasecmp($group, $imageName) == 0) {
            $matchedImage = $image;
            break;
        }
    }
    $finalProductGroups[] = [
        'group' => $group,
        'imagePath' => $matchedImage ?? 'assets/default-image.png' // fallback image
    ];
}

// ✅ Free result memory
if ($result1) {
    mysqli_free_result($result1);
}
if ($result2) {
    mysqli_free_result($result2);
}
mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../admin folders/css/display_product_group.css">
    <title>Product Groups</title>
    <script>
        let suggestionIndex = -1; // Tracks the selected suggestion
        let suggestionsData = []; // Stores the fetched suggestions

        function searchProductGroup() {
            const input = document.getElementById("searchInput").value.trim();
            if (input === "") {
                document.getElementById("suggestions").innerHTML = "";
                suggestionsData = [];
                suggestionIndex = -1;
                return;
            }

            // Fetch product group suggestions
            fetch(`display_product_group_fetch_suggestions.php?query=${encodeURIComponent(input)}`)
                .then(response => response.json())
                .then(data => {
                    suggestionsData = data;
                    suggestionIndex = -1; // Reset selection index
                    const suggestions = document.getElementById("suggestions");
                    suggestions.innerHTML = ""; // Clear previous suggestions

                    data.forEach((group, index) => {
                        const div = document.createElement("div");
                        div.textContent = group;
                        div.classList.add("suggestion-item");
                        div.dataset.index = index;
                        div.onclick = () => fetchGroupDetails(group);

                        suggestions.appendChild(div);
                    });
                });
        }

        function handleKeyDown(event) {
            const suggestions = document.querySelectorAll(".suggestion-item");
            if (suggestions.length === 0) return;

            if (event.key === "ArrowDown") {
                event.preventDefault();
                suggestionIndex = (suggestionIndex + 1) % suggestions.length;
            } else if (event.key === "ArrowUp") {
                event.preventDefault();
                suggestionIndex = (suggestionIndex - 1 + suggestions.length) % suggestions.length;
            } else if (event.key === "Enter") {
                event.preventDefault();
                if (suggestionIndex >= 0 && suggestionIndex < suggestionsData.length) {
                    fetchGroupDetails(suggestionsData[suggestionIndex]);
                }
                return;
            }

            // Remove previous selection and add new selection
            suggestions.forEach((item, index) => {
                item.classList.toggle("selected", index === suggestionIndex);
            });

            // Scroll into view if necessary
            if (suggestionIndex >= 0) {
                suggestions[suggestionIndex].scrollIntoView({ block: "nearest", behavior: "smooth" });
            }
        }

        function fetchGroupDetails(groupName) {
            const fullname = "<?= $fullname ?>"; // Get the fullname value from PHP
            const account_type = "<?= $account_type ?>";
            window.location.href = `display_products.php?group=${encodeURIComponent(groupName)}&name=${encodeURIComponent(fullname)}&account_type=${encodeURIComponent(account_type)}`;
        }

        document.getElementById("searchInput");
        // Search Part NO JS
        function searchProduct() {
            const partNo = document.getElementById("partNo").value;
            if (!partNo) {
                alert("Please enter a part number to search.");
                return;
            }

            // Redirect to search_partNo.php with the searched part number
            window.location.href = `search_partNo.php?partNo=${encodeURIComponent(partNo)}`;
            const fullname = "<?= $fullname ?>"; // Get the fullname value from PHP
            const account_type = "<?= $account_type ?>";
            window.location.href = `search_partNo.php?partNo=${encodeURIComponent(partNo)}&name=${encodeURIComponent(fullname)}&account_type=${encodeURIComponent(account_type)}`;
        }
        //Search All Products in database
        function searchAllProducts() {
            const query = document.getElementById("productSearchInput").value;
            const fullname = "<?= $fullname ?>";
            const account_type = "<?= $account_type ?>";

            if (query.length === 0) {
                document.getElementById("allProductSuggestions").innerHTML = "";
                return;
            }

            const xhr = new XMLHttpRequest();
            xhr.open("GET", `search_all_products.php?query=${encodeURIComponent(query)}&name=${encodeURIComponent(fullname)}&account_type=${encodeURIComponent(account_type)}`, true);
            xhr.onload = function () {
                if (xhr.status === 200) {
                    document.getElementById("allProductSuggestions").innerHTML = xhr.responseText;
                }
            };
            xhr.send();
        }
    </script>
</head>
<body>
    <?php include("preloader.html"); ?>
    <!-- Navigation Bar -->
    <nav class="navbar">
            <!--<a href="javascript:history.back()" class="btn-back">  <i class="bi bi-arrow-left-circle"></i></a> -->
        <a href='admin_dashboard.php' class='back-button'><img src="../image/h1.png" class="home" alt="ok"></a>
        <img src="../image/RJ bg.png" class="logo" alt="RJ">
        <a href="#" onclick="toggleCalculator()">
            <img src="../image/logo/calculator.png" alt="calculator" class="calculator">
        </a>
        <a href="../admin folders/cart.php" class="cart-icon" onclick="openCart()"> <img src="../image/shopping-cart.png" class="cart" alt="tau"></a>
    </nav>

    <!-- Calculator Modal -->
    <div id="calculatorPopup" class="popup">
        <div class="popup-content">
            <span class="close-btn"></span>
            <input type="text" id="display" class="display" readonly>
            <div class="buttons">
                <button onclick="clearDisplay()" class="clear">C</button>
                <button onclick="backspace()">⌫</button>
                <button onclick="appendToDisplay('%')">%</button>
                <button onclick="appendToDisplay('/')">÷</button>
                
                <button onclick="appendToDisplay('7')">7</button>
                <button onclick="appendToDisplay('8')">8</button>
                <button onclick="appendToDisplay('9')">9</button>
                <button onclick="appendToDisplay('*')">×</button>
                
                <button onclick="appendToDisplay('4')">4</button>
                <button onclick="appendToDisplay('5')">5</button>
                <button onclick="appendToDisplay('6')">6</button>
                <button onclick="appendToDisplay('-')">−</button>
                
                <button onclick="appendToDisplay('1')">1</button>
                <button onclick="appendToDisplay('2')">2</button>
                <button onclick="appendToDisplay('3')">3</button>
                <button onclick="appendToDisplay('+')">+</button>
                
                <button onclick="appendToDisplay('0')">0</button>
                <button onclick="appendToDisplay('.')">.</button>
                <button onclick="calculateResult()" class="equal">=</button>
            </div>
        </div>
    </div>
    <!-- Calculator Close -->
    <!-- Display Selected Full Name -->
    <div class="fixed-container">
        <?php if (!empty($fullname)): ?>
            <h2 class="fullname"><?= $fullname ?> (<?= $account_type ?>)!</h2>
        <?php endif; ?>
        <a href="admission.php" class="addCustomer">Add Customer</a>
    </div>
    <div class="search-wrapper shadow p-3 position-fixed top-0 w-100 z-3 mt-5 pt-4 mr-5" style="background-color:#E9EAEC;">
        <div class="container-fluid">
            <div class="row g-3 flex-column flex-md-row justify-content-center align-items-start">
    
                <!-- Product Group Search -->
                <div class="col-12 col-md-4">
                    <form onsubmit="return false;">
                        <input type="text" id="searchInput" class="form-control" placeholder="Search Product Group" oninput="searchProductGroup()" required>
                    </form>
                    <div id="suggestions" class="suggestion-box mt-2"></div>
                </div>
    
                <!-- Part No Search with Button -->
                <div class="col-12 col-md-4 d-flex flex-column align-items-stretch">
                    <form onsubmit="return false;" class="d-flex">
                        <input type="text" id="partNo" class="form-control me-2" placeholder="Search Part Number" required>
                        <button onclick="searchProduct()" class="btn btn-primary">Search</button>
                    </form>
                    <div id="partNoSuggestions" class="suggestion-box mt-2"></div>
                </div>
    
                <!-- All Products Search -->
                <div class="col-12 col-md-4">
                    <form onsubmit="return false;">
                        <input type="text" id="productSearchInput" class="form-control" placeholder="Search Product (All Tables)" oninput="searchAllProducts()" required>
                    </form>
                    <div id="allProductSuggestions" class="suggestion-box mt-2"></div>
                </div>
    
            </div>
        </div>
    </div>

</div> 
    <h1 class="product_group_name">Product Groups <span style="font-size: 18px; color: #555;">(<?= count($finalProductGroups) ?>)</span>
</h1>
     <!-- Product Groups from ProductInventory -->
<div class="file-container">
    <?php foreach ($finalProductGroups as $product): ?>
        <div class='card' onclick="fetchGroupDetails('<?= $product['group'] ?>')">
            <img src='<?= $product['imagePath'] ?>' alt='<?= $product['group'] ?>' loading="lazy">
            <h2><?= $product['group'] ?></h2>
        </div>
    <?php endforeach; ?>
</div>
<script>
    //Keyboard Shortcut Key
    document.addEventListener("keydown", function(event) {
        const activeElement = document.activeElement;
        
        // Check if the active element is an input field
        if (event.key === "Backspace" && (activeElement.tagName !== "INPUT" && activeElement.tagName !== "TEXTAREA")) {
            event.preventDefault();
            window.history.back(); 
        }
    });
    document.addEventListener("keydown", function(event) {
        if (event.ctrlKey && event.key.toLowerCase() === "s") {
            event.preventDefault(); 
            const searchInput = document.getElementById("searchInput");
            if (searchInput) {
                searchInput.focus();
            }
        }
    });
    document.addEventListener("keydown", function(event) {
        if (event.shiftKey && event.key.toLowerCase() === "s") {
            event.preventDefault(); 
            const partNoInput = document.getElementById("partNo");
            if (partNoInput) {
                partNoInput.focus();
            }
        }
    });
</script>   
<script>
    function toggleCalculator() {
        let popup = document.getElementById("calculatorPopup");
        popup.style.display = (popup.style.display === "block") ? "none" : "block";
    }

    function appendToDisplay(value) {
        document.getElementById("display").value += value;
    }

    function clearDisplay() {
        document.getElementById("display").value = "";
    }

    function calculateResult() {
        try {
            let expression = document.getElementById("display").value;
            expression = expression.replace(/%/g, "/100"); // Convert % to division
            document.getElementById("display").value = eval(expression);
        } catch {
            document.getElementById("display").value = "Error";
        }
    }

    function backspace() {
        let display = document.getElementById("display");
        display.value = display.value.slice(0, -1);
    }
</script>
<script>
  // Check if the cookie exists
  if (!document.cookie.split('; ').find(row => row.startsWith('visited='))) {
    // Set cookie for 7 days
    document.cookie = "visited=true; max-age=" + 60 * 60 * 24 * 7 + "; path=/";
    console.log("First-time visit: full content loading");
  } else {
    console.log("Returning visitor: use optimized content if needed");
    // तुम्ही इथे placeholder images किंवा low-res images लावू शकता
  }
</script>

</body>
</html>
