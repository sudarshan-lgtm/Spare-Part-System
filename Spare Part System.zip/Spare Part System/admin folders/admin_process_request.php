<?php
session_start();
include '../db.php';

// Prevent accessing this page without login
if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}

// Function to check if a column is already hidden
function isColumnHidden($conn, $column, $userType, $userId) {
    $query = "SELECT COUNT(*) as count FROM hiddencolumns WHERE column_name = ? AND user_type = ? AND user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssi", $column, $userType, $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $result->close();
    $stmt->close();
    return $row['count'] > 0;
}

// Function to hide default columns for new customer/kolhapur_customer accounts
function hideDefaultColumns($conn, $userType, $userId) {
    if (!in_array($userType, ['customer', 'kolhapur_customer'])) {
        return false;
    }
    $defaultHiddenColumns = [
        'Batch', 'PurchaseRate', 'Exp', 'Margin', 'PurchaseCode',
        'SaleRate', 'ReceiptQty', 'IssueQty', 'ClosingQty', 'Location'
    ];
    $inserted = false;
    foreach ($defaultHiddenColumns as $column) {
        if (!isColumnHidden($conn, $column, $userType, $userId)) {
            $query = "INSERT INTO hiddencolumns (column_name, user_type, user_id) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ssi", $column, $userType, $userId);
            $stmt->execute();
            $stmt->close();
            $inserted = true;
        }
    }
    return $inserted;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $area = $_POST['area'];
    $gstin = $_POST['gstin'];
    $dob = $_POST['dob'];
    $account_type = $_POST['account_type'];

    if (isset($_POST['approve'])) {
        // Determine the correct table based on account_type
        $table = "";
        if ($account_type == 'customer') {
            $table = "customer";
        } elseif ($account_type == 'member') {
            $table = "member";
        } elseif ($account_type == 'kolhapur_customer') {
            $table = "kolhapur_customer";
        } elseif ($account_type == 'kolhapur_member') {
            $table = "kolhapur_member";
        } elseif ($account_type == 'Warehouse') {
            $table = "warehouse";
        } elseif ($account_type == 'warehouse_kolhapur') {
            $table = "warehouse_kolhapur";
        } else {
            echo "<script>alert('Invalid account type!'); window.location.href='admin_requests.php';</script>";
            exit;
        }

        // Check for duplicate username, email, or mobile
        $check_query = "SELECT * FROM $table WHERE username = ? OR email = ? OR mobile = ?";
        $stmt_check = $conn->prepare($check_query);
        $stmt_check->bind_param("sss", $username, $email, $mobile);
        $stmt_check->execute();
        $result = $stmt_check->get_result();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                if ($row['username'] == $username) {
                    $result->close();            // ✅ added
                    $stmt_check->close(); 
                    echo "<script>alert('Oops! This username is already taken. Try a unique one!'); window.location.href='admin_requests.php';</script>";
                    exit;
                }
                if ($row['email'] == $email) {
                    $result->close();            // ✅ added
                    $stmt_check->close(); 
                    echo "<script>alert('This email is already linked to an account. Try another one!'); window.location.href='admin_requests.php';</script>";
                    exit;
                }
                if ($row['mobile'] == $mobile) {
                    $result->close();            // ✅ added
                    $stmt_check->close(); 
                    echo "<script>alert('This mobile number is already registered. Use a different one!'); window.location.href='admin_requests.php';</script>";
                    exit;
                }
            }
        }
        $result->close();           
        $stmt_check->close();

        // Insert into the table
        $stmt = $conn->prepare("INSERT INTO $table (username, password, fullname, email, mobile, address, city, area, gstin, dob, account_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssssssss", $username, $password, $fullname, $email, $mobile, $address, $city, $area, $gstin, $dob, $account_type);

        if ($stmt->execute()) {
            $newUserId = $conn->insert_id;
            // Hide default columns for customer or kolhapur_customer
            hideDefaultColumns($conn, $account_type, $newUserId);
            // Update request status to 'approved'
            $update_stmt = $conn->prepare("UPDATE requests SET status = ? WHERE id = ?");
            $status = 'approved';
            $update_stmt->bind_param("si", $status, $id);
            $update_stmt->execute();
            $update_stmt->close();
            echo "<script>alert('Request approved successfully!'); window.location.href='admin_requests.php';</script>";
        } else {
            echo "<script>alert('Error: " . $stmt->error . "'); window.location.href='admin_requests.php';</script>";
        }
        $stmt->close();
    } elseif (isset($_POST['reject'])) {
        // Update request status to 'rejected'
        $update_stmt = $conn->prepare("UPDATE requests SET status = ? WHERE id = ?");
        $status = 'rejected';
        $update_stmt->bind_param("si", $status, $id);
        $update_stmt->execute();
        $update_stmt->close();
        echo "<script>alert('Request rejected!'); window.location.href='admin_requests.php';</script>";
    }
}
$conn->close();
?>