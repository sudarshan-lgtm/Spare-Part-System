<?php
session_start();
include '../db.php';

// Set timezone to India (Maharashtra)
date_default_timezone_set("Asia/Kolkata");

// Prevent accessing this page after logout
if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}

$fullname = "";
$customer_id = "";
$account_type = "";
if (isset($_SESSION['id'])) {
    $customer_id = $_SESSION['id']; // Get the logged-in customer ID
    $query = "SELECT fullname FROM admission WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $customer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $fullname = htmlspecialchars($row['fullname']);
    }
    $stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product'])) {
    $selectedProducts = $_POST['product'];
    $fullname = $_POST['fullname'];
    $account_type = $_POST['account_type'];

    // Get current date-time in India timezone
    $currentDateTime = date("Y-m-d H:i:s");

    foreach ($selectedProducts as $productid) {
        $query = "SELECT * FROM cart WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $productid);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();

        if ($result->num_rows > 0) {
            $product = $result->fetch_assoc();
            // Fetch customer ID and account type
            $customer_id = $product['customer_id'];
            $fullname = "";
            $account_type = "";
            $totalSaleRate = $product['totalSaleRate'];

            $submit_id = "RJS_" . uniqid();
            // 🔹 Debugging: Check if order_id is generated correctly
            if (empty($submit_id)) {
                die("Error: Order ID is empty. Debugging required.");
            }

            $orderQuery = "INSERT INTO orders (submit_id, customer_id, customer_fullname, account_type, product, batch, company, partNo, purchaseRate, gst, exp, margin, totalSaleRate, enterSaleRate, updatedSaleRate, closingQty, location, quantity, feedback, is_seen, order_date)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)";
            $orderStmt = $conn->prepare($orderQuery);

            $fullname = $product['fullname'];
            $account_type = $product['account_type'];
            $productName = $product['product'];
            $batch = $product['batch'];
            $company = $product['company'];
            $partNo = $product['partNo'];
            $purchaseRate = $product['purchaseRate'];
            $gst = $product['gst'];
            $exp = $product['exp'];
            $margin = $product['margin'];
            $totalSaleRate = $product['totalSaleRate'];
            $enterSaleRate = $product['enterSaleRate'] ?? "";
            $updatedSaleRate = $product['updatedSaleRate'] ?? "";
            $closingQty = $product['closingQty'];
            $location = $product['location'];
            $quantity = $product['quantity'];
            $feedback = $product['feedback'];

            $orderStmt->bind_param("sissssssdidddssisiss", $submit_id, $customer_id, $fullname, $account_type, $productName, $batch, $company, $partNo, $purchaseRate, $gst, $exp, $margin, $totalSaleRate, $enterSaleRate, $updatedSaleRate, $closingQty, $location, $quantity, $feedback, $currentDateTime);
            $orderStmt->execute();
            $orderStmt->close();

            // Cart madhun delete
            $deleteStmt = $conn->prepare("DELETE FROM cart WHERE id = ? AND customer_id = ?");
            $deleteStmt->bind_param("ii", $productid, $customer_id);
            $deleteStmt->execute();
            $deleteStmt->close();
        }
    }
    header("Location: order.php");
    exit;
}
// Dropdowns
function getDropdownOptions($conn, $accountType)
{
    $query = "SELECT DISTINCT customer_fullname, account_type  FROM orders WHERE account_type = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $accountType);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
    // Use actual account_type from DB in the first option
$row = $result->fetch_assoc();
$options = "<option value=''>Select " . htmlspecialchars($row['account_type']) . "</option>";

if ($row) {
    $value = htmlspecialchars($row['customer_fullname']);
    $options .= "<option value='$value'>$value</option>";
    while ($row = $result->fetch_assoc()) {
        $value = htmlspecialchars($row['customer_fullname']);
        $options .= "<option value='$value'>$value</option>";
    }
}

return $options;
}
//Search Customer_fullname 
$search_customer = isset($_GET['search_customer']) ? trim($_GET['search_customer']) : '';

if (!empty($search_customer)) {
    $stmt = $conn->prepare("SELECT * FROM orders WHERE customer_fullname LIKE ? ORDER BY order_date DESC");
    $likeSearch = "%{$search_customer}%";
    $stmt->bind_param("s", $likeSearch);
} else {
    $stmt = $conn->prepare("SELECT * FROM orders ORDER BY order_date DESC");
}

$stmt->execute();
$result = $stmt->get_result();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="../admin folders/css/order.css">
    <title>Admin Orders</title>
</head>
<body>
    <?php include("preloader.html"); ?>
    <a href='admin_dashboard.php' class='back-button'><img src="../image/h1.png" class="home" alt="ok"></a>
    <h2 class="text-center" style="margin-top:15px; margin-bottom: 20px;">Your Orders</h2>
    <!-- Dropdown Options -->
    <div class="container mt-4">
        <!-- Dropdown Filters -->
        <div class="row mb-3">
            <div class="col-md-3">
                <select id="customerFilter" class="form-select">
                    <?php echo getDropdownOptions($conn, 'customer'); ?>
                </select>
            </div>
            <div class="col-md-3">
                <select id="memberFilter" class="form-select">
                    <?php echo getDropdownOptions($conn, 'member'); ?>
                </select>
            </div>
            <div class="col-md-3">
                <select id="solapurFilter" class="form-select">
                    <?php echo getDropdownOptions($conn, 'kolhapur_member'); ?>
                </select>
            </div>
            <div class="col-md-3">
                <select id="kolhapurFilter" class="form-select">
                    <?php echo getDropdownOptions($conn, 'kolhapur_customer'); ?>
                </select>
            </div>
        </div>
        <!-- Search bar under buttons with proper width and height -->
        <div class="row" style="margin-bottom: -30px;">
            <div class="col-md-4 offset-md-0 mt-1">
                <input type="text" id="searchCustomer" class="form-control form-control-lg" 
                    placeholder="🔍 Search by Customer FullName" 
                    style="height: 45px; font-size: 16px;">
            </div>
            <div id="totalOrders" class="offset-md-0 fw-bold" style="margin-right: 20%;  margin-top: 10px; margin-bottom: -40px;"></div>
        </div>
        <button class="btn btn-primary print-btn hide-on-mobile" style="float: right; margin-bottom: 20px; margin-right: 20px; margin-top: 10px;" onclick="printTableData()">
        <i class="fas fa-print"></i> Print</button>
        <button class="btn btn-danger" id="deleteOrders" style="float: right; margin-bottom: 20px; margin-right: 10px; margin-top: 10px;"><i class="fa fa-trash"></i> Delete Orders</button>
        <a href="orders_submit.php"><button class="btn btn-dark fw-bold px-3 py-1.5 text-light hide-on-mobile" style="float: right; margin-bottom: 20px; margin-right: 20px; margin-top: 10px;"><i class="fas fa-database"></i> Order Reports</button></a>
        
         <!-- Orders Table -->
         <div id="orderTableWrapper">
            <?php
            // Suppose you fetch all orders here
            $highlight_submit_id = isset($_GET['highlight_submit_id']) ? $_GET['highlight_submit_id'] : '';

            // Load all orders initially
            $result = $conn->query("SELECT * FROM orders ORDER BY created_at DESC");
            include 'render_orders_table.php'; // We'll extract table rendering code into a reusable file
            ?>
        </div>
    </div>
    <!-- Loading Modal -->
    <div class="modal fade" id="loadingModal" tabindex="-1" aria-labelledby="loadingModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body text-center">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Submitting...</span>
                    </div>
                    <p class="mt-3" id="modalSubmitId">Submitting orders...</p>
                </div>
            </div>
        </div>
    </div>        
<script src="../admin folders/order_print.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    //Dropdown JS
    $(document).ready(function() {
        function fetchFilteredOrders() {
            var customer = $("#customerFilter").val();
            var member = $("#memberFilter").val();
            var kolhapurMember = $("#solapurFilter").val();
            var kolhapurCustomer = $("#kolhapurFilter").val();
            $.ajax({
                url: "fetch_orders.php",
                type: "POST",
                data: {
                    customer,
                    member,
                    kolhapurMember,
                    kolhapurCustomer
                },
                success: function(response) {
                    $("#orderTableWrapper").html(response);
                }
            });
        }
        $("select").change(fetchFilteredOrders);
    });
</script>
</body>
</html>