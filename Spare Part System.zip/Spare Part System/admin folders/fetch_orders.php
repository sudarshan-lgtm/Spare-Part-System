<?php
include '../db.php';

$customer = $_POST['customer'] ?? '';
$member = $_POST['member'] ?? '';
$kolhapurMember = $_POST['kolhapurMember'] ?? '';
$kolhapurCustomer = $_POST['kolhapurCustomer'] ?? '';

$query = "SELECT * FROM orders WHERE 1=0";

$params = [];
$types = "";

if ($customer) {
    $query .= " OR (account_type = 'customer' AND customer_fullname = ?)";
    $types .= "s";
    $params[] = $customer;
}
if ($member) {
    $query .= " OR (account_type = 'member' AND customer_fullname = ?)";
    $types .= "s";
    $params[] = $member;
}
if ($kolhapurMember) {
    $query .= " OR (account_type = 'kolhapur_member' AND customer_fullname = ?)";
    $types .= "s";
    $params[] = $kolhapurMember;
}
if ($kolhapurCustomer) {
    $query .= " OR (account_type = 'kolhapur_customer' AND customer_fullname = ?)";
    $types .= "s";
    $params[] = $kolhapurCustomer;
}

if (empty($params)) {
    $query = "SELECT * FROM orders ORDER BY created_at DESC";
    $result = $conn->query($query);
} else {
    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
}

include 'render_orders_table.php';
$conn->close();
?>
