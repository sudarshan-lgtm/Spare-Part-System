<?php
include '../db.php';

// Only run if form submitted
if (isset($_POST['delete_all'])) {
    try {
        // Disable foreign key checks
        $conn->query("SET FOREIGN_KEY_CHECKS = 0");

        // Truncate all tables
        $conn->query("TRUNCATE TABLE receivable_totals2");
        $conn->query("TRUNCATE TABLE receivable_entries2");
        $conn->query("TRUNCATE TABLE receivable_customers2");
        $conn->query("TRUNCATE TABLE receivable_report_info2");

        // Enable foreign key checks
        $conn->query("SET FOREIGN_KEY_CHECKS = 1");

        echo "<script>alert('All data deleted successfully.'); window.location.href='upload_folder_excel.php';</script>";
    } catch (Exception $e) {
        echo "<script>alert('Error deleting data: " . $e->getMessage() . "'); window.location.href='upload_folder_excel.php';</script>";
    }
}

$conn->close();
?>
