<?php
session_start();
include '../db.php';

// Prevent accessing this page after logout
if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}
//Request count of Login account 
$result = $conn->query("SELECT COUNT(*) AS total FROM requests WHERE status = 'pending'");
$row = $result->fetch_assoc();
$request_count = $row['total'];
$result->close();

// Prevent back button from accessing cached pages after logout
header("Cache-Control: no-cache, must-revalidate, no-store, max-age=0");
header("Pragma: no-cache");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");

$fullname = "Guest"; // Default value
if (isset($_SESSION['id'])) {
    $user_id = $_SESSION['id']; // Get logged-in user ID

    $query = "SELECT fullname FROM users WHERE id = ?";
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $fullname = htmlspecialchars($row['fullname'], ENT_QUOTES, 'UTF-8');
        }
        $result->close();
        $stmt->close();
    }
    else {
        // Handle prepare failure
        $conn->close();
    }
}

//Feedback 
$query = "SELECT fullname, message FROM contact ORDER BY id DESC";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <!-- Bootstrap CSS -->
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <link rel="stylesheet" href="../admin folders/css/admin_page.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title>Admin Dashboard</title>
</head>
<body>
    <?php include("preloader.html"); ?>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <a href="../admin folders/admin_dashboard.php"><img src="../image/RJ Logo.png" class="logo" alt="RJ"></a>
        <a href="../admin folders/cart.php" class="cart-icon" onclick="openCart()"><img src="../image/shopping-cart.png" class="cart" alt="tau"></a>
    </nav>
     
    <!-- Overlay -->  
    <div class="overlay" id="overlay" onclick="toggleSidebar()"></div>
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="toggle-btn-container">
        <span class="welcome"><marquee behavior="scroll" direction="left" scrollamount="5">Welcome - <?php echo $fullname; ?></marquee></span>
        <button class="toggle-btn" onclick="toggleSidebar()">☰</button></div>
        <ul class="sidebar-menu">
            <li style="margin-top: 20px;"><a href="admin_dashboard.php" style="text-decoration:none; color:#fff;">🏠 Home</a></li>
            <li><a href="sidebar/facility.html" style="text-decoration:none; color:#fff;"> 🏢 Facility</a></li>
            <li><a href="feedback.php" style="text-decoration:none; color:#fff;"> 📢 Feedback</a></li>
            <li><a href="sidebar/edit_account.php" style="text-decoration:none; color:#fff;">👤️ Edit Accounts</a></li>
            <li><a href="sidebar/gallary.php" style="text-decoration:none; color:#fff;">🖼️ Gallery</a></li>
            <li><a href="sidebar/slogan.php" style="text-decoration:none; color:#fff;">💡️ Insert Slogans</a></li>
            <li style="margin-top: auto;"><a href="admin_logout.php" style="text-decoration:none; color:#fff; padding:10px; background: linear-gradient(45deg, #6a11cb, #2575fc); border-radius: 10px; width: 20%;""><img style="height:auto; width: 15%;" src="../image/logo/logout2.png" alt="logout"> Logout</a></li>
        </ul>
    </div>
<div class="container-fluid">
    <div class="row">
        <!-- Main Content -->
        <div class="col-md-12">
            <div class="p-4">
                <!-- Header Section -->
                <div class="d-flex justify-content-between align-items-center mb-4" style="border-bottom: 2px solid #ccc;">
                    <div>
                        <h2>Good Morning, <?php echo $fullname; ?></h2>
                        <p>Your performance summary this year</p>
                    </div>
                    <div class="position-relative">
                        <button class="btn btn-outline-secondary me-2"><i class="fas fa-share-alt"></i> Share</button>
                        <div class="share-options" style="display: none; position: absolute; top: 100%; left: 0; margin-top: 10px; background: white; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); z-index: 100;">
                            <a href="https://api.whatsapp.com/send?text=Check out this awesome website: https://rjautoheaven.com/?i=1" target="_blank" class="btn btn-outline-secondary d-flex align-items-center"> <i class="fab fa-whatsapp me-2"></i> Share on WhatsApp</a>
                            <a href="https://t.me/share/url?url=https://rjautoheaven.com/?i=1" target="_blank" class="btn btn-outline-secondary d-flex align-items-center"><i class="fab fa-telegram-plane me-2"></i> Share on Telegram</a>
                            <a href="https://www.facebook.com/sharer/sharer.php?u=https://rjautoheaven.com/?i=1" target="_blank" class="btn btn-outline-secondary d-flex align-items-center"><i class="fab fa-facebook me-2"></i> Share on Facebook</a>
                            <a href="sms:?body=Check out this awesome website: https://rjautoheaven.com/?i=1" class="btn btn-outline-secondary d-flex align-items-center"> <i class="fas fa-sms me-2"></i> Share via SMS</a>
                        </div>
                        <a href="admin_requests.php"><button class="btn btn-outline-primary custom-btn" type="button"><i class="fas fa-paper-plane"></i>  Request 
                        <span id="request-count" class="position-absolute top-0 start-80 translate-middle badge rounded-pill bg-danger">0</span>
                        </button></a>
                        <!--<a href="../admin folders/user_login_logout.php"><button class="btn btn-primary" type="button">User Logs</button></a>-->
                        <a href="../admin folders/order.php"><button class="btn btn-warning me-2"><i class="fas fa-print"></i> Print</button></a>
                        <a href="../admin folders/upload_folder_excel.php"><button class="btn btn-success"><i class="fas fa-upload"></i> Import</button></a>
                        <button class="btn btn-secondary me-2" id="notification-btn"><i class="fas fa-bell"></i>
                            <span id="notification-count" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">0</span></button>
                    </div>
                </div>
                <!-- Metrics Section -->
                <div class="row px-5">
                    <!-- Total Products -->
                    <div class="col-md-2">
                        <div class="matrics bg-light p-3 text-center position-relative">
                            <div class="position-absolute top-0 w-100 border-top" style="border-color: #ccc;"></div>
                            <h5>Total Products</h5>
                            <p id="totalProducts" class="text-danger mb-0">Loading...</p>
                        </div>
                    </div>
                    <!-- Today's sales -->
                    <div class="col-md-2">
                        <div class="matrics bg-light p-3 text-center position-relative">
                            <div class="position-absolute top-0 w-100 border-top" style="border-color: #ccc;"></div>
                            <h5>Today's Sales</h5>
                            <p id="todaysSales" class="text-success mb-0">Loading...</p>
                        </div>
                    </div>
                    <!-- Today's Money 
                    <div class="col-md-2">
                        <div class="matrics bg-light p-3 text-center position-relative">
                            <div class="position-absolute top-0 w-100 border-top" style="border-color: #ccc;"></div>
                            <h5>Today's Money</h5>
                            <p id="todaysMoney" class="text-success mb-0">Loading...</p>
                        </div>
                    </div>-->
                    <!-- Total sales -->
                    <div class="col-md-2">
                        <div class="matrics bg-light p-3 text-center position-relative">
                            <div class="position-absolute top-0 w-100 border-top" style="border-color: #ccc;"></div>
                            <h5>Total Sales</h5>
                            <p id="totalSales" class="text-danger mb-0">Loading...</p>
                        </div>
                    </div>
                    <!-- Total Money -->
                    <div class="col-md-2">
                        <div class="matrics bg-light p-3 text-center position-relative">
                            <div class="position-absolute top-0 w-100 border-top" style="border-color: #ccc;"></div>
                            <h5>Total Money</h5>
                            <p id="totalMoney" class="text-success mb-0">Loading...</p>
                        </div>
                    </div>
                    <!-- Current Date and Time -->
                    <div class="col-md-4">
                        <div class="matrics bg-light p-3 text-center position-relative date-time-container">
                            <div class="position-absolute top-0 w-100 border-top" style="border-color: #ccc;"></div>
                            <h5><img src="../image/logo/time.png" alt="Time">Current Date & Time</h5>
                            <p id="currentDateTime">Loading...</p>
                            <button id="toggleTimeFormat" class="btn btn-outline-primary">Switch to 12-Hour</button>
                        </div>
                    </div>
                </div>
                <!-- Scrolling Marquee Message with HelpLine Design -->
                <div class="container-fluid mt-3">
                    <div class="d-flex align-items-center" style="background: linear-gradient(to right, white, darkred); border-radius: 10px; padding: 5px 15px; color: white;">
                        <div style="background: red; padding: 5px 15px; border-radius: 10px; font-weight: bold;">Updates</div>
                        <marquee behavior="scroll" direction="left" style="font-size: 16px; color: white; font-weight: bold;">
                            🔔 Important Update: Your website analytics have been updated! Check the latest performance metrics now.
                        </marquee>
                    </div>
                </div>
                
                <div class="row mt-4">
                    <div class="col-lg-8 col-md-7 mb-3">
                        <h4>Order Performance</h4>
                        <div class="chart-container">
                            <canvas id="orderChart"></canvas>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-5">
                        <div class="scroll-container">
                            <h4>📢 Feedback</h4>
                            <div class="scroll-content-wrapper">
                                <div class="scroll-content">
                                    <?php while($row = $result->fetch_assoc()): ?>
                                        <div class="message">
                                            <strong><?= htmlspecialchars($row['fullname']) ?>:</strong>
                                            <?= htmlspecialchars($row['message']) ?>
                                        </div>
                                    <?php endwhile; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>  
    <div class="header">
        <div class="card-container">
        <a href="display_receivable.php">
                <div class="card">
                    <img src="../image/logo/inbox.png" loading="lazy" alt="Order Icon">
                    <h5>Receivable Data</h5>
                </div>
            </a>
            <a href="import_csv_statement.php">
                <div class="card">
                    <img src="../image/logo/ledger.png" loading="lazy" alt="Order Icon">
                    <h5>Ledger Data</h5>
                </div>
            </a>
            <a href="order.php">
                <div class="card">
                    <img src="../image/logo/order.png" loading="lazy" alt="Order Icon">
                    <h5>Customer Orders</h5>
                </div>
            </a>
            <a href="display_product_group.php">
                <div class="card">
                    <img src="../image/logo/product-management.png" loading="lazy" alt="Category Icon">
                    <h5>Product Groups</h5>
                </div>
            </a>
            <a href="upload_folder_excel.php">
                <div class="card">
                    <img src="../image/logo/upload.png" loading="lazy" alt="Loyalty Icon">
                    <h5>Upload Data</h5>
                </div>
            </a>
            <a href="../admin folders/company/company.php">
                <div class="card">
                    <img src="../image/logo/companies.png" loading="lazy" alt="Loyalty Icon">
                    <h5>Companies</h5>
                </div>
            </a>
            <a href="../admin folders/cust_mem_hide.php">
                <div class="card">
                    <img src="../image/logo/folder.png" loading="lazy" alt="Loyalty Icon">
                    <h5>Hide/Unhide</h5>
                </div>
            </a>
            <a href="download.php">
                <div class="card">
                    <img src="../image/logo/download-data.png" loading="lazy" alt="Download Icon">
                    <h5>Download</h5>
                </div>
            </a>
            <a href="add_offers.php">
                <div class="card">
                    <img src="../image/logo/new-product.png" loading="lazy" alt="New Product Icon">
                    <h5>Add Offers</h5>
                </div>
            </a>
            <a href="account.php">
                <div class="card">
                    <img src="../image/logo/user.png" loading="lazy" alt="Account Icon">
                    <h5>Payment</h5>
                </div>
            </a>
            <a href="orders_submit.php">
            <div class="card">
                <img src="../image/logo/medal.png" loading="lazy" alt="Loyalty Icon">
                <h5>Submited Orders</h5>
            </div>
            </a>
            <a href="contact.php">
                <div class="card">
                    <img src="../image/logo/contact-us.png" loading="lazy" alt="Loyalty Icon">
                    <h5>Contact Us</h5>
                </div>
            </a>
        </div>
    </div>
    <footer class="py-5 mb-0">
        <div class="footer-container">
            <div class="about-us">
                <h4>About Us</h4>
                <p>Your one-stop destination for high-quality spare parts. Find the right part for your vehicle effortlessly with our advanced search and categorized product groups. Order with confidence and get the best deals on premium auto parts.</p>
            </div>
            <div class="order-spares">
                <h4>Order Spare Parts</h4>
                <p>Looking for genuine spare parts? Use our **Search Part Number** feature or browse through **Product Groups** to find the perfect match for your vehicle. We ensure top-quality, fast delivery, and competitive pricing.</p>
            </div>
            <div class="contact-us">
                <h4>Contact Us</h4>
                <P>Email: rjautoheaven@gmail.com</P>
                <p>Phone: 9834530051</p>
                <p>Address: Gat No. 288/2, Plot No.2, A/P-kondi, TQ, North Solapur, Dist: Solapur </p>
            </div>
            <div class="follow-us">
                <h4>Follow Us</h4>
                <div class="social-icons">
                    <a href="https://www.facebook.com/"><img src="../image/logo/facebook.png" alt="Facebook"></a>
                    <a href="https://www.instagram.com/"><img src="../image/logo/instagram.png" alt="Instagram"></a>
                    <a href="https://www.linkedin.com/"><img src="../image/logo/linkedin.png" alt="LinkedIn"></a>
                    <a href="https://www.twitter.com/"><img src="../image/logo/twitter.png" alt="Twitter"></a>
                </div>
            </div>
        </div>
        <div class="container mt-3">
            <h4 class="mb-4 text-center text-danger">RJ AUTOHEAVEN Policies</h4>
            <div class="d-flex flex-column flex-md-row justify-content-around align-items-center gap-3">
                <a href="../Privacy_Policy.html" class="btn btn-outline-primary w-100 w-md-auto">Privacy Policy</a>
                <a href="../terms_conditions.html" class="btn btn-outline-success w-100 w-md-auto">Terms & Conditions</a>
                <a href="../return_refund_policy.html" class="btn btn-outline-danger w-100 w-md-auto">Return & Refund Policy</a>
            </div>
        </div>
        <div class="footer-bottom">
            <small>Developed by <a href="admin_dashboard.php" class="text-info"><img src="../image/sud2.png" class="sudarshan"></a> | © 2025 RJ AUTOHEAVEN. All Rights Reserved.</small>
        </div>  
    </footer>
    <script src="../admin folders/js/admin_dashboard.js"></script>
    <script src="../admin folders/js/shortcut_key.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    //Graph count of totalProducts, todaysSales, totalSales, totalMoney etc.
    $(document).ready(function(){
        function fetchDashboardData() {
            $.ajax({
                url: 'metrics_graph.php',
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response) {
                        $("#totalProducts").text(response.totalProducts);
                        $("#todaysSales").text(response.todaysSales);
                        $("#todaysMoney").text(response.todaysMoney);
                        $("#totalSales").text(response.totalSales);
                        $("#totalMoney").text("₹" + response.totalMoney);
                    } else {
                        console.error("Invalid response from server.");
                    }
                },
                error: function(xhr, status, error) {
                    console.error("AJAX Error: ", status, error);
                }
            });
        }

        fetchDashboardData(); // Fetch on page load
        setInterval(fetchDashboardData, 5000); // Refresh every 5 seconds
    });

    // Login Success Voice JS 
    window.onload = function() {
        if (localStorage.getItem('login_success') === 'true') {
            localStorage.removeItem('login_success');

            let msg = new SpeechSynthesisUtterance("Login successful");
            msg.lang = "en-US"; // English Language
            msg.rate = 1; // Normal speed
            msg.pitch = 1.2; // Higher pitch for female voice
            msg.volume = 1; // Full volume
            
            let voices = window.speechSynthesis.getVoices();
            msg.voice = voices.find(voice => voice.name.includes("Female")) || voices[0]; 

            window.speechSynthesis.speak(msg);
        }
    };
    //Request Count JS
    document.getElementById('request-count').innerText = "<?= $request_count ?>";
</script>
<script>
    // Cart alert JS
    function openCart() {
        alert("Cart functionality will be implemented here!");
    }
    
    //Side bar JS
    function toggleSidebar() {
        const sidebar = document.getElementById("sidebar");
        const overlay = document.getElementById("overlay");
    
        // Toggle the 'open' class on the sidebar
        sidebar.classList.toggle("open");
    
        // Show or hide the overlay based on sidebar state
        if (sidebar.classList.contains("open")) {
            overlay.classList.add("active");
        } else {
            overlay.classList.remove("active");
        }
    }
    
    //Graph Backend JS
    document.addEventListener("DOMContentLoaded", () => {
        // Fetch order data from the backend
        fetch('graph_fetch_order.php') // Replace with your PHP file's path
            .then(response => response.json())
            .then(data => {
                const ctx = document.getElementById('orderChart').getContext('2d');
                new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: ['Last Week', 'Today', 'This Week', 'This Month', 'This Six Month', 'This Year', 'Last Year'],
                        datasets: [{
                            label: 'Number of Orders',
                            data: [
                                data.lastWeekOrders,
                                data.todayOrders,
                                data.thisWeekOrders,
                                data.thisMonthOrders,
                                data.thisSixMonthOrders,
                                data.thisYear,
                                data.lastYear
                            ],
                            backgroundColor: [
                                'rgba(75, 192, 192, 0.2)', // Today
                                'rgba(153, 102, 255, 0.2)', // This Week
                                'rgba(255, 159, 64, 0.2)', // Last Week
                                'rgba(54, 162, 235, 0.2)',  // This Month
                                'rgba(201, 203, 207, 0.2)', // Last 6 Months
                                'rgba(255, 205, 86, 0.2)', // This Year
                                'rgba(255, 99, 132, 0.2)'  // Last Year
                            ],
                            borderColor: [
                                'rgba(75, 192, 192, 1)', // Today
                                'rgba(153, 102, 255, 1)', // This Week
                                'rgba(255, 159, 64, 1)', // Last Week
                                'rgba(54, 162, 235, 1)',  // This Month
                                'rgba(201, 203, 207, 1)', // Last 6 Months
                                'rgba(255, 205, 86, 1)', // This Year
                                'rgba(255, 99, 132, 1)'  // Last Year
                            ],
                            borderWidth: 2
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                display: true,
                                position: 'top',
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });
            })
            .catch(error => console.error('Error fetching data:', error));
    });
    
    //Share option JS
    document.querySelector('.btn-outline-secondary').addEventListener('click', function() {
        document.querySelector('.share-options').style.display = 'block';
    });
    
    
    //Notification Button JS
    document.getElementById("notification-btn").addEventListener("click", function() {
    window.location.href = "../admin folders/notification.php";
    });
    
    function updateNotificationCount() {
        $.ajax({
            url: '../admin folders/notification_count.php',
            method: 'GET',
            success: function(count) {
                if (count > 0) {
                    $("#notification-count").text(count).show();
                } else {
                    $("#notification-count").hide();
                }
            }
        });
    }
    setInterval(updateNotificationCount, 2000);
    updateNotificationCount();
    
    //Show Current Time and Date
    document.addEventListener("DOMContentLoaded", function () {
        let is24HourFormat = true;
    
        function updateDateTime() {
            const now = new Date();
    
            // Set options to show Indian date/time
            const dateOptions = {
                timeZone: "Asia/Kolkata", // India time zone
                year: 'numeric',
                month: 'long',
                day: 'numeric',
            };
            const timeOptions24 = {
                timeZone: "Asia/Kolkata",
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: false
            };
            const timeOptions12 = {
                timeZone: "Asia/Kolkata",
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: true
            };
    
            const date = new Intl.DateTimeFormat('en-IN', dateOptions).format(now);
            const time = new Intl.DateTimeFormat('en-IN', is24HourFormat ? timeOptions24 : timeOptions12).format(now);
    
            document.getElementById('currentDateTime').innerHTML = `${date}, ${time}`;
        }
    
        updateDateTime();
        setInterval(updateDateTime, 1000);
    
        document.getElementById('toggleTimeFormat').addEventListener('click', function () {
            is24HourFormat = !is24HourFormat;
            const formatText = is24HourFormat ? "Switch to 12-Hour" : "Switch to 24-Hour";
            this.textContent = formatText;
            updateDateTime();
        });
    });
</script>

<script>
// Set cookie if not exists
function setCookie(name, value, days) {
    const d = new Date();
    d.setTime(d.getTime() + (days*24*60*60*1000));
    document.cookie = name + "=" + value + ";expires=" + d.toUTCString() + ";path=/";
}

// Get cookie
function getCookie(name) {
    const cname = name + "=";
    const decodedCookie = decodeURIComponent(document.cookie);
    const ca = decodedCookie.split(';');
    for (let c of ca) {
        while (c.charAt(0) === ' ') c = c.substring(1);
        if (c.indexOf(cname) === 0) return c.substring(cname.length, c.length);
    }
    return "";
}

// Defer heavy images if not first visit
window.addEventListener('DOMContentLoaded', function () {
    const visited = getCookie("visitedOnce");

    if (!visited) {
        console.log("First time visit — setting cookie.");
        setCookie("visitedOnce", "yes", 7);
    } else {
        console.log("Returning visitor — delaying extra image loading.");
        const heavyImages = document.querySelectorAll("img[data-src]");
        heavyImages.forEach(img => {
            img.setAttribute("src", img.getAttribute("data-src"));
            img.removeAttribute("data-src");
        });
    }
});
</script>

</body>
</html>