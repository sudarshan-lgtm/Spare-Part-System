<?php
// fetch_customers.php
require '../vendor/autoload.php';
$pdo = new PDO("mysql:host=127.0.0.1:3306;dbname=u494849712_part", "u494849712_patilnagesh007", "Password@1381");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$search = $_GET['search'] ?? '';

$stmt = $pdo->prepare("SELECT DISTINCT customer_name FROM receivable_customers WHERE customer_name LIKE ?");
$stmt->execute(["%$search%"]);
$customers = $stmt->fetchAll(PDO::FETCH_ASSOC);
$stmt->closeCursor();

echo json_encode($customers);
?>
