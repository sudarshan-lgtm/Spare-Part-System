<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}

try {
    $pdo = new PDO("mysql:host=127.0.0.1:3306;dbname=u494849712_part", "u494849712_patilnagesh007", "Password@1381");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

$stmt = $pdo->query("SELECT * FROM statement_user_name2 ORDER BY statement_id DESC");
$customers = $stmt->fetchAll(PDO::FETCH_ASSOC);
$stmt->closeCursor();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Imported Account Statements</title>
    <link rel="icon" href="../image/icon.png" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
    <h2 class="text-center mb-4">All Imported Account Statements</h2>

    <!-- Search Input -->
    <div class="mb-3">
        <input type="text" id="searchInput" class="form-control" placeholder="Search by customer name..." onkeyup="filterCustomers()">
    </div>

    <?php if (empty($customers)): ?>
        <div class="alert alert-warning">No data available.</div>
    <?php else: ?>
        <?php foreach ($customers as $customer): ?>
            <div class="card mb-4 customer-section" data-customer-name="<?= strtolower(htmlspecialchars($customer['user_name'])) ?>">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><?= htmlspecialchars($customer['user_name']) ?> (<?= $customer['from_date'] ?> to <?= $customer['to_date'] ?>)</h5>
                </div>
                <div class="card-body p-3">
                    <?php
                    $sid = $customer['statement_id'];

                    // Opening Balance
                    $stmt = $pdo->prepare("SELECT * FROM opening_balance2 WHERE statement_id = :sid");
                    $stmt->execute(['sid' => $sid]);
                    $opening_balance = $stmt->fetch(PDO::FETCH_ASSOC);
                    $stmt->closeCursor();

                    // Transactions
                    $stmt = $pdo->prepare("SELECT * FROM statement_all_data2 WHERE statement_id = :sid ORDER BY date");
                    $stmt->execute(['sid' => $sid]);
                    $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    $stmt->closeCursor();

                    // Totals
                    $stmt = $pdo->prepare("SELECT * FROM statement_total_amt2 WHERE statement_id = :sid");
                    $stmt->execute(['sid' => $sid]);
                    $total_amt = $stmt->fetch(PDO::FETCH_ASSOC);
                    $stmt->closeCursor();

                    // Closing Balance
                    $stmt = $pdo->prepare("SELECT * FROM closing_balance2 WHERE statement_id = :sid");
                    $stmt->execute(['sid' => $sid]);
                    $closing_balance = $stmt->fetch(PDO::FETCH_ASSOC);
                    $stmt->closeCursor();
                    ?>

                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead class="table-secondary">
                                <tr>
                                    <th>Date</th>
                                    <th>Doc/Chq. No.</th>
                                    <th>Type</th>
                                    <th>Particulars</th>
                                    <th>Credit</th>
                                    <th>Debit</th>
                                    <th>Closing Balance</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Opening Balance -->
                                <tr class="table-info">
                                    <td colspan="3"></td>
                                    <td><strong>Opening Balance</strong></td>
                                    <td><?= number_format($opening_balance['credit_amt'] ?? 0, 2) ?></td>
                                    <td><?= number_format($opening_balance['debit_amt'] ?? 0, 2) ?></td>
                                    <td><?= htmlspecialchars($opening_balance['closer_balance'] ?? 'N/A') ?></td>
                                </tr>

                                <!-- Transactions -->
                                <?php foreach ($transactions as $txn): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($txn['date']) ?></td>
                                        <td><?= htmlspecialchars($txn['doc_no']) ?></td>
                                        <td><?= htmlspecialchars($txn['type']) ?></td>
                                        <td><?= htmlspecialchars($txn['particulars']) ?></td>
                                        <td><?= $txn['credit'] !== null ? number_format($txn['credit'], 2) : '' ?></td>
                                        <td><?= $txn['debit'] !== null ? number_format($txn['debit'], 2) : '' ?></td>
                                        <td><?= htmlspecialchars($txn['closing_balance']) ?></td>
                                    </tr>
                                <?php endforeach; ?>

                                <!-- Totals -->
                                <tr class="table-warning">
                                    <td colspan="3"></td>
                                    <td><strong>Total</strong></td>
                                    <td><?= number_format($total_amt['credit_amt'] ?? 0, 2) ?></td>
                                    <td><?= number_format($total_amt['debit_amt'] ?? 0, 2) ?></td>
                                    <td></td>
                                </tr>

                                <!-- Closing Balance -->
                                <tr class="table-success">
                                    <td colspan="6"><strong>Closing Balance</strong></td>
                                    <td><?= htmlspecialchars($closing_balance['closing_balance'] ?? 'N/A') ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<script>
    function filterCustomers() {
        const searchValue = document.getElementById('searchInput').value.toLowerCase();
        const sections = document.querySelectorAll('.customer-section');

        sections.forEach(section => {
            const customer = section.getAttribute('data-customer-name');
            section.style.display = customer.includes(searchValue) ? '' : 'none';
        });
    }
</script>
</body>
</html>
