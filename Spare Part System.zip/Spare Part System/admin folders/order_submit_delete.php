<?php
include '../db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['orderIds'])) {
    $orderIds = $_POST['orderIds'];

    if (!empty($orderIds) && is_array($orderIds)) {
        $idsString = implode(",", array_map('intval', $orderIds)); // Sanitize input

        // Start transaction
        $conn->begin_transaction();

        try {
            // Delete only the selected orders
            $deleteQuery = "DELETE FROM submitted_orders WHERE id IN ($idsString)";
            $conn->query($deleteQuery);

            $conn->commit();
            echo json_encode(["success" => true]);
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(["success" => false, "error" => $e->getMessage()]);
        }
    } else {
        echo json_encode(["success" => false, "error" => "Invalid selection"]);
    }
}
?>
