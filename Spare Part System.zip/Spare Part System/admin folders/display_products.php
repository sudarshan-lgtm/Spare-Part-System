<?php
session_start();
include '../db.php';

if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}
// Initialize cart count
$cart_count = 0;

// Fetch cart count from database
$result = $conn->query("SELECT COUNT(*) as count FROM cart");
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $cart_count = $row['count'];
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <title>Products</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            line-height: 1.6;
            background-color: #fff;
        }
        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 40px !important;
            background-color: #fff;
            border-radius: 2px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.6);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 20px;
            z-index: 1000;
            backdrop-filter: blur(9px);
        }
        .navbar .logo {
            height: 45px;
            object-fit: contain;
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            filter: drop-shadow(2px 2px 5px rgba(0,0,0,0.4));
        }
        .navbar .cart-icon {
            font-size: 24px;
            color: #333;
            text-decoration: none;
            cursor: pointer;
            transition: transform 0.3s ease, color 0.3s ease;
            position: absolute;
            right: 60px;
        }
        .navbar .cart-icon:hover {
            color: #f90;
            transform: scale(1.2);
        }
        .cart {
            width: 40px;
            height: 40px;
            object-fit: contain;
            transition: transform 0.1s ease, box-shadow 0.3s ease;
            margin-left: 10px;
            transform: perspective(200px) rotateY(5deg);
        }
        .cart:hover {
            transform: perspective(200px) rotateY(0deg) scale(1.05);
        }
        .calculator {
            height: 35px;
            object-fit: contain;
            position: absolute;
            left: 85%;
            top: 20%;
        }
        .popup {
            display: none;
            position: fixed;
            left: 50%;
            top: 60%;
            transform: translate(-50%, -50%);
            width: 320px;
            padding: 20px;
            background: rgba(0, 0, 0, 0.736);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
            text-align: center;
            animation: fadeIn 0.3s ease-in-out;
            z-index: 1001;
        }
        .display {
            width: 100%;
            height: 60px;
            font-size: 2em;
            text-align: right;
            border: none;
            outline: none;
            background: rgba(255, 255, 255, 0.2);
            color: #fff;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 10px;
        }
        .buttons {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
        }
        .buttons button {
            width: 100%;
            height: 60px;
            font-size: 1.5em;
            border: none;
            outline: none;
            border-radius: 8px;
            background: rgba(255, 255, 255, 0.3);
            color: #fff;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
            cursor: pointer;
            transition: all 0.2s ease-in-out;
        }
        .buttons button:hover {
            background: rgba(255, 255, 255, 0.5);
            transform: scale(1.05);
        }
        .equal {
            grid-column: span 2;
            background: #34d399;
        }
        .equal:hover {
            background: #2ab77d;
        }
        .clear {
            background: #ef4444;
        }
        .clear:hover {
            background: #d32f2f;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translate(-50%, -45%); }
            to { opacity: 1; transform: translate(-50%, -50%); }
        }
        /* Image Popup Styles */
        .image-popup {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.85);
            z-index: 1002;
            justify-content: center;
            align-items: center;
            animation: fadeInPopup 0.3s ease-in-out;
        }
        .image-popup-content {
            position: relative;
            max-width: 90%;
            max-height: 90%;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.5);
            overflow: hidden;
            animation: zoomIn 0.3s ease-in-out;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding-bottom: 20px;
        }
        .image-popup-content img {
            width: 100%;
            height: auto;
            max-height: 70vh;
            object-fit: contain;
        }
        .image-popup-content .product-name {
            margin-top: 10px;
            font-size: 18px;
            font-weight: bold;
            color: #333;
            text-align: center;
        }
        .close-popup {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 30px;
            color: #fff;
            background: rgba(0, 0, 0, 0.7);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            transition: background 0.3s;
        }
        .close-popup:hover {
            background: rgba(255, 0, 0, 0.7);
        }
        .nav-arrow {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            font-size: 40px;
            color: #fff;
            background: rgba(0, 0, 0, 0.5);
            padding: 10px;
            cursor: pointer;
            user-select: none;
            transition: background 0.3s;
        }
        .nav-arrow:hover {
            background: rgba(0, 0, 0, 0.8);
        }
        .prev-arrow {
            left: 10px;
        }
        .next-arrow {
            right: 10px;
        }
        @keyframes fadeInPopup {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes zoomIn {
            from { transform: scale(0.8); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }
        .cart-number {
            position: absolute;
            top: -6px;
            right: -17px;
            color: red;
            font-size: 20px;
            font-weight: bold;
            font-family: Arial, sans-serif;
            transition: all 0.3s ease-in-out;
        }
        .cart-badge.updated {
            animation: pop 0.3s ease-in-out;
        }
        @keyframes pop {
            0% { transform: scale(1); }
            50% { transform: scale(1.3); }
            100% { transform: scale(1); }
        }
        .search-container {
            margin-top: -40px;
            background-color: #E9EAEC;
            box-shadow: none;
            width: 103%;
            margin-left: -2.5% !important;
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 999;
        }
        .searchInput {
            padding: 10px;
            font-size: 14px;
            width: 250px;
            border: 1px solid #ccc;
            border-radius: 5px;
            outline: none;
        }
        .searchButton {
            padding: 10px 15px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-left: 10px;
            transition: background-color 0.3s;
        }
        .searchButton:hover {
            background-color: #0056b3;
        }
        .file-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
            padding: 10px;
            margin-top: 20px;
            max-width: 1400px;
            margin-left: auto;
            margin-right: auto;
        }
        .card {
            border: 1px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            padding: 15px;
            width: 100%;
            max-width: 300px;
            text-align: center;
            background-color: #fff;
            box-sizing: border-box;
        }
        .card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 5px;
            margin-bottom: 10px;
            cursor: pointer;
            transition: transform 0.3s;
        }
        .card img:hover {
            transform: scale(1.05);
        }
        h4 {
            margin-top: 0;
            font-size: 14px;
            margin-top: 5px;
            margin-bottom: 3px;
        }
        .card p {
            font-size: 14px;
            margin: 5px 0;
            text-align: left;
        }
        .feedbackText {
            width: 100%;
            height: 50px;
            font-size: 14px;
            margin-top: 5px;
            margin-bottom: 7px;
        }
        .quantity-btn {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            border-radius: 4px;
            font-size: 18px;
        }
        .minus {
            background-color: #03A9F4;
        }
        .minus:hover {
            background-color: #0288D1;
        }
        .plus {
            background-color: #4CAF50;
        }
        .plus:hover {
            background-color: #388E3C;
        }
        .add-to-cart-btn {
            background-color: #FF9800;
            color: white;
            border: none;
            padding: 8px 15px;
            cursor: pointer;
            border-radius: 4px;
            font-size: 16px;
            margin-top: 10px;
            width: 100%;
        }
        .add-to-cart-btn:hover {
            background-color: #FB8C00;
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            color: white;
            border-radius: 50%;
            text-decoration: none;
            font-size: 22px;
            transition: all 0.3s ease;
            position: fixed;
            top: 10px;
            left: 20px;
            z-index: 999;
        }
        .back-button:hover {
            transform: scale(1.1);
            color: #fff;
        }
        .back-button .home {
            height: 55px;
            width: auto;
            margin-right: 10px;
            vertical-align: middle;
            object-fit: contain;
        }
        @media (max-width: 1400px) {
            .file-container {
                gap: 15px;
            }
        }
        @media (max-width: 768px) {
            .file-container {
                gap: 10px;
            }
            .card {
                max-width: 250px;
            }
        }
        @media (max-width: 600px) {
            .file-container {
                flex-direction: column;
                align-items: center;
            }
            .card {
                max-width: 100%;
                padding: 12px;
            }
            .card img {
                height: 150px;
                object-fit: contain;
            }
            .add-to-cart-btn {
                font-size: 14px;
            }
        }
        @media (max-width: 480px) {
            .navbar .logo {
                height: 35px;
            }
            .calculator {
                margin-left: -67% !important;
            }
            .search-container {
                width: 111% !important;
                margin-left: -9% !important;
            }
            .card {
                max-width: 100%;
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <?php include("preloader.html"); ?>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <a href='admin_dashboard.php' class='back-button'><img src="../image/h1.png" class="home" alt="ok"></a>
        <img src="../image/RJ Logo.png" class="logo" alt="RJ">
        <a href="#" onclick="toggleCalculator()">
            <img src="../image/logo/calculator.png" alt="calculator" class="calculator">
        </a>
        <a href="../admin folders/cart.php" class="cart-icon"> 
            <img src="../image/shopping-cart.png" class="cart" alt="cart">
            <span id="cart-count" class="cart-number"><?php echo $cart_count; ?></span>
        </a>
    </nav>
    <!-- Search Bar -->
    <div class="search-container">
        <input type="text" id="searchInput" class="searchInput" placeholder="Search the data" style="float:right; margin-top: 80px; margin-right: 10px; padding: 8px;">
        <button id="searchButton" class="searchButton" style="padding: 10px; margin-top: 80px; float:right;">Search</button>
    </div>
    <!-- Calculator Modal -->
    <div id="calculatorPopup" class="popup">
        <div class="popup-content">
            <span class="close-btn"></span>
            <input type="text" id="display" class="display" readonly>
            <div class="buttons">
                <button onclick="clearDisplay()" class="clear">C</button>
                <button onclick="backspace()">⌫</button>
                <button onclick="appendToDisplay('%')">%</button>
                <button onclick="appendToDisplay('/')">÷</button>
                <button onclick="appendToDisplay('7')">7</button>
                <button onclick="appendToDisplay('8')">8</button>
                <button onclick="appendToDisplay('9')">9</button>
                <button onclick="appendToDisplay('*')">×</button>
                <button onclick="appendToDisplay('4')">4</button>
                <button onclick="appendToDisplay('5')">5</button>
                <button onclick="appendToDisplay('6')">6</button>
                <button onclick="appendToDisplay('-')">−</button>
                <button onclick="appendToDisplay('1')">1</button>
                <button onclick="appendToDisplay('2')">2</button>
                <button onclick="appendToDisplay('3')">3</button>
                <button onclick="appendToDisplay('+')">+</button>
                <button onclick="appendToDisplay('0')">0</button>
                <button onclick="appendToDisplay('.')">.</button>
                <button onclick="calculateResult()" class="equal">=</button>
            </div>
        </div>
    </div>
    <!-- Image Popup -->
    <div id="imagePopup" class="image-popup">
        <div class="image-popup-content">
            <span class="close-popup" onclick="closeImagePopup()">×</span>
            <img id="popupImage" src="" alt="Full Image">
            <div id="popupProductName" class="product-name"></div>
            <span class="nav-arrow prev-arrow" onclick="navigateImage(-1)">❮</span>
            <span class="nav-arrow next-arrow" onclick="navigateImage(1)">❯</span>
        </div>
    </div>
    <?php
    include '../db.php'; // Include database connection

    // Fetch product group from GET parameter
    $groupName = isset($_GET['group']) ? trim($_GET['group']) : '';
    $fullname = isset($_GET['name']) ? htmlspecialchars($_GET['name']) : '';
    $account_type = isset($_GET['account_type']) ? htmlspecialchars($_GET['account_type']) : "";
    $productName = isset($_GET['product']) ? trim($_GET['product']) : '';
    $singleProductResults = [];

    if (!empty($productName)) {
        // Search in both tables
        $searchSql = "
        SELECT id, ProductGroup, Product, Batch, Company, PartNo, PurchaseRate, GST, Exp, Margin, PurchaseCode, SaleRate, ReceiptQty, IssueQty, ClosingQty, Location, imagePath, 'productinventory' as source 
        FROM productinventory WHERE Product = ?
        UNION
        SELECT id, ProductGroup, Product, Batch, Company, PartNo, PurchaseRate, GST, Exp, Margin, PurchaseCode, SaleRate, ReceiptQty, IssueQty, ClosingQty, Location, imagePath, 'kolhapurdata' as source 
        FROM kolhapurdata WHERE Product = ?
        LIMIT 1
    ";
        $stmt = $conn->prepare($searchSql);
        $stmt->bind_param("ss", $productName, $productName);
        $stmt->execute();
        $res = $stmt->get_result();

        while ($row = $res->fetch_assoc()) {
            $singleProductResults[] = $row;
        }
        
        // ✅ Free result set memory
    if ($res) {
        $res->free();
    }


        $stmt->close();
    }

    // Function to fetch products from a table
    function fetchProducts($conn, $tableName, $groupName) {
        $query = "SELECT * FROM $tableName WHERE ProductGroup = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $groupName);
        $stmt->execute();
        $result = $stmt->get_result();
        $products = [];

        while ($row = $result->fetch_assoc()) {
            $products[] = $row;
        }
        $stmt->close();
        return $products;
    }

    // Fetch products separately from both tables
    $productInventoryProducts = fetchProducts($conn, 'productinventory', $groupName);
    $kolhapurdataProducts = fetchProducts($conn, 'kolhapurdata', $groupName);

    echo "<h2 style='margin-top: 40px; text-align: center;'>Search Results for Product Group: $groupName</h2>";

    if (!empty($singleProductResults)) {
        echo "<h2 style='text-align: center;'>Search Result for Product: $productName</h2>";
        displayProducts($singleProductResults, 'Searched Product Result', $fullname, $account_type);
    }

    function displayProducts($products, $sectionTitle, $fullname, $account_type) {
        echo "<div style='width: 100%; text-align: center; margin-top: 5px;'>
            <h2 class='sectionTitle' style='background-color:rgba(3, 163, 255, 0.78); color: white; padding: 7px 0; border-radius: none; width: 50%; margin: 0 auto;'>
                $sectionTitle
            </h2>
        </div>";
        echo "<div class='file-container'>";

        if (!empty($products)) {
            foreach ($products as $index => $product) {
                echo "<div class='card'>
                    <img src='{$product['imagePath']}' alt='{$product['Product']}' style='width: 100%; height: auto;' loading='lazy' onclick='openImagePopup($index)' data-index='$index'>
                    <h4>{$product['Product']}</h4>
                    <p><strong>Batch:</strong> {$product['Batch']}</p>
                    <p><strong>Company:</strong> {$product['Company']}</p>
                    <p><strong>Part No:</strong> {$product['PartNo']}</p>
                    <p><strong>Purchase Rate:</strong> ₹{$product['PurchaseRate']}</p>
                    <p><strong>GST:</strong> {$product['GST']}%</p>
                    <p><strong>Exp:</strong> {$product['Exp']}</p>
                    <p><strong>Margin:</strong> {$product['Margin']}%</p>
                    <p><strong>Sale Rate:</strong> ₹{$product['SaleRate']}</p>
                    <p><strong>Closing Qty:</strong> {$product['ClosingQty']}</p>
                    <p><strong>Location:</strong> {$product['Location']}</p>
                    <textarea name='feedback' class='feedbackText' placeholder='Enter Feedback Here' rows='4'></textarea>
                    <form id='addToCartForm-{$product['PartNo']}' onsubmit='addToCart(event, this)'>
                        <input type='hidden' name='fullname' value='$fullname'>
                        <input type='hidden' name='account_type' value='$account_type'>
                        <input type='hidden' name='Product' value='{$product['Product']}'>
                        <input type='hidden' name='Batch' value='{$product['Batch']}'>
                        <input type='hidden' name='Company' value='{$product['Company']}'>
                        <input type='hidden' name='PartNo' value='{$product['PartNo']}'>
                        <input type='hidden' name='PurchaseRate' value='{$product['PurchaseRate']}'>
                        <input type='hidden' name='GST' value='{$product['GST']}'>
                        <input type='hidden' name='Exp' value='{$product['Exp']}'>
                        <input type='hidden' name='Margin' value='{$product['Margin']}'>
                        <input type='hidden' name='SaleRate' value='{$product['SaleRate']}'>
                        <input type='hidden' name='ClosingQty' value='{$product['ClosingQty']}'>
                        <input type='hidden' name='Location' value='{$product['Location']}'>
                        <input type='hidden' name='imagePath' value='{$product['imagePath']}'>
                        <div style='display: flex; justify-content: center; align-items: center; gap: 10px;'>
                            <button type='button' class='quantity-btn minus' onclick='updateQuantity(this, -1)'>-</button>
                            <input type='number' name='quantity' value='1' min='1' style='width: 50px; text-align: center;' id='quantity-{$product['PartNo']}'>
                            <button type='button' class='quantity-btn plus' onclick='updateQuantity(this, 1)'>+</button>
                        </div>
                        <button type='submit' class='add-to-cart-btn'>Add To Cart</button>
                    </form>
                </div>";
            }
        } else {
            echo "<p style='text-align: center; width: 100%;'>No products found in $sectionTitle.</p>";
        }
        echo "</div>";
    }

    // Display products from ProductInventory table
    displayProducts($productInventoryProducts, 'Solapur Products', $fullname, $account_type);

    // Display products from KolhapurData table
    displayProducts($kolhapurdataProducts, 'Kolhapur Products', $fullname, $account_type);

    $conn->close();
    ?>
    <script>
        let currentImageIndex = 0;
        const images = document.querySelectorAll('.card img');

        function openImagePopup(index) {
            currentImageIndex = index;
            const popup = document.getElementById('imagePopup');
            const popupImage = document.getElementById('popupImage');
            const popupProductName = document.getElementById('popupProductName');
            popupImage.src = images[index].src;
            popupProductName.textContent = images[index].closest('.card').querySelector('h4').textContent;
            popup.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }

        function closeImagePopup() {
            const popup = document.getElementById('imagePopup');
            popup.style.display = 'none';
            document.body.style.overflow = 'auto';
        }

        function navigateImage(direction) {
            currentImageIndex += direction;
            if (currentImageIndex < 0) {
                currentImageIndex = images.length - 1;
            } else if (currentImageIndex >= images.length) {
                currentImageIndex = 0;
            }
            const popupImage = document.getElementById('popupImage');
            const popupProductName = document.getElementById('popupProductName');
            popupImage.src = images[currentImageIndex].src;
            popupProductName.textContent = images[currentImageIndex].closest('.card').querySelector('h4').textContent;
        }

        // Keyboard navigation
        document.addEventListener('keydown', function(event) {
            const popup = document.getElementById('imagePopup');
            if (popup.style.display === 'flex') {
                if (event.key === 'ArrowRight') {
                    navigateImage(1);
                } else if (event.key === 'ArrowLeft') {
                    navigateImage(-1);
                } else if (event.key === 'Escape') {
                    closeImagePopup();
                }
            }
        });

        function updateQuantity(button, change) {
            const input = button.parentElement.querySelector("input[name='quantity']");
            let currentValue = parseInt(input.value);
            currentValue += change;
            if (currentValue < 1) currentValue = 1;
            input.value = currentValue;
        }

        async function addToCart(event, form) {
            event.preventDefault();
            const formData = new FormData(form);
            formData.append('feedback', form.closest('.card').querySelector("textarea[name='feedback']").value);

            const button = form.querySelector('.add-to-cart-btn');

            const response = await fetch('cart.php', {
                method: 'POST',
                body: formData,
            });

            if (response.ok) {
                button.style.backgroundColor = '#28a745';
                button.textContent = 'Added To Cart!';
                button.disabled = true;
                updateCartCount();

                setTimeout(() => {
                    button.style.backgroundColor = '';
                    button.textContent = 'Add To Cart';
                    button.disabled = false;
                }, 3000);
            } else {
                alert('Failed to add product to cart. Please try again.');
            }
        }

        document.addEventListener("DOMContentLoaded", function () {
            const searchInput = document.getElementById("searchInput");
            const searchButton = document.getElementById("searchButton");

            function filterProducts() {
                const searchText = searchInput.value.toLowerCase();
                const cards = document.querySelectorAll(".card");

                cards.forEach(card => {
                    const productName = card.querySelector("h4").textContent.toLowerCase();
                    const partNumber = card.querySelector("p:nth-of-type(4)").textContent.toLowerCase();

                    if (productName.includes(searchText) || partNumber.includes(searchText)) {
                        card.style.display = "block";
                    } else {
                        card.style.display = "none";
                    }
                });
            }

            searchInput.addEventListener("keyup", function (event) {
                if (event.key === "Enter") {
                    filterProducts();
                }
            });

            searchButton.addEventListener("click", filterProducts);
        });

        document.addEventListener("keydown", function(event) {
            const activeElement = document.activeElement;
            if (event.key === "Backspace" && (activeElement.tagName !== "INPUT" && activeElement.tagName !== "TEXTAREA")) {
                event.preventDefault();
                window.history.back();
            }
        });

        document.addEventListener("keydown", function(event) {
            if (event.ctrlKey && event.key.toLowerCase() === "s") {
                event.preventDefault();
                const searchInput = document.getElementById("searchInput");
                if (searchInput) {
                    searchInput.focus();
                }
            }
        });

        function updateCartCount() {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "cart_count.php", true);
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    let count = xhr.responseText.trim();
                    let cartBadge = document.getElementById("cart-count");

                    if (cartBadge.innerText !== count) {
                        cartBadge.innerText = count;
                        cartBadge.classList.add("updated");
                        setTimeout(() => cartBadge.classList.remove("updated"), 300);
                    }
                }
            };
            xhr.send();
        }

        setInterval(updateCartCount, 1000);

        function toggleCalculator() {
            let popup = document.getElementById("calculatorPopup");
            popup.style.display = (popup.style.display === "block") ? "none" : "block";
        }

        function appendToDisplay(value) {
            document.getElementById("display").value += value;
        }

        function clearDisplay() {
            document.getElementById("display").value = "";
        }

        function calculateResult() {
            try {
                let expression = document.getElementById("display").value;
                expression = expression.replace(/%/g, "/100");
                document.getElementById("display").value = eval(expression);
            } catch {
                document.getElementById("display").value = "Error";
            }
        }

        function backspace() {
            let display = document.getElementById("display");
            display.value = display.value.slice(0, -1);
        }

        if (!document.cookie.split('; ').find(row => row.startsWith('visited='))) {
            document.cookie = "visited=true; max-age=" + 60 * 60 * 24 * 7 + "; path=/";
            console.log("First-time visit: full content loading");
        } else {
            console.log("Returning visitor: use optimized content if needed");
        }
    </script>
</body>
</html>