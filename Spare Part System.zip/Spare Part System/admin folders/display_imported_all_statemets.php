<?php
if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}
// Database connection
try {
    $pdo = new PDO("mysql:host=127.0.0.1:3306;dbname=u494849712_part", "u494849712_patilnagesh007", "Password@1381");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Fetch all customers
$stmt = $pdo->query("SELECT * FROM statement_user_name ORDER BY statement_id");
$customers = $stmt->fetchAll(PDO::FETCH_ASSOC);
$stmt->closeCursor();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Account Statements</title>
    <link rel="icon" href="../image/icon.png" type="image/png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        h2 {
            color: #555;
            margin-top: 30px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 40px;
        }
        th,td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr {
            background-color: #fff !important;
        }
        .summary-row {
            font-weight: bold;
            background-color: #f0f0f0;
        }
        /* Search Bar Container */
        .search-container {
            position: relative;
            width: 50%;
            margin: 20px auto;
        }
        /* Input Field with Embedded Icon */
        #searchInput {
            width: 100%;
            padding: 12px 15px 12px 45px; /* Space for the icon */
            font-size: 16px;
            border: 2px solid #ddd;
            border-radius: 25px;
            outline: none;
            transition: 0.3s;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            background-color: #fff;
            background: url("https://cdn-icons-png.flaticon.com/512/482/482631.png") no-repeat 15px center; 
            background-size: 18px; /* Adjust icon size */
        }
        /* Hover & Focus Effects */
        #searchInput:hover,
        #searchInput:focus {
            border-color: #007bff;
            box-shadow: 0px 4px 8px rgba(0, 123, 255, 0.3);
        }
        .customer-section {
            display: block;
            /* Default visibility */
        }
        /* Responsive Design */
        @media screen and (max-width: 768px) {
            .search-container {
                width: 80%;
            }
            #searchInput {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <h1>All Account Statements</h1>
    <!-- Search Input -->
    <div class="search-container">
        <input type="text" id="searchInput" placeholder="Search by customer name..." onkeyup="filterCustomers()">
    </div>

    <?php if (empty($customers)): ?>
        <p>No data available.</p>
    <?php else: ?>
        <?php foreach ($customers as $customer): ?>
            <div class="customer-section" data-customer-name="<?php echo htmlspecialchars(strtolower($customer['user_name'])); ?>">
                <h2><?php echo htmlspecialchars($customer['user_name']); ?></h2>
                <p>Period: <?php echo htmlspecialchars($customer['from_date']); ?> to <?php echo htmlspecialchars($customer['to_date']); ?></p>

                <!-- Fetch Opening Balance -->
                <?php
                $stmt = $pdo->prepare("SELECT * FROM opening_balance WHERE statement_id = :statement_id");
                $stmt->execute([':statement_id' => $customer['statement_id']]);
                $opening_balance = $stmt->fetch(PDO::FETCH_ASSOC);
                $stmt->closeCursor();
                ?>

                <!-- Fetch Transactions -->
                <?php
                $stmt = $pdo->prepare("SELECT * FROM statement_all_data WHERE statement_id = :statement_id ORDER BY date");
                $stmt->execute([':statement_id' => $customer['statement_id']]);
                $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $stmt->closeCursor();
                ?>

                <!-- Fetch Total Amounts -->
                <?php
                $stmt = $pdo->prepare("SELECT * FROM statement_total_amt WHERE statement_id = :statement_id");
                $stmt->execute([':statement_id' => $customer['statement_id']]);
                $total_amt = $stmt->fetch(PDO::FETCH_ASSOC);
                $stmt->closeCursor();
                ?>

                <!-- Fetch Closing Balance -->
                <?php
                $stmt = $pdo->prepare("SELECT * FROM closing_balance WHERE statement_id = :statement_id");
                $stmt->execute([':statement_id' => $customer['statement_id']]);
                $closing_balance = $stmt->fetch(PDO::FETCH_ASSOC);
                $stmt->closeCursor();
                ?>

                <!-- Transactions Table with Opening Balance, Total, and Closing Balance -->
                <table>
                    <tr>
                        <th>Date</th>
                        <th>Doc/Chq. No.</th>
                        <th>Type</th>
                        <th>Particulars</th>
                        <th>Credit</th>
                        <th>Debit</th>
                        <th>Closing Balance</th>
                    </tr>
                    <!-- Opening Balance Row -->
                    <tr class="summary-row">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>Opening Balance:</td>
                        <td><?php echo number_format($opening_balance['credit_amt'] ?? 0, 2); ?></td>
                        <td><?php echo number_format($opening_balance['debit_amt'] ?? 0, 2); ?></td>
                        <td><?php echo htmlspecialchars($opening_balance['closer_balance'] ?? 'N/A'); ?></td>
                    </tr>
                    <!-- Transaction Rows -->
                    <?php foreach ($transactions as $transaction): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($transaction['date']); ?></td>
                            <td><?php echo htmlspecialchars($transaction['doc_no'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($transaction['type'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($transaction['particulars']); ?></td>
                            <td><?php echo $transaction['credit'] !== null ? number_format($transaction['credit'], 2) : ''; ?></td>
                            <td><?php echo $transaction['debit'] !== null ? number_format($transaction['debit'], 2) : ''; ?></td>
                            <td><?php echo htmlspecialchars($transaction['closing_balance'] ?? ''); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <!-- Total Row -->
                    <tr class="summary-row">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>Total:</td>
                        <td><?php echo number_format($total_amt['credit_amt'] ?? 0, 2); ?></td>
                        <td><?php echo number_format($total_amt['debit_amt'] ?? 0, 2); ?></td>
                        <td></td>
                    </tr>
                    <!-- Closing Balance Row -->
                    <tr class="summary-row">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>Closing Balance:</td>
                        <td></td>
                        <td></td>
                        <td><?php echo htmlspecialchars($closing_balance['closing_balance'] ?? 'N/A'); ?></td>
                    </tr>
                </table>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <script>
        function filterCustomers() {
            // Get the search input value and convert to lowercase
            const searchValue = document.getElementById('searchInput').value.toLowerCase();
            // Get all customer sections
            const customerSections = document.getElementsByClassName('customer-section');

            // Loop through each customer section
            for (let i = 0; i < customerSections.length; i++) {
                const customerName = customerSections[i].getAttribute('data-customer-name');
                // Show or hide based on whether the customer name contains the search value
                if (customerName.includes(searchValue)) {
                    customerSections[i].style.display = 'block';
                } else {
                    customerSections[i].style.display = 'none';
                }
            }
        }
    </script>
</body>

</html>