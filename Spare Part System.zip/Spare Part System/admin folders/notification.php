<?php
session_start();
include '../db.php';

// Prevent accessing this page after logout
if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}
// Fetch new orders where is_seen = 0
$query = "SELECT id, submit_id, product, totalSaleRate, quantity, created_at FROM orders WHERE is_seen = 0 ORDER BY created_at DESC";
$result = $conn->query($query);
$orders = [];

while ($row = $result->fetch_assoc()) {
    $orders[] = $row;
}

// Mark orders as seen when this page is opened
$conn->query("UPDATE orders SET is_seen = 1 WHERE is_seen = 0");
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications</title>
    <link rel="icon" href="../image/icon.png" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            background-color: #EEF2FE;
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            color: white;
            border-radius: 50%;
            text-decoration: none;
            font-size: 22px;
            transition: all 0.3s ease;
            position: fixed; /* Optional: fixed position */
            top: 10px;
            left: 20px;
            z-index: 999;
        }
        .back-button:hover {
            transform: scale(1.1);
            color: #fff;
        }
        .back-button .home {
            height: 55px; 
            width: auto;  
            margin-right: 10px; 
            vertical-align: middle;
            object-fit: contain;
        }
    </style>
</head>
<body>
    <?php include("preloader.html"); ?>
<a href='admin_dashboard.php' class='back-button'><img src="../image/h1.png" class="home" alt="ok"></a>
    <div class="container mt-5">
        <h3>New Order Notifications</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Product Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Time</th>
                    <th>View Order</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($orders)): ?>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($order['product']); ?></td>
                            <td>₹<?php echo number_format($order['totalSaleRate'], 1); ?></td>
                            <td><?php echo number_format($order['quantity']); ?></td>
                            <td><?php echo date("d M Y, h:i A", strtotime($order['created_at'])); ?></td>
                            <td>
                                <a href="view_order.php?submit_id=<?php echo $order['submit_id']; ?>" class="btn btn-primary">View Order</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="4" class="text-center">No new notifications</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
