<?php
$serialNumber = 1;
if ($result->num_rows > 0):
?>

<button class="btn btn-success" id="submitAllOrders" style="float: right; margin-bottom: 20px; margin-right: 20px; margin-top: 10px;"><i class="fa fa-check-circle"></i> Submit Orders</button>

<div class="table-container">
    <div class="printable-content">
        <table border="1" class="table table-bordered" id="ordersTable">
            <thead>
                <tr>
                    <th><input type="checkbox" id="selectAll"></th>
                    <th>Sr.No</th>
                    <th>Product</th>
                    <th>Order No</th>
                    <th>Account</th>
                    <th>Party Name</th>
                    <th>Account Type</th>
                    <th>Batch</th>
                    <th>Company</th>
                    <th>Part No</th>
                    <th>Purchase Rate</th>
                    <th>Total Sale Rate</th>
                    <th>Enter Sale Rate</th>
                    <th>Updated Sale Rate</th>
                    <th>Cls Qty</th>
                    <th>Location</th>
                    <th>Qty</th>
                    <th>Customer Feedback</th>
                    <th>Warehouse Remark</th>
                    <th>Admin Remark</th>
                    <th>Order Date</th>
                    <th>Delete</th>
                    <th>Edit</th>
                </tr>
            </thead>
            <tbody>
                    <?php $highlight_submit_id = isset($_GET['highlight_submit_id']) ? $_GET['highlight_submit_id'] : '';
                    $serialNumber = 1;
                    while ($row = $result->fetch_assoc()): 
                    $highlight = ($row['submit_id'] == $highlight_submit_id) ? 'table-success' : '';?>
                    <tr class="<?php echo $highlight; ?>" data-submit-id="<?php echo $row['submit_id']; ?>">
                        <td><input type="checkbox" class="order-checkbox" data-submit_id="<?php echo htmlspecialchars($row['submit_id']); ?>" value="<?php echo htmlspecialchars($row['submit_id']); ?>"></td>
                        <td><?php echo $serialNumber++; ?></td>
                        <td data-lable="Product" class="product-column"><?php echo htmlspecialchars($row['product']); ?></td>
                        <td><?php echo htmlspecialchars($row['submit_id']); ?></td>
                        <td><?php echo htmlspecialchars($row['fullname']); ?></td>
                        <td><?php echo htmlspecialchars($row['customer_fullname']); ?></td>
                        <td><?php echo htmlspecialchars($row['account_type']); ?></td>
                        <td data-label="Batch"><?php echo htmlspecialchars($row['batch']); ?></td>
                        <td data-label="Company"><?php echo htmlspecialchars($row['company']); ?></td>
                        <td data-label="Part No"><?php echo htmlspecialchars($row['partNo']); ?></td>
                        <td data-label="Purchase Rate"><?php echo htmlspecialchars($row['purchaseRate']); ?></td>
                        <td data-label="Total Sale Rate"><?php echo htmlspecialchars($row['totalSaleRate']); ?></td>
                        <td class="enter_column" data-label="Enter Sale Rate"><input type="text" oninput="updateSaleRate(this, '<?php echo $row['submit_id']; ?>')" class="enter-sale-rate"value="<?php echo htmlspecialchars($row['enterSaleRate']); ?>"></td>
                        <td data-label="Updated Sale Rate" class="updated-sale-rate"><?php echo htmlspecialchars($row['updatedSaleRate']); ?></td>
                        <td data-label="Closing Qty"><?php echo htmlspecialchars($row['closingQty']); ?></td>
                        <td data-label="Location"><?php echo htmlspecialchars($row['location']); ?></td>
                        <td data-label="Quantity"><span class="editable" data-column="quantity"><?php echo htmlspecialchars($row['quantity']); ?></span>
                        <input type="text" class="edit-input" data-column="quantity" value="<?php echo htmlspecialchars($row['quantity']); ?>" style="display: none;"></td>
                        <td class="feedback-column" id="feedback-column"><?php echo htmlspecialchars($row['feedback']); ?></td>
                        <td class="remark-column"><?php echo htmlspecialchars($row['remark']); ?></td>



                        <td class="admin-remark-cell">
                        <span class="remark-text"><?php echo htmlspecialchars($row['admin_remark']); ?></span>
                        <input type="text" class="remark-input form-control" style="display:none;" value="<?php echo htmlspecialchars($row['admin_remark']); ?>">
                        <button type="button" class="btn btn-sm btn-primary edit-remark-btn">Remark</button>
                    </td>



                        <td class="order_date" data-lable="Order Date"><?= date('d-m-Y h:i A', strtotime($row['order_date'])) ?></td>
                        <td data-label="Delete"><button type="submit" class="delete-btn" data-submit-id="<?php echo $row['submit_id']; ?>">Delete</button></td>
                        <td data-label="Edit"><button type="button" class="btn btn-primary btn-sm edit-btn"><i class="fa-solid fa-pencil"></i> Edit</button></td>
                        </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
<?php else: ?>
<tr>
    <td colspan="15" class="text-center">No orders found.</td>
</tr>
<?php endif; ?>
<?php if (!empty($highlight_submit_id)): ?>
<script>
    // Smooth scroll to highlighted row
    document.getElementById("<?= $highlight_submit_id ?>").scrollIntoView({ behavior: 'smooth', block: 'center' });

    // Remove highlight after 5 seconds
    setTimeout(() => {
        document.getElementById("<?= $highlight_submit_id ?>").classList.remove('table-success');
    }, 5000);
</script>
<?php endif; ?>
<script src="../admin folders/order.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {  
        $("#selectAll").change(function() {
            $(".order-checkbox").prop('checked', this.checked);
        });

        $(".order-checkbox").change(function() {
            $("#selectAll").prop("checked", $(".order-checkbox:checked").length === $(".order-checkbox").length);
        });

        $("#submitAllOrders").click(function() {
            let selectedOrders = [];
            $(".order-checkbox:checked").each(function() {
                selectedOrders.push($(this).data("submit_id")); // ✅ FIXED HERE
            });

            if (selectedOrders.length === 0) {
                alert("Please select at least one order.");
                return;
            }

            if (selectedOrders.length === 1) {
                $("#modalSubmitId").text("Submitting order: " + selectedOrders[0]);
            } else {
                $("#modalSubmitId").html("Submitting " + selectedOrders.length + " orders:<br>" + selectedOrders.join("<br>"));
            }

            $("#loadingModal").modal("show");

            $.ajax({
                url: "orders_submit.php",
                type: "POST",
                data: {
                    orderIds: selectedOrders
                },
                success: function(response) {
                    console.log("Raw response:", response);
                    let result;
                    try {
                        result = JSON.parse(response);
                    } catch (e) {
                        console.error("Failed to parse response:", e);
                        alert("Invalid response from server.");
                        $("#loadingModal").modal("hide");
                        return;
                    }

                    setTimeout(() => {
                        $("#loadingModal").fadeOut("slow", function() {
                            $(this).modal("hide");
                        });
                    }, 2000);

                    setTimeout(() => {
                        if (result.success) {
                            window.location.reload();
                        } else {
                            alert("Error: " + result.error);
                        }
                    }, 2500);
                },
                error: function(xhr, status, error) {
                    console.error("AJAX error:", status, error);
                    alert("Failed to submit orders. Check console for details.");
                    $("#loadingModal").modal("hide");
                }
            });
        });
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        // On Edit button click: show input box
        $(".edit-btn").click(function () {
            let row = $(this).closest("tr");
            row.find(".editable").hide();
            row.find(".edit-input").show().focus();
        });

        // On Enter key inside input field
        $(".edit-input").keypress(function (e) {
            if (e.which === 13) {
                let inputField = $(this);
                let newValue = inputField.val().trim();
                let columnName = inputField.data("column");
                let submitId = inputField.closest("tr").data("submit-id");

                if (newValue === "") {
                    alert("Quantity cannot be empty.");
                    return;
                }

                $.ajax({
                    url: "order_update.php",
                    method: "POST",
                    data: {
                        id: submitId,
                        column: columnName,
                        value: newValue
                    },
                    success: function (response) {
                        if (response.trim() === "success") {
                            inputField.hide();
                            inputField.siblings(".editable").text(newValue).show();
                        } else {
                            alert("Update failed. Please try again.");
                        }
                    }
                });
            }
        });

        // Hide input on blur
        $(".edit-input").blur(function () {
            $(this).hide();
            $(this).siblings(".editable").show();
        });
    });
</script>
<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        // Select All
        $("#selectAll").click(function() {
            $(".order-checkbox").prop("checked", this.checked);
        });

        // Delete Orders
        $("#deleteOrders").click(function() {
            let selectedOrders = [];

            $(".order-checkbox:checked").each(function() {
                selectedOrders.push($(this).data("submit_id"));
            });

            if (selectedOrders.length > 0) {
                if (confirm("Are you sure you want to delete the selected orders?")) {
                    $.ajax({
                        url: 'order_delete_selected.php',
                        type: 'POST',
                        data: { orderIds: selectedOrders },
                        success: function(response) {
                            alert(response);
                            location.reload();
                        },
                        error: function() {
                            alert("Error occurred while deleting orders.");
                        }
                    });
                }
            } else {
                alert("Please select at least one order to delete.");
            }
        });
    });

    //Search Customer_fullname JS  
    document.getElementById("searchCustomer").addEventListener("input", function () {
        const searchValue = this.value.toLowerCase();
        const rows = document.querySelectorAll("#ordersTable tbody tr");
        let count = 0;

        rows.forEach(row => {
            const customerName = row.cells[5].textContent.toLowerCase();
            if (customerName.includes(searchValue)) {
                row.style.display = "";
                count++;
            } else {
                row.style.display = "none";
            }
        });

        document.getElementById("totalOrders").innerText = 
            searchValue ? `Total Orders for "${this.value}": ${count}` : '';
    });
</script>
<!-- Required JS -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$(document).ready(function() {
    // Edit button click for admin remark
    $(document).on('click', '.edit-remark-btn', function() {
        var cell = $(this).closest('.admin-remark-cell');
        cell.find('.remark-text').hide();
        cell.find('.remark-input').show().focus();
        $(this).hide(); // Hide the "Remark" button
    });

    // When press ENTER inside input
    $(document).on('keydown', '.remark-input', function(e) {
        if (e.key === 'Enter') {
            var input = $(this);
            var newRemark = input.val();
            var row = input.closest('tr');
            var submitId = row.data('submit-id');

            if (submitId && newRemark.trim() !== '') {
                $.ajax({
                    url: 'update_admin_remark.php',
                    method: 'POST',
                    data: { submit_id: submitId, admin_remark: newRemark },
                    success: function(response) {
                        if (response.trim() === 'success') {
                            input.hide();
                            row.find('.remark-text').text(newRemark).show();
                            row.find('.edit-remark-btn').show();
                        } else {
                            alert('Failed to update remark.');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX Error:', error);
                        alert('Error updating remark.');
                    }
                });
            }
        }
    });
});
</script>