<?php
include '../db.php';
$query = $_GET['query'] ?? '';
$fullname = isset($_GET['name']) ? $_GET['name'] : '';
$account_type = isset($_GET['account_type']) ? $_GET['account_type'] : '';

$query = trim($query);

if ($query !== '') {
    $query = "%$query%";

    $sql = "
        SELECT Product, 'Solapur' as source FROM productinventory WHERE Product LIKE ?
        UNION
        SELECT Product, 'kolhapur' as source FROM kolhapurdata WHERE Product LIKE ?
        LIMIT 10
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $query, $query);
    $stmt->execute();
    $result = $stmt->get_result();

    echo "<div id='suggestionList' style='position: absolute; width: 300px; background-color: #fff; border: 1px solid #ccc; border-top: none; border-radius: 0 0 6px 6px; max-height: 250px; overflow-y: auto; box-shadow: 0 4px 6px rgba(0,0,0,0.1); z-index: 1000;'>";

    while ($row = $result->fetch_assoc()) {
        $product = htmlspecialchars($row['Product']);
        $source = htmlspecialchars($row['source']);
        echo "
        <div class='suggestion-item' style='padding: 10px 12px; cursor: pointer; border-bottom: 1px solid #eee; transition: background-color 0.2s;' 
             onclick=\"window.location.href='display_products.php?product=" . urlencode($product) . "&source=" . urlencode($source) . "&name=" . urlencode($fullname) . "&account_type=" . urlencode($account_type) . "'\">
            <span style='font-size: 14px; color: #333;'>$product <small style='color: #888;'>($source)</small></span>
        </div>";
    }
    
    echo "</div>";
    $result->free(); // Free the result set
    $stmt->close();
}
$conn->close();
?>