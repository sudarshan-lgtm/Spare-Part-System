<?php
session_start();
require '../vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\IOFactory;

// Prevent accessing this page after logout
if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}

$pdo = new PDO("mysql:host=127.0.0.1:3306;dbname=u494849712_part", "u494849712_patilnagesh007", "Password@1381");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$message = "";
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file2']) && $_FILES['file2']['error'] === 0) {
    try {
        $spreadsheet = IOFactory::load($_FILES['file2']['tmp_name']);
        $data = $spreadsheet->getActiveSheet()->toArray();

        $valid = false;
        foreach ($data as $row) {
            if (strpos($row[0], "A/c. Receivable Detail Report") !== false) {
                $valid = true;
                break;
            }
        }

        if (!$valid) {
            throw new Exception("Invalid file. Please upload the correct Receivable report.");
        }

        $reportTitle = null;
        $reportDate = null;
        $currentCustomer = null;
        $reportId = null;
        $customerId = null;

        foreach ($data as $row) {
            if (strpos($row[0], "A/c. Receivable Detail Report") !== false) {
                $reportTitle = $row[0];
            }

            if (strpos($row[0], "As On Date") !== false) {
                $dateStr = trim(str_replace("As On Date", "", $row[0]));
                $reportDate = DateTime::createFromFormat('d/m/Y', $dateStr) ?: DateTime::createFromFormat('d-m-Y', $dateStr);
                $reportDate = $reportDate ? $reportDate->format('Y-m-d') : null;

                $stmt = $pdo->prepare("INSERT INTO receivable_report_info2 (report_title, report_date) VALUES (?, ?)");
                $stmt->execute([$reportTitle, $reportDate]);
                $reportId = $pdo->lastInsertId();
                $stmt->closeCursor();
            }

            if (!empty($row[0]) && empty($row[1]) && empty($row[2]) && !is_numeric($row[0])) {
                $currentCustomer = trim($row[0]);
                $stmt = $pdo->prepare("INSERT INTO receivable_customers2 (report_id, customer_name) VALUES (?, ?)");
                $stmt->execute([$reportId, $currentCustomer]);
                $customerId = $pdo->lastInsertId();
                $stmt->closeCursor();
                continue;
            }

            if (preg_match('/^\d{2}[\/-]\d{2}[\/-]\d{4}$/', $row[0])) {
                $billDateObj = DateTime::createFromFormat('d/m/Y', $row[0]) ?: DateTime::createFromFormat('d-m-Y', $row[0]);
                $billDate = $billDateObj ? $billDateObj->format('Y-m-d') : null;

                $stmt = $pdo->prepare("INSERT INTO receivable_entries2 (
                    customer_id, bill_date, bill_no, type, due_days, bill_amount, adv_amount, adjusted_amount, pending_amount, cumulative_balance
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

                $stmt->execute([
                    $customerId,
                    $billDate,
                    $row[1] ?? null,
                    $row[2] ?? null,
                    is_numeric($row[3]) ? $row[3] : null,
                    $row[4] ?? null,
                    $row[5] ?? null,
                    $row[6] ?? null,
                    $row[7] ?? null,
                    $row[8] ?? null
                ]);
                $stmt->closeCursor();
            }

            if (trim($row[0]) === '' && strtolower(trim($row[2])) !== 'opening' && is_numeric($row[3])) {
                $stmt = $pdo->prepare("INSERT INTO receivable_totals2 (
                    customer_id, due_days, bill_amount, adv_amount, adjusted_amount, pending_amount, cumulative_balance
                ) VALUES (?, ?, ?, ?, ?, ?, ?)");

                $stmt->execute([
                    $customerId,
                    $row[3] ?? null,
                    $row[4] ?? null,
                    $row[5] ?? null,
                    $row[6] ?? null,
                    $row[7] ?? null,
                    $row[8] ?? null
                ]);
                $stmt->closeCursor();
            }
        }

        $message = "<div class='alert alert-success text-center mt-3'>✅ Data imported successfully!</div>";

    } catch (Exception $e) {
        $error = "<div class='alert alert-danger text-center mt-3'>❌ " . $e->getMessage() . "</div>";
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file']) && $_FILES['file']['error'] === 0) {
    try {
        $spreadsheet = IOFactory::load($_FILES['file']['tmp_name']);
        $data = $spreadsheet->getActiveSheet()->toArray();

        // Minimal file validation
        $valid = false;
        foreach ($data as $row) {
            if (strpos($row[0], "A/c. Receivable Detail Report") !== false) {
                $valid = true;
                break;
            }
        }

        if (!$valid) {
            throw new Exception("Invalid file. Please upload the correct Receivable report.");
        }

        // Initialize variables
        $reportTitle = null;
        $reportDate = null;
        $currentCustomer = null;
        $reportId = null;
        $customerId = null;

        foreach ($data as $row) {
            if (strpos($row[0], "A/c. Receivable Detail Report") !== false) {
                $reportTitle = $row[0];
            }

            if (strpos($row[0], "As On Date") !== false) {
                $dateStr = trim(str_replace("As On Date", "", $row[0]));
                $reportDate = DateTime::createFromFormat('d/m/Y', $dateStr) ?: DateTime::createFromFormat('d-m-Y', $dateStr);
                $reportDate = $reportDate ? $reportDate->format('Y-m-d') : null;

                $stmt = $pdo->prepare("INSERT INTO receivable_report_info (report_title, report_date) VALUES (?, ?)");
                $stmt->execute([$reportTitle, $reportDate]);
                $reportId = $pdo->lastInsertId();
                $stmt->closeCursor();
            }

            if (!empty($row[0]) && empty($row[1]) && empty($row[2]) && !is_numeric($row[0])) {
                $currentCustomer = trim($row[0]);
                $stmt = $pdo->prepare("INSERT INTO receivable_customers (report_id, customer_name) VALUES (?, ?)");
                $stmt->execute([$reportId, $currentCustomer]);
                $customerId = $pdo->lastInsertId();
                $stmt->closeCursor();
                continue;
            }

            if (preg_match('/^\d{2}[\/-]\d{2}[\/-]\d{4}$/', $row[0])) {
                $billDateObj = DateTime::createFromFormat('d/m/Y', $row[0]) ?: DateTime::createFromFormat('d-m-Y', $row[0]);
                $billDate = $billDateObj ? $billDateObj->format('Y-m-d') : null;

                $stmt = $pdo->prepare("INSERT INTO receivable_entries (
                    customer_id, bill_date, bill_no, type, due_days, bill_amount, adv_amount, adjusted_amount, pending_amount, cumulative_balance
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

                $stmt->execute([
                    $customerId,
                    $billDate,
                    $row[1] ?? null,
                    $row[2] ?? null,
                    is_numeric($row[3]) ? $row[3] : null,
                    $row[4] ?? null,
                    $row[5] ?? null,
                    $row[6] ?? null,
                    $row[7] ?? null,
                    $row[8] ?? null
                ]);
                $stmt->closeCursor();
            }

            if (trim($row[0]) === '' && strtolower(trim($row[2])) !== 'opening' && is_numeric($row[3])) {
                $stmt = $pdo->prepare("INSERT INTO receivable_totals (
                    customer_id, due_days, bill_amount, adv_amount, adjusted_amount, pending_amount, cumulative_balance
                ) VALUES (?, ?, ?, ?, ?, ?, ?)");

                $stmt->execute([
                    $customerId,
                    $row[3] ?? null,
                    $row[4] ?? null,
                    $row[5] ?? null,
                    $row[6] ?? null,
                    $row[7] ?? null,
                    $row[8] ?? null
                ]);
                $stmt->closeCursor();
            }
        }
        
        $message = "success";
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

//Upload Image folder


$zip_upload_dir = "../admin folders/uploads/zip/";

// Handle zip upload and extraction
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['zip_file'])) {
    $main_zip = $_FILES['zip_file']['tmp_name'];
    $main_zip_name = $_FILES['zip_file']['name'];
    $upload_path = $zip_upload_dir . basename($main_zip_name);

    if (move_uploaded_file($main_zip, $upload_path)) {
        $zip = new ZipArchive();
        if ($zip->open($upload_path) === TRUE) {
            $zip->extractTo($zip_upload_dir); // Extract main zip
            $zip->close();
            unlink($upload_path); // Delete main zip after extract

            // Extract each company zip
            foreach (glob($zip_upload_dir . "*.zip") as $company_zip_path) {
                $company_name = pathinfo($company_zip_path, PATHINFO_FILENAME);
                $company_folder = $zip_upload_dir . $company_name . '/';

                if (!file_exists($company_folder)) {
                    mkdir($company_folder, 0777, true);
                }

                $company_zip = new ZipArchive();
                if ($company_zip->open($company_zip_path) === TRUE) {
                    $company_zip->extractTo($company_folder); // Extract into its folder
                    $company_zip->close();
                    unlink($company_zip_path); // Delete company zip after extract
                }
            }

            $_SESSION['upload_message'] = "Main ZIP uploaded and all companies extracted successfully.";
        } else {
            $_SESSION['upload_message'] = "Failed to extract the uploaded ZIP.";
        }
            // Redirect back to the main page to avoid resubmission
    header("Location: upload_folder_excel.php");
    exit;  // Make sure to exit to stop the script
    } else {
        $_SESSION['upload_message'] = "Failed to upload ZIP.";
    }
    
    header("Location: upload_folder_excel.php");
    exit;
}

// Handle ZIP delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_zip_data'])) {
    $deleted = true;

    foreach (glob($zip_upload_dir . "*") as $file) {
        if (is_dir($file)) {
            // Recursively delete folder
            $it = new RecursiveDirectoryIterator($file, RecursiveDirectoryIterator::SKIP_DOTS);
            $files = new RecursiveIteratorIterator($it, RecursiveIteratorIterator::CHILD_FIRST);
            foreach ($files as $f) {
                $f->isDir() ? rmdir($f) : unlink($f);
            }
            rmdir($file);
        } else {
            if (!unlink($file)) {
                $deleted = false;
            }
        }
    }

    if ($deleted) {
        $_SESSION['upload_message'] = ['type' => 'success', 'text' => '✅ All ZIP data deleted successfully!'];
    } else {
        $_SESSION['upload_message'] = ['type' => 'error', 'text' => '❌ Failed to delete some files or folders.'];
    }

    header("Location: upload_folder_excel.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="../admin folders/css/upload_excel.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <title>Upload Files</title>
</head>
<body>
    <?php include("preloader.html"); ?>
    <nav class="navbar">
    <a href='admin_dashboard.php' class='back-button'><i class="fa fa-home" aria-hidden="true"></i></a>
    <img src="../image/RJ bg.png" class="logo" alt="RJ">
        <a href="../admin folders/upload_folder_excel.php" class="cart-icon">🛒</a>
    </nav>
    
    
    <!-- Excel Uploaded for ProductInventory And Folder Uploaded into uploads/folders-->
    <p style="text-align: center;" class="top">Import Solapur Folder & Excel</p>
    <div class="search-container">
        <form action="upload_files.php" method="post" enctype="multipart/form-data" class="form-column">
            <div class="form-item">
                <label for="uploadFolder" class="select">Select Image Folder:</label>
                <input type="file" name="folder[]" id="uploadFolder" webkitdirectory multiple required>
            </div>
            <button type="submit" name="upload_folder">Import Folder</button>
        </form>

        <form action="upload_files.php" method="post" enctype="multipart/form-data" class="form-column">
            <div class="form-item">
                <label for="uploadExcel" class="select">Select Excel File:</label>
                <input type="file" name="excelFile" id="uploadExcel" accept=".xlsx, .xls" required>
            </div>
            <button type="submit" name="upload_excel">Import Excel</button>
        </form>  
        
        <form action="folder.php" style="margin: 0;">
            <button onclick="checkPassword()" type="submit">Folders</button>
        </form>
    </div>
    
    
    <!-- Excel Uploaded for Solapurdata-->
    <!--<p style="text-align: center;">Import Solapur File</p>
    <div class="search-container">
        <form action="upload_files.php" method="post" enctype="multipart/form-data" class="form-column">
            <div class="form-item">
                <label for="uploadSolapurExcel" class="select">Select Solapur Excel File:</label>
                <input type="file" name="solapurExcel" id="uploadSolapurExcel" accept=".xlsx, .xls" required>
            </div>
            <button type="submit" name="upload_solapur">Import Excel</button>
        </form>  
    </div>-->
    
    
    <!-- Excel Uploaded for Kolhapurdata-->
    <p style="text-align: center;">Import Kolhapur File</p>
    <div class="search-container">
        <form action="upload_files.php" method="post" enctype="multipart/form-data" class="form-column">
            <div class="form-item">
                <label for="uploadKolhapurExcel" class="select">Select Kolhapur Excel File:</label>
                <input type="file" name="kolhapurExcel" id="uploadKolhapurExcel" accept=".xlsx, .xls" required>
            </div>
            <button type="submit" name="upload_kolhapur">Import Excel</button>
        </form> 
        <a href="last_imported_excels.php"><button>📂 Last Imported Excel</button></a> 
    </div>
    
    
    <!-- Zip File Uploaded for PDF-->
    <p style="text-align: center;">Import Zip For Products</p>
    <div class="search-container">
        <form method="POST" action="upload_folder_excel.php" enctype="multipart/form-data" class="form-column">
            <div class="form-item align-items-center">
                <div class="col-sm-8 my-1">
                <label for="uploadzip" class="select">Select ZIP File:</label>
                    <input type="file" class="form-control" name="zip_file" accept=".zip" required>
                </div>
                <div class="col-12 col-sm-4 my-1 d-flex justify-content-center">
                    <button type="submit" class="upload btn btn-primary mt-2 w-100 w-sm-auto" style="margin-top: 10px;">Upload ZIP</button>
                </div>
            </div>
        </form>
        <!-- Delete Form -->
        <form method="POST" onsubmit="return confirm('Are you sure you want to delete all uploaded ZIP files and folders?');" class="form-column mt-3">
            <button type="submit" name="delete_zip_data" class="btn btn-danger">Delete All ZIP Data</button>
        </form>
        <?php if (isset($_SESSION['upload_message'])): ?>
            <div class="alert alert-info"><?= $_SESSION['upload_message'] ?></div>
            <?php unset($_SESSION['upload_message']); ?>
        <?php endif; ?>
    </div>
    
    
    <!-- Excel Uploaded for Solapur Receivable-->
    <p style="text-align: center;">Upload Solapur Receivable Excel</p>
    <div  class="search-container">
        <?= $error ?>
        <?= $message ?>
        <form action="" method="post" enctype="multipart/form-data" class="form-column">
            <div class="form-item">
                <label for="file" class="form-label">Select Excel File:</label>
                <input type="file" name="file" id="file" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Upload File</button>
        </form>
        <form action='delete_all_receivable.php' method='POST' onsubmit="return confirm('Are you sure you want to delete all data?');" class="form-column">
            <button type='submit' name='delete_all' class='btn btn-danger mt-3'>Delete Solapur Receivable</button>
        </form>
    </div>
    <?php if ($message === "success"): ?>
    <script>
        Swal.fire({
            icon: 'success',
            title: '✅  Solapur Data imported successfully!',
            showConfirmButton: false,
            timer: 2500
        });
    </script>
    <?php elseif (!empty($error)): ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: '❌ Upload Failed',
                text: <?= json_encode($error) ?>,
                confirmButtonColor: '#d33'
            });
        </script>
    <?php endif; ?>
    
    
    <!-- Excel Uploaded for Kolhapur Receivable-->
    <p style="text-align: center;">Upload Kolhapur Receivable Excel</p>
    <div  class="search-container">
        <?= $error ?>
        <?= $message ?>
        <form action="" method="post" enctype="multipart/form-data" class="form-column">
            <div class="form-item">
                <label for="file2" class="form-label">Select Excel File:</label>
                <input type="file" name="file2" id="file2" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Upload File</button>
        </form>
        <form action='delete_all_receivable2.php' method='POST' onsubmit="return confirm('Are you sure you want to delete all data?');" class="form-column">
            <button type='submit' name='delete_all' class='btn btn-danger mt-3'>Delete Kolhapur Receivable</button>
        </form>
    </div>
    <?php if (strpos($message, 'successfully') !== false): ?>
    <script>
        Swal.fire({
            icon: 'success',
            title: '✅ Kolhapur Data imported successfully!',
            showConfirmButton: false,
            timer: 2500
        });
    </script>
    <?php elseif (!empty($error)): ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: '❌ Upload Failed',
                html: <?= json_encode($error) ?>,
                confirmButtonColor: '#d33'
            });
        </script>
    <?php endif; ?>
    
    
    <!-- Check Password for Folder page-->
    <script>
        function checkPassword() {
            var password = prompt("Enter Password:");
            if (password !== null) {
                // Send AJAX request to check password
                var xhr = new XMLHttpRequest();
                xhr.open("POST", "upload_password.php", true);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhr.onreadystatechange = function () {
                    if (xhr.readyState == 4 && xhr.status == 200) {
                        if (xhr.responseText == "success") {
                            window.location.href = "folder.php"; // Open folder page
                        } else {
                            alert("Incorrect password! Redirecting back...");
                            history.back();
                        }
                    }
                };
                xhr.send("password=" + encodeURIComponent(password));
            }
        }
        document.addEventListener("keydown", function(event) {
            if (event.key === "Backspace") {
                event.preventDefault(); 
                window.history.back(); 
            }
        });

            // File extension validation
        function validateExcelFile(inputId) {
            const input = document.getElementById(inputId);
            const file = input.files[0];
            const allowedExtensions = /(\.xlsx|\.xls)$/i;

            if (file && !allowedExtensions.exec(file.name)) {
                alert("⚠️ Invalid file format! Please upload only Excel files (.xlsx, .xls).");
                input.value = ''; // reset input
                return false;
            }
            return true;
        }

        // Attach onchange events
        document.getElementById('uploadExcel').addEventListener('change', function () {
            validateExcelFile('uploadExcel');
        });
        document.getElementById('uploadKolhapurExcel').addEventListener('change', function () {
            validateExcelFile('uploadKolhapurExcel');
        });
    </script>
</body>
</html>
