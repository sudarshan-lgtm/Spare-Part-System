<?php
include '../db.php';

$Admin = isset($_POST['Admin']) ? $_POST['Admin'] : '';
$customer = isset($_POST['customer']) ? $_POST['customer'] : '';
$member = isset($_POST['member']) ? $_POST['member'] : '';
$kolhapurMember = isset($_POST['kolhapurMember']) ? $_POST['kolhapurMember'] : '';
$kolhapurCustomer = isset($_POST['kolhapurCustomer']) ? $_POST['kolhapurCustomer'] : '';

$conditions = [];
$params = [];
$types = "";

if (!empty($customer)) {
    $conditions[] = "(customer_fullname = ? AND account_type = 'customer')";
    $params[] = $customer;
    $types .= "s";
}
if (!empty($Admin)) {
    $conditions[] = "(customer_fullname = ? AND account_type = 'Admin')";
    $params[] = $Admin;
    $types .= "s";
}
if (!empty($member)) {
    $conditions[] = "(customer_fullname = ? AND account_type = 'member')";
    $params[] = $member;
    $types .= "s";
}
if (!empty($kolhapurMember)) {
    $conditions[] = "(customer_fullname = ? AND account_type = 'kolhapur_member')";
    $params[] = $kolhapurMember;
    $types .= "s";
}
if (!empty($kolhapurCustomer)) {
    $conditions[] = "(customer_fullname = ? AND account_type = 'kolhapur_customer')";
    $params[] = $kolhapurCustomer;
    $types .= "s";
}

$query = "SELECT id, submit_id, product, customer_fullname, company, partNo, quantity, order_date FROM submitted_orders";

if (!empty($conditions)) {
    $query .= " WHERE " . implode(" OR ", $conditions);
}
// Add ORDER BY clause
$query .= " ORDER BY order_date DESC";
$stmt = $conn->prepare($query);

if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $serialNumber = 1;

    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td><input type='checkbox' class='order-checkbox' value='{$row['id']}'></td>
                <td>{$serialNumber}</td>
                <td>{$row['submit_id']}</td>
                <td>{$row['product']}</td>
                <td>{$row['company']}</td>
                <td>{$row['customer_fullname']}</td>
                <td>{$row['partNo']}</td>
                <td>{$row['quantity']}</td>
                <td>{$row['order_date']}</td>
            </tr>";
            $serialNumber++;
    }
} else {
    echo "<tr><td colspan='6' class='text-center'>No orders found.</td></tr>";
}

$stmt->close();
$conn->close();
?>
