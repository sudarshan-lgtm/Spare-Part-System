<?php
// Include database connection
include '../db.php';

// Get the data from the request
$data = json_decode(file_get_contents("php://input"), true);

if (isset($data['submit_id'])) {
    $submit_id = $data['submit_id'];

    // Delete the order using submit_id
    $query = "DELETE FROM orders WHERE submit_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $submit_id); // assuming submit_id is string, use "i" if it's integer

    if ($stmt->execute()) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false, "error" => $stmt->error]);
    }

    $stmt->close();
} else {
    echo json_encode(["success" => false, "error" => "Invalid request"]);
}

$conn->close();
?>
