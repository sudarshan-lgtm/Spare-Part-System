<?php
include '../db.php';

if (isset($_POST['orderIds']) && is_array($_POST['orderIds'])) {
    // Filter only valid alphanumeric submit_ids (additionally underscore allowed)
    $orderIds = array_filter($_POST['orderIds'], function($id) {
        return preg_match('/^[a-zA-Z0-9_]+$/', $id); // Adjust this pattern if more characters allowed
    });

    if (!empty($orderIds)) {
        // Generate dynamic placeholders for prepared statement
        $placeholders = implode(',', array_fill(0, count($orderIds), '?'));
        $types = str_repeat('s', count($orderIds)); // 's' because submit_id is string

        $stmt = $conn->prepare("DELETE FROM orders WHERE submit_id IN ($placeholders)");
        if ($stmt === false) {
            echo "Error preparing statement: " . $conn->error;
            exit;
        }

        $stmt->bind_param($types, ...$orderIds);

        if ($stmt->execute()) {
            echo "Selected orders deleted successfully.";
        } else {
            echo "Error deleting orders: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Invalid submit IDs provided.";
    }
} else {
    echo "No orders selected.";
}

$conn->close();
?>
