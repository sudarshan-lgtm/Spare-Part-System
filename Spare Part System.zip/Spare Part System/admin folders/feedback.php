<?php
session_start();
include '../db.php'; // Database connection file

if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}
if (isset($_GET['fetch_accounts'])) {
    // Fetch unique account types from the contact table
    $stmt = $conn->prepare("SELECT DISTINCT account_type FROM contact");
    $stmt->execute();
    $result = $stmt->get_result();

    $accountTypes = [];
    while ($row = $result->fetch_assoc()) {
        $accountTypes[] = $row['account_type'];
    }
    
    $result->free();
    $stmt->close();
    echo json_encode($accountTypes);
    exit;
}

if (isset($_GET['type'])) {
    $type = $_GET['type'];

    // Fetch full names based on selected account type
    $stmt = $conn->prepare("SELECT DISTINCT fullname FROM contact WHERE account_type = ?");
    $stmt->bind_param("s", $type);
    $stmt->execute();
    $result = $stmt->get_result();

    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row['fullname'];
    }

    $result->free();
    $stmt->close();
    echo json_encode($data);
    exit;
}

if (isset($_GET['fullname'])) {
    $fullname = $_GET['fullname'];

    // Fetch full details of the selected fullname
    $stmt = $conn->prepare("SELECT fullname, account_type, email, subject, message FROM contact WHERE fullname = ?");
    $stmt->bind_param("s", $fullname);
    $stmt->execute();
    $result = $stmt->get_result();

    $feedbacks = [];
    while ($row = $result->fetch_assoc()) {
        $feedbacks[] = $row;
    }
    
    $result->free();
    $stmt->close();
    echo json_encode($feedbacks);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            color: white;
            text-align: center;
            padding: 20px;
        }
        .back-btn {
            background: linear-gradient(135deg, #ffcc00, #ff9900);
            color: black;
            font-size: 20px;
            font-weight: bold;
            border: none;
            padding: 10px 25px;
            border-radius: 40px;
            cursor: pointer;
            transition: all 0.3s ease-in-out;
            box-shadow: 2px 2px 5px rgba(255, 204, 0, 0.5);
            position: absolute;
            left: 20px; 
            top: 20px;  
        }
        .back-btn:hover {
            background: linear-gradient(135deg, #ff9900, #ff6600);
            transform: scale(1.1);
        }
        .container {
            max-width: 900px;
            margin: auto;
            margin-top: 7%;
            background: rgba(0, 0, 0, 0.8);
            padding: 20px;
            border-radius: 10px;
        }
        h1 {
            color: #ffcc00;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }
        select {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
        }
        .table-container {
            width: 100%;
            overflow-x: auto; /* Data horizontal scroll hoil */
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid white;
        }
        th, td {
            padding: 10px;
            text-align: left;
            white-space: nowrap; /* Columns shrink honar nahi */
        }
        @media screen and (max-width: 768px) {
            table {
                font-size: 14px;
            }
            select {
                font-size: 16px;
            }
        }
    </style>
</head>
<body>
    <?php include("preloader.html"); ?>
<div class="container">
    <h1>Feedback System</h1>

    <label for="account_type">Select Account Type:</label>
    <select id="account_type">
        <option value="">Select Account Type</option>
    </select>

    <label for="fullname">Select Full Name:</label>
    <select id="fullname">
        <option value="">Select Full Name</option>
    </select>

    <h3>Feedback Data:</h3>
    <div class="table-container">
    <table>
        <thead>
            <tr>
                <th>Sr. No</th>
                <th>Full Name</th>
                <th>Account Type</th>
                <th>Email</th>
                <th>Subject</th>
                <th>Message</th>
            </tr>
        </thead>
        <tbody id="feedback_table">
            <tr><td colspan="6">No feedback available</td></tr>
        </tbody>
    </table>
    </div>
</div>

    <script>
    $(document).ready(function() {
        // Fetch and populate account types dynamically
        $.ajax({
            url: 'feedback.php',
            type: 'GET',
            data: { fetch_accounts: 1 },
            dataType: 'json',
            success: function(response) {
                let accountDropdown = $('#account_type');
                accountDropdown.empty().append('<option value="">Select Account Type</option>');
                $.each(response, function(index, value) {
                    accountDropdown.append('<option value="' + value + '">' + value + '</option>');
                });
            }
        });

        // Fetch full names based on selected account type
        $('#account_type').change(function() {
            let accountType = $(this).val();
            let fullnameDropdown = $('#fullname');
            fullnameDropdown.empty().append('<option value="">Select Full Name</option>');

            if (accountType !== "") {
                $.ajax({
                    url: 'feedback.php',
                    type: 'GET',
                    data: { type: accountType },
                    dataType: 'json',
                    success: function(response) {
                        $.each(response, function(index, value) {
                            fullnameDropdown.append('<option value="' + value + '">' + value + '</option>');
                        });
                    }
                });
            }
        });

        // Fetch details based on selected full name
        $('#fullname').change(function() {
            let fullname = $(this).val();
            let feedbackTable = $('#feedback_table');
            feedbackTable.empty();

            if (fullname !== "") {
                $.ajax({
                    url: 'feedback.php',
                    type: 'GET',
                    data: { fullname: fullname },
                    dataType: 'json',
                    success: function(response) {
                        if (response.length === 0) {
                            feedbackTable.append('<tr><td colspan="6">No data available</td></tr>');
                        } else {
                            $.each(response, function(index, row) {
                                feedbackTable.append('<tr><td>' + (index + 1) + '</td><td>' + row.fullname + '</td><td>' + row.account_type + '</td><td>' + row.email + '</td><td>' + row.subject + '</td><td>' + row.message + '</td></tr>');
                            });
                        }
                    }
                });
            }
        });
    });
    </script>

</body>
</html>
