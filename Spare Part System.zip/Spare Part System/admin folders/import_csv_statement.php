<?php
session_start();
require '../vendor/autoload.php'; // Include PHPSpreadsheet

if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}
use PhpOffice\PhpSpreadsheet\IOFactory;

// Database connection
try {
    $pdo = new PDO("mysql:host=127.0.0.1:3306;dbname=u494849712_part", "u494849712_patilnagesh007", "Password@1381");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Function to save customer data to the database
function saveCustomerData($pdo, $statement_id, $user_name, $from_date, $to_date, $opening_balance, $total_amt, $closing_balance, $transactions) {
    if (empty($user_name) || empty($from_date) || empty($to_date)) {
        echo "Skipping customer due to missing required fields: user_name='$user_name', from_date='$from_date', to_date='$to_date'<br>";
        return;
    }

    // Insert into statement_user_name
    $stmt = $pdo->prepare("INSERT INTO statement_user_name (statement_id, user_name, from_date, to_date) VALUES (:statement_id, :user_name, :from_date, :to_date)");
    $stmt->execute([
        ':statement_id' => $statement_id,
        ':user_name' => $user_name,
        ':from_date' => $from_date,
        ':to_date' => $to_date
    ]);
    $stmt->closeCursor();

    // Insert into opening_balance
    $stmt = $pdo->prepare("INSERT INTO opening_balance (statement_id, credit_amt, debit_amt, closer_balance) VALUES (:statement_id, :credit_amt, :debit_amt, :closer_balance)");
    $stmt->execute([
        ':statement_id' => $statement_id,
        ':credit_amt' => $opening_balance['credit_amt'] ?? 0.00,
        ':debit_amt' => $opening_balance['debit_amt'] ?? 0.00,
        ':closer_balance' => $opening_balance['closer_balance']
    ]);
    $stmt->closeCursor();

    // Insert into statement_total_amt
    $stmt = $pdo->prepare("INSERT INTO statement_total_amt (statement_id, credit_amt, debit_amt) VALUES (:statement_id, :credit_amt, :debit_amt)");
    $stmt->execute([
        ':statement_id' => $statement_id,
        ':credit_amt' => $total_amt['credit_amt'] ?? 0.00,
        ':debit_amt' => $total_amt['debit_amt'] ?? 0.00
    ]);
    $stmt->closeCursor();

    // Insert into closing_balance
    $stmt = $pdo->prepare("INSERT INTO closing_balance (statement_id, closing_balance) VALUES (:statement_id, :closing_balance)");
    $stmt->execute([
        ':statement_id' => $statement_id,
        ':closing_balance' => $closing_balance
    ]);
    $stmt->closeCursor();

    // Insert into statement_all_data
    $stmt = $pdo->prepare("INSERT INTO statement_all_data (statement_id, date, doc_no, type, particulars, credit, debit, closing_balance) VALUES (:statement_id, :date, :doc_no, :type, :particulars, :credit, :debit, :closing_balance)");
    foreach ($transactions as $transaction) {
        $stmt->execute([
            ':statement_id' => $statement_id,
            ':date' => $transaction['date'],
            ':doc_no' => $transaction['doc_no'],
            ':type' => $transaction['type'],
            ':particulars' => $transaction['particulars'],
            ':credit' => $transaction['credit'],
            ':debit' => $transaction['debit'],
            ':closing_balance' => $transaction['closing_balance']
        ]);
    }
    $stmt->closeCursor();

    echo "Saved data for customer: $user_name<br>";
}

// File upload handling
if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
    $file = $_FILES['file']['tmp_name'];
    $fileType = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);

    // Check for allowed extensions
    $allowedExtensions = ['csv'];
    if (!in_array(strtolower($fileType), $allowedExtensions)) {
        echo "<script>alert('You have uploaded an incorrect file format! Please upload a CSV file.'); window.history.back();</script>";
        exit();
    }

    // Load file based on type
    if ($fileType == 'csv') {
        $data = array_map('str_getcsv', file($file));
    } elseif ($fileType == 'xlsx' || $fileType == 'xls') {
        $spreadsheet = IOFactory::load($file);
        $data = $spreadsheet->getActiveSheet()->toArray();
    } else {
        die("Unsupported file format. Please upload a CSV or Excel file.");
    }

    // Debugging: Print raw data to inspect
    echo "<pre>Raw Data:\n";
    print_r($data);
    echo "</pre>";

    // Initialize variables for the first customer
    $statement_id = "STMT" . time();
    $user_name = null;
    $from_date = null;
    $to_date = null;
    $opening_balance = [];
    $total_amt = [];
    $closing_balance = null;
    $transactions = [];

    // Process the data
    foreach ($data as $index => $row) {
        if (!is_array($row) || empty($row)) continue;

        // Detect a new customer (start of a new "Account Statement For")
        if (strpos($row[0], "Account Statement For") !== false) {
            // If we already have data for a previous customer, save it before resetting
            if ($user_name !== null) {
                saveCustomerData($pdo, $statement_id, $user_name, $from_date, $to_date, $opening_balance, $total_amt, $closing_balance, $transactions);
                // Generate a new statement_id for the next customer
                $statement_id = "STMT" . time() . rand(100, 999); // Adding rand to avoid duplicates
            }

            // Reset variables for the new customer
            $user_name = $row[0];
            $from_date = null;
            $to_date = null;
            $opening_balance = [];
            $total_amt = [];
            $closing_balance = null;
            $transactions = [];
            continue;
        }

        // Extract from_date and to_date
        if (strpos($row[0], "From ") !== false && strpos($row[0], " To ") !== false) {
            $dateParts = explode(" To ", $row[0]);
            $fromDateStr = str_replace("From ", "", $dateParts[0] ?? '');
            $toDateStr = $dateParts[1] ?? '';

            $from_date_obj = DateTime::createFromFormat('d/m/Y', $fromDateStr);
            if ($from_date_obj === false) {
                $from_date_obj = DateTime::createFromFormat('d-m-Y', $fromDateStr);
            }
            $from_date = $from_date_obj ? $from_date_obj->format('Y-m-d') : null;

            $to_date_obj = DateTime::createFromFormat('d/m/Y', $toDateStr);
            if ($to_date_obj === false) {
                $to_date_obj = DateTime::createFromFormat('d-m-Y', $toDateStr);
            }
            $to_date = $to_date_obj ? $to_date_obj->format('Y-m-d') : null;
            continue;
        }

        // Extract opening balance
        if (strpos($row[0], "Opening Balance") !== false) {
            $opening_balance['credit_amt'] = isset($row[5]) ? floatval(str_replace(',', '', $row[5])) : null;
            $opening_balance['debit_amt'] = isset($row[6]) ? floatval(str_replace(',', '', $row[6])) : null;
            $opening_balance['closer_balance'] = $row[7] ?? null;
            continue;
        }

        // Extract transactions (support DD/MM/YYYY and DD-MM-YYYY)
        if (preg_match('/^\d{2}[\/-]\d{2}[\/-]\d{4}$/', $row[0])) {
            $date_obj = DateTime::createFromFormat('d/m/Y', $row[0]);
            if ($date_obj === false) {
                $date_obj = DateTime::createFromFormat('d-m-Y', $row[0]);
            }
            $parsed_date = $date_obj ? $date_obj->format('Y-m-d') : null;
            echo "Transaction Date Raw: " . $row[0] . " | Parsed: " . $parsed_date . "<br>";

            if ($parsed_date === null) {
                die("Error: Could not parse transaction date '$row[0]' for customer '$user_name'");
            }

            $transactions[] = [
                'date' => $parsed_date,
                'doc_no' => $row[1] ?? null,
                'type' => $row[2] ?? null,
                'particulars' => implode(", ", array_filter([$row[3] ?? '', $row[4] ?? ''])),
                'credit' => isset($row[5]) && !empty($row[5]) ? floatval(str_replace(',', '', $row[5])) : null,
                'debit' => isset($row[6]) && !empty($row[6]) ? floatval(str_replace(',', '', $row[6])) : null,
                'closing_balance' => $row[7] ?? null
            ];
            continue;
        }

        // Extract total amounts
        if (strpos($row[0], "Total") !== false) {
            $total_amt['credit_amt'] = isset($row[5]) ? floatval(str_replace(',', '', $row[5])) : null;
            $total_amt['debit_amt'] = isset($row[6]) ? floatval(str_replace(',', '', $row[6])) : null;
            continue;
        }

        // Extract closing balance
        if (strpos($row[0], "Closing Balance") !== false) {
            $closing_balance = $row[7] ?? null;
            continue;
        }
    }

    // Save the last customer's data
    if ($user_name !== null) {
        saveCustomerData($pdo, $statement_id, $user_name, $from_date, $to_date, $opening_balance, $total_amt, $closing_balance, $transactions);
    }

    ?>
    <script>
        alert("Data imported successfully for all customers!");
        window.location.href = "display_imported_statement.php";
    </script>
    <?php
} else {
    echo "";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Import Statement Data</title>
    <link rel="icon" href="../image/icon.png" type="image/png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #EEF2FE;
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            color: white;
            border-radius: 50%;
            text-decoration: none;
            font-size: 22px;
            transition: all 0.3s ease;
            position: fixed; /* Optional: fixed position */
            top: 10px;
            left: 20px;
            z-index: 999;
        }
        .back-button:hover {
            transform: scale(1.1);
            color: #fff;
        }
        .back-button .home {
            height: 55px; 
            width: auto;  
            margin-right: 10px; 
            vertical-align: middle;
            object-fit: contain;
        }
    </style>
</head>
<body>
    <?php include("preloader.html"); ?>
<a href='admin_dashboard.php'  class='back-button'><img src="../image/h1.png" class="home" alt="ok"></a>
<!-- Upload & Delete Container -->
<div class="container my-0">
    <div class="card shadow-lg rounded-4 border-0" style="background-color: #fff;">
        <div class="card-body p-4">
            <h4 class="card-title text-center mb-4 text-primary">Ledger Management</h4>

            <div class="row g-4 justify-content-center">
                <!-- File Upload Form -->
                <div class="col-md-6">
                    <form method="post" enctype="multipart/form-data" class="d-grid gap-3">
                        <div>
                            <label for="file" class="form-label fw-semibold">Import Solapur Ledger (CSV):</label>
                            <input type="file" name="file" accept=".csv, .xlsx, .xls" required class="form-control shadow-sm">
                        </div>
                        <div class="d-grid gap-2">
                            <input type="submit" value="Import" class="btn btn-primary">
                            <a href="display_imported_statement.php" class="btn btn-success">Last Solapur Imported Ledger</a>
                        </div>
                    </form>
                </div>

                <!-- Delete All Ledger Data Form -->
                <div class="col-md-4">
                    <form method="POST" action="delete_all_ledger_data.php" class="w-100 mt-5"
                        onsubmit="return confirm('Are you sure you want to delete ALL ledger data? This action cannot be undone.');">
                        <button type="submit" class="btn btn-danger w-100">Delete Solapur Ledger</button>
                    </form>
                    
                        <a  href="import_csv_statement2.php" class="btn btn-outline-primary w-100 mt-2 fw-bold shadow-sm">Import Kolhapur Ledger</a>

                    <form method="POST" action="delete_all_ledger_data2.php" class="w-100 mt-2"
                        onsubmit="return confirm('Are you sure you want to delete ALL ledger data? This action cannot be undone.');">
                        <button type="submit" class="btn btn-outline-danger w-100">Delete Kolhapur Ledger</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
    <?php
    include 'display_imported_all_statemets.php';
    ?>
</body>
</html>
