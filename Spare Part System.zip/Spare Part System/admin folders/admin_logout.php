<?php
session_start();
require_once("../db.php");

// Destroy session
session_unset();
session_destroy();
setcookie(session_name(), "", time() - 3600, "/"); // Expire session cookie

// Prevent back button after logout
echo "<script>
    history.pushState(null, null, location.href);
    window.onpopstate = function () {
        history.go(1);
    };
    window.location.href = 'admin_login.php';
</script>";
exit();
?>
