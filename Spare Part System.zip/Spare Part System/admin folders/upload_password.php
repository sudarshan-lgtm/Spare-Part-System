<?php
session_start();

$correctPassword = "admin123"; // Set your secure password here

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $enteredPassword = $_POST["password"] ?? '';

    if ($enteredPassword === $correctPassword) {
        $_SESSION["authenticated"] = true;
        echo "success"; // Send success response
    } else {
        echo "failed"; // Send failure response
    }
}
?>
