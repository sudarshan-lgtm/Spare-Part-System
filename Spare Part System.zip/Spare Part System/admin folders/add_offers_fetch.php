<?php
include '../db.php'; // Include database connection

// Fetch product suggestions for dropdown search
if (isset($_GET['q'])) {
    $searchTerm = trim($_GET['q']);
    $searchLike = "%" . $searchTerm . "%";

    $query = "
        SELECT DISTINCT Product FROM productinventory WHERE Product LIKE ? 
        UNION 
        SELECT DISTINCT Product FROM kolhapurdata WHERE Product LIKE ? 
        LIMIT 10";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $searchLike, $searchLike);
    $stmt->execute();
    $result = $stmt->get_result();

    $products = [];
    while ($row = $result->fetch_assoc()) {
        $products[] = ["id" => $row['Product'], "text" => $row['Product']];
    }

    $result->free(); // Free the result set
    $stmt->close();
    
    echo json_encode($products);
    exit;
}

// Fetch existing offers **for the specific module only**
if (isset($_GET['module'])) {
    $module = trim($_GET['module']);
    $query = "SELECT * FROM Offers WHERE Module = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $module);
    $stmt->execute();
    $result = $stmt->get_result();

    $offers = [];
    while ($row = $result->fetch_assoc()) {
        $offers[] = [
            "id" => $row['id'],
            "product" => $row['Product'],
            "discount" => $row['Discount'],
            "module" => $row['Module']
        ];
    }

    $result->free(); // Free the result set
    $stmt->close();
    
    echo json_encode($offers);
    exit;
}
?>
