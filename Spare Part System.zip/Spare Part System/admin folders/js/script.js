window.onload = async () => {
    const partContainer = document.getElementById('partContainer');

    const response = await fetch('fetch_parts.php');
    const parts = await response.json();

    parts.forEach(part => {
        const card = document.createElement('div');
        card.classList.add('part-card');
        card.innerHTML = `
            <img src="${part.image_path}" alt="${part.name}">
            <h4>${part.name}</h4>
            <p>${part.description}</p>
            <button onclick="orderPart('${part.id}')">Order</button>
        `;
        partContainer.appendChild(card);
    });
};

function orderPart(partId) {
    // Redirect to order page or send partId to the server
    window.location.href = `order.php?id=${partId}`;
}
