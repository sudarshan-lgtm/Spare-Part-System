//keyboard Shortcut Key
let typedKeys = "";

// Check if logout was triggered before refresh
if (sessionStorage.getItem("loggedOut") === "true") {
    sessionStorage.removeItem("loggedOut"); // Remove flag to prevent repeat logout
} else {
    document.addEventListener("keydown", function (event) {
        // Skip checking if user is typing inside an input or textarea
        if (document.activeElement.tagName === "INPUT" || document.activeElement.tagName === "TEXTAREA") {
            return;
        }

        typedKeys += event.key.toLowerCase();

        if (typedKeys.includes("sushrut")) {
            alert("Logging out...");
            sessionStorage.setItem("loggedOut", "true"); // Set flag to prevent repeat logout after refresh
            window.location.href = "admin_logout.php"; // Redirect to logout
        }

        if (typedKeys.length > 7) {
            typedKeys = typedKeys.slice(-7);
        }
    });
}

document.addEventListener("keydown", function (event) {
    // Check if user pressed "LD" (L + D in sequence)
    if (event.key.toLowerCase() === "l") {
        document.addEventListener("keydown", function checkL(e) {
            if (e.key.toLowerCase() === "d") {
                window.location.href = "ledger_display.php"; // Change URL as per your project
            }
            document.removeEventListener("keydown", checkL);
        });
    }
});

document.addEventListener("keydown", function (event) {
    // Check if user pressed "os" (O + S in sequence)
    if (event.key.toLowerCase() === "o") {
        document.addEventListener("keydown", function checkO(e) {
            if (e.key.toLowerCase() === "s") {
                window.location.href = "order.php"; // Change URL as per your project
            }
            document.removeEventListener("keydown", checkO);
        });
    }
});

document.addEventListener("keydown", function (event) {
    // Check if user pressed "Pg" (P + G in sequence)
    if (event.key.toLowerCase() === "p") {
        document.addEventListener("keydown", function checkG(e) {
            if (e.key.toLowerCase() === "g") {
                window.location.href = "display_product_group.php"; // Change URL as per your project
            }
            document.removeEventListener("keydown", checkG);
        });
    }
});

document.addEventListener("keydown", function (event) {
    // Check if user pressed "up" (U + P in sequence)
    if (event.key.toLowerCase() === "u") {
        document.addEventListener("keydown", function checkU(e) {
            if (e.key.toLowerCase() === "p") {
                window.location.href = "upload_folder_excel.php"; // Change URL as per your project
            }
            document.removeEventListener("keydown", checkU);
        });
    }
});

document.addEventListener("keydown", function (event) {
    // Check if user pressed "co" (C + O in sequence)
    if (event.key.toLowerCase() === "c") {
        document.addEventListener("keydown", function checkC(e) {
            if (e.key.toLowerCase() === "o") {
                window.location.href = "company/company.php"; // Change URL as per your project
            }
            document.removeEventListener("keydown", checkC);
        });
    }
});

document.addEventListener("keydown", function (event) {
    // Check if user pressed "vf" (V + F in sequence)
    if (event.key.toLowerCase() === "v") {
        document.addEventListener("keydown", function checkV(e) {
            if (e.key.toLowerCase() === "f") {
                window.location.href = "cust_mem_hide.php"; // Change URL as per your project
            }
            document.removeEventListener("keydown", checkV);
        });
    }
});

document.addEventListener("keydown", function (event) {
    // Check if user pressed "do" (D + O in sequence)
    if (event.key.toLowerCase() === "d") {
        document.addEventListener("keydown", function checkD(e) {
            if (e.key.toLowerCase() === "o") {
                window.location.href = "download.php"; // Change URL as per your project
            }
            document.removeEventListener("keydown", checkD);
        });
    }
});

document.addEventListener("keydown", function (event) {
    // Check if user pressed "ao" (A + O in sequence)
    if (event.key.toLowerCase() === "a") {
        document.addEventListener("keydown", function checkA(e) {
            if (e.key.toLowerCase() === "o") {
                window.location.href = "add_offers.php"; // Change URL as per your project
            }
            document.removeEventListener("keydown", checkA);
        });
    }
});

document.addEventListener("keydown", function (event) {
    // Check if user pressed "ac" (A + C in sequence)
    if (event.key.toLowerCase() === "a") {
        document.addEventListener("keydown", function checkA(e) {
            if (e.key.toLowerCase() === "c") {
                window.location.href = "account.php"; // Change URL as per your project
            }
            document.removeEventListener("keydown", checkA);
        });
    }
});

document.addEventListener("keydown", function (event) {
    // Check if user pressed "so" (S + O in sequence)
    if (event.key.toLowerCase() === "s") {
        document.addEventListener("keydown", function checkS(e) {
            if (e.key.toLowerCase() === "o") {
                window.location.href = "orders_submit.php"; // Change URL as per your project
            }
            document.removeEventListener("keydown", checkS);
        });
    }
});

document.addEventListener("keydown", function (event) {
    // Check if user pressed "CU" (C + U in sequence)
    if (event.key.toLowerCase() === "c") {
        document.addEventListener("keydown", function checkC(e) {
            if (e.key.toLowerCase() === "u") {
                window.location.href = "contact.php"; // Change URL as per your project
            }
            document.removeEventListener("keydown", checkC);
        });
    }
});

//Keyboard Shortcut Key display Pop UP Page
let typedSequence = "";

document.addEventListener("keydown", function (event) {
    // Skip checking if user is typing inside an input or textarea
    if (document.activeElement.tagName === "INPUT" || document.activeElement.tagName === "TEXTAREA") {
        return;
    }

    typedSequence += event.key;

    if (typedSequence.includes("1216")) {
        openShortcutPopup();
        typedSequence = ""; // Reset sequence after triggering
    }

    if (typedSequence.length > 4) {
        typedSequence = typedSequence.slice(-4);
    }
});

function openShortcutPopup() {
    const popupHtml = `
        <div id="shortcutPopup" class="popup-overlay">
            <div class="popup-content">
                <h2>🔑 Shortcut Keys List</h2>
                <ul>
                    <li><strong>"sushrut"</strong> → Logout</li>
                    <li><strong>"Ctrl + S"</strong> → Focus on Product Search</li>
                    <li><strong>"Shift + S"</strong> → Focus on Part Number Search</li>
                    <li><strong>"Backspace"</strong> → Go Back (except in input fields)</li>
                    <li><strong>"1216"</strong> → Open this Shortcut Popup</li>
                    <li><strong>"p + g"</strong> → Open Product Group's Page</li>
                    <li><strong>"u + p"</strong> → Open Upload Page</li>
                    <li><strong>"c + o"</strong> → Open Company Page</li>
                    <li><strong>"l + d"</strong> → Open Ledger Page</li>
                    <li><strong>"o + s"</strong> → Open Order And Stock Page</li>
                    <li><strong>"v + f"</strong> → Open Visibility Functions Page</li>
                    <li><strong>"d + o"</strong> → Open Download Page</li>
                    <li><strong>"a + o"</strong> → Open Add Offers Page</li>
                    <li><strong>"a + c"</strong> → Open Account Page</li>
                    <li><strong>"s + o"</strong> → Open Submited Orders Page</li>
                </ul>
                <button onclick="closeShortcutPopup()">Close</button>
            </div>
        </div>
    `;

    const popupContainer = document.createElement("div");
    popupContainer.innerHTML = popupHtml;
    document.body.appendChild(popupContainer);
}

function closeShortcutPopup() {
    document.getElementById("shortcutPopup").remove();
}