function toggleSelectAll() {
    const selectAllCheckbox = document.getElementById('select-product');
    const productCheckboxes = document.querySelectorAll('.product-checkbox');
    productCheckboxes.forEach(checkbox => { 
    checkbox.checked = selectAllCheckbox.checked;
    });
}

function submitForm() {
    const selectedCheckboxes = document.querySelectorAll('.product-checkbox:checked');
    if (selectedCheckboxes.length === 0) {
        alert('Select At Least One Product!');
        return false;
    }                    
    document.getElementById('orderForm').submit();
}
// Select all delete buttons
document.addEventListener('DOMContentLoaded', () => {
    // Select all delete buttons
    document.querySelectorAll('.delete-btn').forEach(button => {
        button.addEventListener('click', function (event) {
            event.preventDefault(); // Prevent form submission or page reload
            const id = this.getAttribute('data-id'); // Get product ID
            const cartItem = this.closest('.cart-card'); // Get the closest cart item card

            // Send delete request to the server
            fetch('cart_remove.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ id: id }) // Send product ID
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    cartItem.remove(); // Remove the entire cart item card
                    alert('Product removed from cart successfully!');
                } else {
                    alert('Failed to remove product from cart!');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while removing the product.');
            });
        });
    });
});
// Function to toggle scroll up and down
function toggleScroll() {
    if (window.innerHeight + window.scrollY >= document.body.offsetHeight) {
        // If at bottom, scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
        // If at top, scroll to bottom
        window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
    }
}

// Change arrow image on scroll
window.addEventListener('scroll', function () {
    let arrowImg = document.getElementById('arrow-img');

    if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 10) {
        arrowImg.src = '../image/logo/up-arrow.png'; // Show Up Arrow when at bottom
    } else {
        arrowImg.src = '../image/logo/down-arrow.png'; // Show Down Arrow when at top
    }
});