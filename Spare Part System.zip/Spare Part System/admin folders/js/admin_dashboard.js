// Cart alert JS
function openCart() {
    alert("Cart functionality will be implemented here!");
}

//Side bar JS
function toggleSidebar() {
    const sidebar = document.getElementById("sidebar");
    const overlay = document.getElementById("overlay");

    // Toggle the 'open' class on the sidebar
    sidebar.classList.toggle("open");

    // Show or hide the overlay based on sidebar state
    if (sidebar.classList.contains("open")) {
        overlay.classList.add("active");
    } else {
        overlay.classList.remove("active");
    }
}

//Graph Backend JS
document.addEventListener("DOMContentLoaded", () => {
    // Fetch order data from the backend
    fetch('graph_fetch_order.php') // Replace with your PHP file's path
        .then(response => response.json())
        .then(data => {
            const ctx = document.getElementById('orderChart').getContext('2d');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: ['Last Week', 'Today', 'This Week', 'This Month', 'This Six Month', 'This Year', 'Last Year'],
                    datasets: [{
                        label: 'Number of Orders',
                        data: [
                            data.lastWeekOrders,
                            data.todayOrders,
                            data.thisWeekOrders,
                            data.thisMonthOrders,
                            data.thisSixMonthOrders,
                            data.thisYear,
                            data.lastYear
                        ],
                        backgroundColor: [
                            'rgba(75, 192, 192, 0.2)', // Today
                            'rgba(153, 102, 255, 0.2)', // This Week
                            'rgba(255, 159, 64, 0.2)', // Last Week
                            'rgba(54, 162, 235, 0.2)',  // This Month
                            'rgba(201, 203, 207, 0.2)', // Last 6 Months
                            'rgba(255, 205, 86, 0.2)', // This Year
                            'rgba(255, 99, 132, 0.2)'  // Last Year
                        ],
                        borderColor: [
                            'rgba(75, 192, 192, 1)', // Today
                            'rgba(153, 102, 255, 1)', // This Week
                            'rgba(255, 159, 64, 1)', // Last Week
                            'rgba(54, 162, 235, 1)',  // This Month
                            'rgba(201, 203, 207, 1)', // Last 6 Months
                            'rgba(255, 205, 86, 1)', // This Year
                            'rgba(255, 99, 132, 1)'  // Last Year
                        ],
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            display: true,
                            position: 'top',
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        })
        .catch(error => console.error('Error fetching data:', error));
});

//Share option JS
document.querySelector('.btn-outline-secondary').addEventListener('click', function() {
    document.querySelector('.share-options').style.display = 'block';
});


//Notification Button JS
document.getElementById("notification-btn").addEventListener("click", function() {
window.location.href = "../admin folders/notification.php";
});

function updateNotificationCount() {
    $.ajax({
        url: '../admin folders/notification_count.php',
        method: 'GET',
        success: function(count) {
            if (count > 0) {
                $("#notification-count").text(count).show();
            } else {
                $("#notification-count").hide();
            }
        }
    });
}
setInterval(updateNotificationCount, 2000);
updateNotificationCount();

//Show Current Time and Date
document.addEventListener("DOMContentLoaded", function () {
    let is24HourFormat = true;

    function updateDateTime() {
        const now = new Date();

        // Set options to show Indian date/time
        const dateOptions = {
            timeZone: "Asia/Kolkata", // India time zone
            year: 'numeric',
            month: 'long',
            day: 'numeric',
        };
        const timeOptions24 = {
            timeZone: "Asia/Kolkata",
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false
        };
        const timeOptions12 = {
            timeZone: "Asia/Kolkata",
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: true
        };

        const date = new Intl.DateTimeFormat('en-IN', dateOptions).format(now);
        const time = new Intl.DateTimeFormat('en-IN', is24HourFormat ? timeOptions24 : timeOptions12).format(now);

        document.getElementById('currentDateTime').innerHTML = `${date}, ${time}`;
    }

    updateDateTime();
    setInterval(updateDateTime, 1000);

    document.getElementById('toggleTimeFormat').addEventListener('click', function () {
        is24HourFormat = !is24HourFormat;
        const formatText = is24HourFormat ? "Switch to 12-Hour" : "Switch to 24-Hour";
        this.textContent = formatText;
        updateDateTime();
    });
});