<?php
include '../db.php'; // Database connection

if (isset($_POST['id'], $_POST['column'], $_POST['value'])) {
    $submit_id = $_POST['id']; // this is actually submit_id
    $column = $_POST['column'];
    $value = $_POST['value'];

    // Use submit_id instead of id
    $stmt = $conn->prepare("UPDATE orders SET `$column` = ? WHERE submit_id = ?");
    $stmt->bind_param("ss", $value, $submit_id); // submit_id is string type

    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "error";
    }

    $stmt->close();
    $conn->close();
}
?>
