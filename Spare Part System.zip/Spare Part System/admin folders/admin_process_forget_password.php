<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer-master/src/PHPMailer.php';
require '../PHPMailer-master/src/SMTP.php';
require '../PHPMailer-master/src/Exception.php';
require '../db.php'; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve the user's email from the form
    $email = mysqli_real_escape_string($conn, $_POST['email']);

    // Check if email exists in the database
    $query = "SELECT * FROM users WHERE email='$email'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        // Generate a unique reset token
        $token = bin2hex(random_bytes(32));
        $resetLink = "https://rjautoheaven.com/admin%20folders/reset_password.php?token=$token";

        // Save the token in the database
        $updateQuery = "UPDATE users SET reset_token='$token', token_expiry=DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE email='$email'";
        if (mysqli_query($conn, $updateQuery)) {
            // Send the reset email
            $mail = new PHPMailer(true);
            try {
                // Server settings
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com';
                $mail->SMTPAuth   = true;
                $mail->Username   = 'sudarshan12shinde@gmail.com';
                $mail->Password   = 'tigh optn beym jrta'; // Use an app-specific password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = 587;

                // Recipients
                $mail->setFrom('sudarshan12shinde@gmail.com', 'Spare Parts Website');
                $mail->addAddress($email);

                // Content
                $mail->isHTML(true);
                $mail->Subject = 'Password Reset Request';
                $mail->Body    = "Click the link below to reset your password:<br><a href='$resetLink'>$resetLink</a><br>This link will expire in 1 hour.";

                $mail->send();
                echo "<script>alert('A password reset link has been sent to your email.');window.location='admin_forget_password.php';</script>";
            } catch (Exception $e) {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
        } else {
            echo "Failed to set reset token. Please try again.";
        }
    } else {
        echo "No account found with that email address.";
    }
} else {
    "<script>alert('Email not found!');window.location='admin_forget_password.php';</script>";
}
?>
