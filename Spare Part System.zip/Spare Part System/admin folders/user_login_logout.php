<?php
require_once("../db.php");

$sql = "SELECT user_id, fullname, login_time, logout_time FROM user_logs ORDER BY id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>User Login Logs</title>
</head>
<body class="bg-light">
<div class="container mt-5">
    <h2 class="text-center mb-4">Login & Logout Logs</h2>
    <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover text-center shadow-sm">
            <thead class="table-dark">
                <tr>
                    <th>Full Name</th>
                    <th>Login Time</th>
                    <th>Logout Time</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td class="fw-bold"><?php echo htmlspecialchars($row['fullname']); ?></td>
                        <td class="text-success"><?php echo $row['login_time']; ?></td>
                        <td class="<?php echo ($row['logout_time']) ? 'text-danger' : 'text-primary fw-bold'; ?>">
                            <?php echo $row['logout_time'] ?? 'Still Logged In'; ?>
                        </td>
                        <td>
                            <?php if (!$row['logout_time']) { ?>
                                <form action="admin_logout.php" method="POST">
                                    <input type="hidden" name="user_id" value="<?php echo $row['user_id']; ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">Logout</button>
                                </form>
                            <?php } else { ?>
                                <span class="badge bg-secondary">Logged Out</span>
                            <?php } ?>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>
<!-- Bootstrap JS (Optional for interactive components) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php $conn->close(); ?>
