<?php
include '../db.php'; // Database connection

// Count orders where is_seen = 0 (new orders)
$query = "SELECT COUNT(*) AS new_orders FROM orders WHERE is_seen = 0";
$result = $conn->query($query);
$row = $result->fetch_assoc();
echo $row['new_orders']; // Return new orders count
$conn->close();
?>
