<?php
session_start();
include '../db.php';

if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}

// Set the timezone to your local timezone (e.g., IST)
date_default_timezone_set("Asia/Kolkata"); // Adjust this to your timezone

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['orderIds']) && is_array($_POST['orderIds'])) {
        $orderIds = $_POST['orderIds'];
        // Escape and quote each submit_id since it's a string
        $idsString = implode(",", array_map(function($id) use ($conn) {
            return "'" . $conn->real_escape_string($id) . "'";
        }, $orderIds));

        // Get current date and time in MySQL datetime format
        $currentDateTime = date("Y-m-d H:i:s"); // e.g., 2025-04-08 11:00:13
        
        // Start transaction
        $conn->begin_transaction();

        try {
            // Insert into submitted_orders
            $insertQuery = "INSERT INTO submitted_orders (submit_id, customer_id, customer_fullname, fullname, account_type, product, batch, company, partNo, purchaseRate, gst, exp, margin, totalSaleRate, enterSaleRate, updatedSaleRate, closingQty, location, quantity, feedback, order_date, submit_order_date) 
                            SELECT submit_id, customer_id, customer_fullname, fullname, account_type, product, batch, company, partNo, purchaseRate, gst, exp, margin, totalSaleRate, enterSaleRate, updatedSaleRate, closingQty, location, quantity, feedback, created_at, '$currentDateTime'
                            FROM orders WHERE submit_id IN ($idsString)";
            $conn->query($insertQuery);

            $conn->query("DELETE FROM orders WHERE submit_id IN ($idsString)");
            $conn->query("DELETE FROM customer_orders WHERE submit_id IN ($idsString)");
            $conn->query("DELETE FROM member_orders WHERE submit_id IN ($idsString)");
            $conn->query("DELETE FROM kolhapur_orders WHERE submit_id IN ($idsString)");
            $conn->query("DELETE FROM k_member_orders WHERE submit_id IN ($idsString)");
            
            // Commit the transaction
            $conn->commit();

            echo json_encode(["success" => true]);
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(["success" => false, "error" => $e->getMessage()]);
        }
    } else {
        echo json_encode(["success" => false, "error" => "Invalid order selection"]);
    }
    exit; // Ensure no further output
}

// Function to generate dropdown options dynamically
function getDropdownOptions($conn, $accountType) {
    $query = "SELECT DISTINCT customer_fullname FROM submitted_orders WHERE account_type = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $accountType);
    $stmt->execute();
    $result = $stmt->get_result();
    $options = "<option value=''>Select " . ucfirst(str_replace('_', ' ', $accountType)) . "</option>";
    while ($row = $result->fetch_assoc()) {
        $options .= "<option value='" . htmlspecialchars($row['customer_fullname']) . "'>" . htmlspecialchars($row['customer_fullname']) . "</option>";
    }
    $result->free(); // Free the result set
    $stmt->close();
    return $options;
}

//Search Customer_fullname 
$search_customer = isset($_GET['search_customer']) ? trim($_GET['search_customer']) : '';

if (!empty($search_customer)) {
    $stmt = $conn->prepare("SELECT * FROM submitted_orders WHERE customer_fullname LIKE ? ORDER BY order_date DESC");
    $likeSearch = "%{$search_customer}%";
    $stmt->bind_param("s", $likeSearch);
} else {
    $stmt = $conn->prepare("SELECT * FROM submitted_orders ORDER BY order_date DESC");
}

$stmt->execute();
$result = $stmt->get_result();
$stmt->close(); // Close the prepared statement
$result->free();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submitted Orders</title>
    <link rel="icon" href="../image/icon.png" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> <!-- jQuery for AJAX -->
    <style>
        body {
            background-color: #EEF2FE; /* Light teal */
        }
        .print-btn {
            color: #fff;
            background-color: #17a2b8; 
            border-color: #17a2b8; 
            font-size: 14px;
            padding: 6px 12px;
            border-radius: 5px;
            transition: all 0.3s ease-in-out;
        }
        .print-btn:hover {
            background-color: #138496; 
            border-color: #117a8b; 
            cursor: pointer;
        }
        .print-btn:active {
            background-color: #117a8b; 
            border-color: #0e5f6b; 
        }
        .print-btn:focus {
            box-shadow: 0 0 0 0.2rem rgba(23, 162, 184, 0.5); 
        }
        /* Print Styles */
        @media print {
            body * {
                visibility: hidden;
            }
            .printable-content, .printable-content * {
                visibility: visible;
            }
            .printable-content {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
            }
        }
        /* Make the table responsive */
        .table-responsive {
            overflow-x: auto; /* Horizontal scroll enabled */
            overflow-y: auto; /* Vertical scroll enabled */
            width: 100%;
            max-height: 80vh; /* Limits table height to 80% of viewport */
        }

        /* General Table Styling */
        .table {
            border-collapse: collapse;
            width: 100%;
            background-color: #fff;
            table-layout: auto; /* Dynamic column sizing */
        }

        /* Table Header & Data Cell Styling */
        .table th, .table td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
            vertical-align: middle;
            white-space: nowrap; /* Prevent text wrapping */
        }

        /* Set specific column widths */
        .table th, .table td {
            min-width: 100px; /* Ensures proper spacing */
        }

        /* Feedback Column - Allows Scroll */
        .table td:nth-child(15) {
            min-width: 250px;
            max-width: 300px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .table td:nth-child(15):hover {
            white-space: normal;
            overflow: auto;
            max-height: 100px;
            word-wrap: break-word;
        }

        /* Table header background color */
        .table th {
            background-color: #007bff;
            color: white;
        }

        /* Alternate row colors */
        .table tbody tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        /* Set row height */
        .table td {
            height: 50px;
        }

        /* Responsive adjustments */
        @media screen and (max-width: 1024px) {
            .table th, .table td {
                padding: 8px;
                font-size: 14px;
            }
        }

        /* Mobile & Small Tablets */
        @media screen and (max-width: 768px) {
            .table th, .table td {
                padding: 6px;
                font-size: 12px;
            }
            .table td:nth-child(15) {
                min-width: 150px;
                max-width: 200px;
            }
        }

        /* Smartphones in Portrait Mode */
        @media screen and (max-width: 576px) {
            .row {
                margin-bottom: 7% !important;
            }
            .print-btn {
                padding: 7px;
                position: fixed;
                top: 44% !important;
                left: 70%;
            }
            .table th, .table td {
                padding: 5px;
                font-size: 11px;
            }
            .table td {
                height: 40px;
            }
        }

        /* Landscape Mode for Smartphones & Tablets */
        @media screen and (max-width: 768px) and (orientation: landscape) {
            .table-responsive {
                overflow-x: auto;
                overflow-y: auto;
                max-height: 90vh; /* Adjust height for landscape */
            }

            .table th, .table td {
                padding: 7px;
                font-size: 13px;
            }
            .table td {
                height: 45px;
            }
        }
    </style>
</head>
<body>
    <?php include("preloader.html"); ?>
<div class="container mt-4">
    <h2 class="text-center">Submitted Orders</h2>
    <!-- Dropdown Filters -->
    <div class="row mb-3">
        <div class="col-md-2">
            <select id="AdminFilter" class="form-select">
                <?php echo getDropdownOptions($conn, 'Admin'); ?>
            </select>
        </div>
        <div class="col-md-2">
            <select id="customerFilter" class="form-select">
                <?php echo getDropdownOptions($conn, 'customer'); ?>
            </select>
        </div>
        <div class="col-md-2">
            <select id="memberFilter" class="form-select">
                <?php echo getDropdownOptions($conn, 'member'); ?>
            </select>
        </div>
        <div class="col-md-3">
            <select id="solapurFilter" class="form-select">
                <?php echo getDropdownOptions($conn, 'kolhapur_member'); ?>
            </select>
        </div>
        <div class="col-md-3">
            <select id="kolhapurFilter" class="form-select">
                <?php echo getDropdownOptions($conn, 'kolhapur_customer'); ?>
            </select>
        </div>
    </div>
    <!-- Selected Fullname and Account Type Display -->
    <div id="selectedInfo" class="alert alert-info text-center" style="display: none;">
        <strong>Fullname:</strong> <span id="selectedFullname" style="margin-right:40px;"></span>  <strong>Account Type:</strong><span id="selectedAccountType"></span>
    </div>
        <!-- Search bar under buttons with proper width and height -->
        <div class="row" style="margin-bottom: -30px;">
        <div class="col-md-4 offset-md-4 mt-1">
            <input type="text" id="searchCustomer" class="form-control form-control-lg" 
                placeholder="🔍 Search by Customer FullName" 
                style="height: 45px; font-size: 16px;">
        </div>
        <div id="totalOrders" class="offset-md-0 fw-bold" style="margin-right: 20%;  margin-top: 10px; margin-bottom: -40px;"></div>
    </div>
    <a href="javascript:history.back()" class="btn btn-primary" style="float: left; margin-bottom: 20px; margin-right: 20px; position:relative; margin-top: 10px;"><i class="fas fa-arrow-left"></i> Back</a>
    <button class="btn btn-primary print-btn"  style="float: left; margin-bottom: 20px; margin-right: 20px; margin-top: 10px;" onclick="printTableData()">
        <i class="fas fa-print"></i> Print</button>
    <button id="deleteSelected" class="btn btn-danger" style="float: left; margin-bottom: 20px; margin-right: 20px; position:relative; margin-top: 10px;"><i class="fas fa-trash"></i> Delete Orders</button>

<div class="table-responsive" id="table-responsive">
    <table class="table table-bordered" id="ordersTable">
        <thead>
            <tr>
                <th><input type="checkbox" id="selectAll"></th>
                <th>Sr. No</th>
                <th>Order No</th>
                <th>Product Name</th>
                <th>Company</th>
                <th>Customer FullName</th>
                <th>Part No</th>
                <th>Quantity</th>
                <th>Order Date</th>
            </tr>
        </thead>
        <tbody id="orderTableBody">
            <?php include 'orders_fetch_submitted.php'; ?>
        </tbody>
    </table>
        
</div>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    $(document).ready(function() {
        function fetchOrders() {
            var filters = {
                Admin: $("#AdminFilter").val(),
                customer: $("#customerFilter").val(),
                member: $("#memberFilter").val(),
                kolhapurMember: $("#solapurFilter").val(),
                kolhapurCustomer: $("#kolhapurFilter").val()
            };

            
            // Fetch orders based on selected filters
            $.post("orders_fetch_submitted.php", filters, function(response) {
                $("#table-responsive tbody").html(response);
            });
        

            $("#selectedFullname").text(Object.values(filters).find(val => val) || '');
            $("#selectedAccountType").text(Object.keys(filters).find(key => filters[key]) || '');
            $("#selectedInfo").toggle(!!Object.values(filters).find(val => val));
        }

        $("select").change(fetchOrders);
        fetchOrders();
    });
</script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        // Select All Checkbox Functionality
        $("#selectAll").click(function() {
            $(".order-checkbox").prop("checked", this.checked);
        });
        // Delete Selected Orders
        $("#deleteSelected").click(function() {
            let selectedOrders = [];
            $(".order-checkbox:checked").each(function() {
                selectedOrders.push($(this).val());
            });

            if (selectedOrders.length === 0) {
                alert("Please select at least one order to delete.");
                return;
            }

            if (!confirm("Are you sure you want to delete the selected orders?")) {
                return;
            }

            $.ajax({
                url: "order_submit_delete.php",
                type: "POST",
                data: { orderIds: selectedOrders },
                success: function(response) {
                    let data = JSON.parse(response);
                    if (data.success) {
                        alert("Selected orders deleted successfully.");
                        location.reload();
                    } else {
                        alert("Error: " + data.error);
                    }
                }
            });
        });
    });
</script>
<script>
    // Print Table Data Function with Order Form Header
    function printTableData() {
        // Get selected dropdown values
        let selectedFullname = $("#AdminFilter").val() || $("#customerFilter").val() || $("#memberFilter").val() || $("#solapurFilter").val() || $("#kolhapurFilter").val();
        let selectedAccountType = "";

        if ($("#customerFilter").val()) {
            selectedAccountType = "Customer";
        } else if ($("#AdminFilter").val()) {
            selectedAccountType = "Admin";
        } else if ($("#memberFilter").val()) {
            selectedAccountType = "Member";
        } else if ($("#solapurFilter").val()) {
            selectedAccountType = "Kolhapur Member";
        } else if ($("#kolhapurFilter").val()) {
            selectedAccountType = "Kolhapur Customer";
        }
        if (!selectedFullname) {
            alert("Please select a user from the dropdown before printing.");
            return;
        }

        $.ajax({
            url: "order_fetch_id.php",
            type: "POST",
            data: { fullname: selectedFullname },
            dataType: "json",
            success: function (response) {
                if (response.success) {

        let printContent = `
        <div class="order-form">
            <div class="header">
                <img src="../image/RJ logo.png" class="logo" alt="RJ Photo">
                <div class="contact">
                    <h3>Yogesh Patil</h3>
                    <p>📞 9834530051</p>
                    <p><img src="../image/logo/whatsapp.png"> 9766950925</p>
                </div>
            </div>
            <div class="company-details">
                <p><strong>Office:</strong> PUNE-SOLAPUR ROAD, NH-65, MOHOL-413 213, DIST. SOLAPUR.</p>
                <p><strong>Warehouse:</strong> GATE NO. 280, PLOT NO. 2, A/P. KONDI, TQ. NORTH SOLAPUR, DIST. SOLAPUR.</p>
                <p><strong>GSTIN:</strong> 27AAZFR2504H1ZV | <strong>Email:</strong> rjautoheaven@gmail.com</p>
            </div>
            <hr>
            <div class="order-details">
                <div class="order-header">
                    <h3>ORDER FORM No.: <span id="orderFormNo" style="color:red;">${response.submit_id || "N/A"}</span></h3>
                    <p><strong>Date:</strong> <span id="orderDate">${response.order_date || new Date().toLocaleDateString()}</span></p>
                </div>

                <div class="order-row">
                    <p><strong>Party Name:</strong> <span id="partyName"> ${selectedFullname || "N/A"}</span></p>
                    <p><strong>City:</strong> <span id="partyCity"></span></p>
                </div>

                <div class="order-row">
                    <p><strong>Transport:</strong> <span id="partyTransport"></span></p>
                    <p><strong>Party Contact No:</strong> <span id="partyContact">${response.mobile || "N/A"}</span></p>
                </div>
            </div>
        </div>
        `;

        printContent += "<table class='table table-bordered'><thead><tr>";
        let table = document.querySelector("#table-responsive table");
        let checkboxes = document.querySelectorAll(".order-checkbox:checked");

        let headers = ["Sr. No", "Product", "Part No", "Quantity"];
        headers.forEach(header => {
            printContent += "<th>" + header + "</th>";
        });
        printContent += "</tr></thead><tbody>";

        if (checkboxes.length > 0) {
            checkboxes.forEach(checkbox => {
                let row = checkbox.closest("tr");
                let rowData = row.querySelectorAll("td");
                printContent += `<tr>
                    <td>${rowData[1].innerText}</td>
                    <td>${rowData[3].innerText}</td>
                    <td>${rowData[5].innerText}</td>
                    <td>${rowData[6].innerText}</td>
                </tr>`;
            });
        } else {
            let rows = table.querySelectorAll("tbody tr");
            rows.forEach(row => {
                let rowData = row.querySelectorAll("td");
                printContent += `<tr>
                    <td>${rowData[1].innerText}</td>
                    <td>${rowData[3].innerText}</td>
                    <td>${rowData[5].innerText}</td>
                    <td>${rowData[6].innerText}</td>
                </tr>`;
            });
        }

        printContent += "</tbody></table>";

        let printWindow = window.open("", "", "width=900,height=600");
        printWindow.document.write(`
            <html>
            <head>
                <title>Print Orders</title>
                <style>
                    table {
                        border-collapse: 
                        collapse; 
                        width: 100%;
                    }
                    th, td {
                        border: 1px solid black; 
                        padding: 8px; 
                        text-align: left;
                    }
                    .table td:nth-child(2) {
                        min-width: 150px;
                        max-width: 200px;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                    }
                    .table td:nth-child(3),
                    .table td:nth-child(4) {
                        min-width: 70px;
                        max-width: 100px;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                    }
                    .order-form {
                        width: 90%;
                        margin: 20px auto;
                        padding: 10px;
                        border: 2px solid #000;
                        border-radius: 8px;
                        font-family: Arial, sans-serif;
                    }

                    .header {
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                    }

                    .logo {
                        width: 20%;
                        margin-top: -10px;
                    }
                    p img {
                        width: 3%;
                        height: auto;
                    }
                    .contact {
                        text-align: right;
                        font-size: 14px;
                        margin-top: -10px;
                        line-height: 0.5;
                        font-weight: bold;
                    }
                        
                    .contact h3 {
                        text-align: right;
                        font-size: 14px;
                        font-weight: bold;
                    }
                    .contact p {
                        line-height: 0.5;
                    }

                    .company-details {
                        text-align: center;
                        font-size: 14px;
                        margin-top: -55px;
                    }

                    .order-details {
                        font-size: 16px;
                        line-height: 0.5;
                    }

                    .order-details h3 {
                        display: inline-block;
                        margin-right: 20px;
                        line-height: 0.5;
                    }

                    .order-header, .order-footer {
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                    }
                    
                    .order-row {
                        display: flex;
                        justify-content: space-between;
                        margin: 5px 0;
                        width: 100%;
                    }

                    .order-row p {
                        width: 50%;
                        line-height: 0.5;
                    }
                </style>
            </head>
            <body>
                ${printContent}
            </body>
            </html>
        `);
        printWindow.document.close();
        printWindow.print();
    } else {
                    alert("No order found for the selected user.");
                }
            },
            error: function () {
                alert("Error fetching order details.");
            }
        });
    }

    //Search Customer_fullname JS  
    document.getElementById("searchCustomer").addEventListener("input", function () {
        const searchValue = this.value.toLowerCase();
        const rows = document.querySelectorAll("#ordersTable tbody tr");
        let count = 0;

        rows.forEach(row => {
            const customerName = row.cells[5].textContent.toLowerCase();
            if (customerName.includes(searchValue)) {
                row.style.display = "";
                count++;
            } else {
                row.style.display = "none";
            }
        });

        document.getElementById("totalOrders").innerText = 
            searchValue ? `Total Orders for "${this.value}": ${count}` : '';
    });
</script>
</body>
</html>