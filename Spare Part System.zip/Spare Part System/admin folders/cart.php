<?php

include '../db.php';

// Set timezone to India (Maharashtra)
date_default_timezone_set("Asia/Kolkata");



if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inputData = json_decode(file_get_contents('php://input'), true);
    
     // 1. Get current customer_id from session
     $customer_id = $_SESSION['id'];

     // 2. Get fullname from admission table
     $fullname = "";
     $query = "SELECT fullname FROM admission WHERE id = ?";
     $stmt = $conn->prepare($query);
     $stmt->bind_param("i", $customer_id);
     $stmt->execute();
     $result = $stmt->get_result();
     if ($result && $result->num_rows > 0) {
         $row = $result->fetch_assoc();
         $fullname = $row['fullname'];
     }
     $stmt->close();

    // Retrieve product data from POST request
    $fullname = $_POST['fullname'];
    $account_type = $_POST['account_type'];
    $product = $_POST['Product'];
    $batch = $_POST['Batch'];
    $company = $_POST['Company'];
    $partNo = $_POST['PartNo'];
    $purchaseRate = $_POST['PurchaseRate'];
    $gst = $_POST['GST'];
    $exp = $_POST['Exp'];
    $margin = $_POST['Margin'];
    $saleRate = $_POST['SaleRate'];
    $quantity = $_POST['quantity']; // Retrieve the quantity
    $totalSaleRate = $saleRate * $quantity;
    $closingQty = $_POST['ClosingQty'];
    $location = $_POST['Location'];
    $imagePath = $_POST['imagePath'];
    $imageBasePath = "../../admin folders/";
    $imagePathWithoutBase = str_replace($imageBasePath, '',$imagePath);
    $feedback = isset($_POST['feedback']) ? trim($_POST['feedback']) : ''; // Capture feedback

    // Create current date-time in India timezone
    $currentDateTime = date("Y-m-d H:i:s");

     // Check if the product is already in the cart
     $query = "SELECT * FROM cart WHERE partNo = ?";
     if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("s", $partNo);
        $stmt->execute();
        $result = $stmt->get_result();
        $result->free(); // Free the result set
        $stmt->close();
     } else {
        echo json_encode(['success' => false, 'message' => 'SQL Error (Check Query): ' . $conn->error]);
        exit;
     }
    // check part no end
    // Insert data into the database
    $query = "INSERT INTO cart(customer_id, fullname, account_type, product, batch, company, partNo, purchaseRate, gst, exp, margin, saleRate,  totalSaleRate, closingQty, location, imagePath, quantity, feedback, created_at) 
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($query);
    if ($stmt) {
        $stmt->bind_param("issssssdidsddssssss", $customer_id, $fullname, $account_type, $product, $batch, $company, $partNo, $purchaseRate, $gst, $exp, $margin, $saleRate,  $totalSaleRate, $closingQty, $location, $imagePathWithoutBase, $quantity, $feedback, $currentDateTime);

        if ($stmt->execute()) {
        } else {
            echo "<script>alert('Error inserting data: " . $stmt->error . "');</script>";
        }
        $stmt->close();
    } else {
        echo "<script>alert('Failed to prepare the SQL statement');</script>";
    } 
}
    $query = "SELECT * FROM cart ORDER BY created_at DESC";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        // Display Cart details
        echo "<!DOCTYPE html>
        <html lang='en'>
        <head>
            <meta charset='UTF-8'>
            <link rel='icon' href='../image/icon.png' type='image/png'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css'>
            <link rel='stylesheet' href='../admin folders/css/cart.css'>
            <title>Cart Details</title>
        </head>
        <body>
        <?php include('preloader.html'); ?>
            <a href='admin_dashboard.php' class='back-button'><img src='../image/h1.png' class='home' alt='ok'></a>
            <h1>Cart Details</h1>
            <form action='order.php' method='post' id='orderForm'>
                <div class='checkbox-container'>
                    <input type='checkbox' id='select-product' onclick='toggleSelectAll()'>
                    <label for='select-product'>Select All Orders</label>
                </div>
            <div class='cart-container'>";
            
        while ($row = $result->fetch_assoc()) {
            echo "<div class='cart-card'>
                <div class='cart-details'   id='cart-item-" . $row['id'] . "'>
                    <input type='checkbox' class='product-checkbox' name='product[]' value='" . $row['id'] . "'>
                    <img src='" . $row['imagePath'] . "' alt='" . $row['product'] . "'>
                    <h4> " . $row['product'] . "</h4>
                    <p><strong>Customer Name:</strong> " . $row['fullname'] . "</p> 
                    <p><strong>Account Type:</strong> " . $row['account_type'] . "</p>
                    <p><strong>Batch:</strong> " . $row['batch'] . "</p>
                    <p><strong>Company:</strong> " . $row['company'] . "</p>
                    <p><strong>Part No:</strong> " . $row['partNo'] . "</p>
                    <p><strong>Purchase Rate:</strong> ₹" . $row['purchaseRate'] . "</p>
                    <p><strong>GST:</strong> " . $row['gst'] . "%</p>
                    <p><strong>Exp:</strong> " . $row['exp'] . "</p>
                    <p><strong>Margin:</strong> " . $row['margin'] . "%</p>
                    <p><strong>Sale Rate:</strong> ₹" . $row['saleRate'] . "</p>
                    <p><strong>Total Sale Rate:</strong> ₹{$row['totalSaleRate']}</p>
                    <p><strong>Closing Qty:</strong> " . $row['closingQty'] . "</p>
                    <p><strong>Location:</strong> " . $row['location'] . "</p>
                    <p><strong>Quantity Ordered:</strong> " . $row['quantity'] . "</p>
                    <p><strong>Feedback:</strong> " . htmlspecialchars($row['feedback']) . "</p>
                    
                        <input type='hidden' name='product[<?php echo $row[id]; ?>]' value='<?php echo $row[product]; ?>'>
                        <input type='hidden' name='fullname[<?php echo $row[id]; ?>]' value='<?php echo $row[fullname]; ?>'>
                        <input type='hidden' name='account_type[<?php echo $row[id]; ?>]' value='<?php echo $row[account_type]; ?>'>
                        <input type='hidden' name='batch[<?php echo $row[id]; ?>]' value='<?php echo $row[batch]; ?>'>
                        <input type='hidden' name='company[<?php echo $row[id]; ?>]' value='<?php echo $row[company]; ?>'>
                        <input type='hidden' name='partNo[<?php echo $row[id]; ?>]' value='<?php echo $row[partNo]; ?>'>
                        <input type='hidden' name='purchaseRate[<?php echo $row[id]; ?>]' value='<?php echo $row[purchaseRate]; ?>'>
                        <input type='hidden' name='gst[<?php echo $row[id]; ?>]' value='<?php echo $row[gst]; ?>'>
                        <input type='hidden' name='exp[<?php echo $row[id]; ?>]' value='<?php echo $row[exp]; ?>'>
                        <input type='hidden' name='margin[<?php echo $row[id]; ?>]' value='<?php echo $row[margin]; ?>'>
                        <input type='hidden' name='saleRate[<?php echo $row[id]; ?>]' value='<?php echo $row[saleRate]; ?>'>
                        <input type='hidden' name='totalSaleRate[<?php echo $row[id]; ?>]' value='<?php echo $row[totalSaleRate]; ?>']'>
                        <input type='hidden' name='closingQty[<?php echo $row[id]; ?>]' value='<?php echo $row[closingQty]; ?>'>
                        <input type='hidden' name='location[<?php echo $row[id]; ?>]' value='<?php echo $row[location]; ?>'>
                        <input type='hidden' name='quantity[<?php echo $row[id]; ?>]' value='<?php echo $row[quantity]; ?>'>
                        <input type='hidden' name='feedback[<?php echo $row[id]; ?>]' value='<?php echo $row[feedback]; ?>'>
                    </form>
                </div>
                    <div class='cart-button'>
                        <button class='delete-btn' data-id='" . $row['id'] . "'>Remove From Cart</button>
                    </div>  
            </div>";
        }
        echo "</div>
        <div class='cart-button'>
                <button type='submit' onclick='submitForm()'>Submit All Orders</button>
        </div>
         <div class='scroll-btn' onclick='toggleScroll()'>
        <img id='arrow-img' src='../image/logo/down-arrow.png' alt='scroll-arrow'>
    </div>;
    <script src='/spare_parts/admin folders/js/cart.js'></script>
    <script>
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Backspace') {
                event.preventDefault();
                window.history.back();
            }
        });
        //Select All Orders
        function toggleSelectAll() {
            const selectAllCheckbox = document.getElementById('select-product');
            const productCheckboxes = document.querySelectorAll('.product-checkbox');
            productCheckboxes.forEach(checkbox => { 
            checkbox.checked = selectAllCheckbox.checked;
            });
        }
        //Submit Orders
        function submitForm() {
            const selectedCheckboxes = document.querySelectorAll('.product-checkbox:checked');
            if (selectedCheckboxes.length === 0) {
                alert('Select At Least One Product!');
                return false;
            }                    
            document.getElementById('orderForm').submit();
        }
        
        // Select all delete buttons
        document.addEventListener('DOMContentLoaded', () => {
            // Select all delete buttons
            document.querySelectorAll('.delete-btn').forEach(button => {
                button.addEventListener('click', function (event) {
                    event.preventDefault(); // Prevent form submission or page reload
                    const id = this.getAttribute('data-id'); // Get product ID
                    const cartItem = this.closest('.cart-card'); // Get the closest cart item card
        
                    // Send delete request to the server
                    fetch('cart_remove.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ id: id }) // Send product ID
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            cartItem.remove(); // Remove the entire cart item card
                            alert('Product removed from cart successfully!');
                        } else {
                            alert('Failed to remove product from cart!');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('An error occurred while removing the product.');
                    });
                });
            });
        });
        
        // Function to toggle scroll up and down
        function toggleScroll() {
            if (window.innerHeight + window.scrollY >= document.body.offsetHeight) {
                // If at bottom, scroll to top
                window.scrollTo({ top: 0, behavior: 'smooth' });
            } else {
                // If at top, scroll to bottom
                window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
            }
        }
        
        // Change arrow image on scroll
        window.addEventListener('scroll', function () {
            let arrowImg = document.getElementById('arrow-img');
        
            if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 10) {
                arrowImg.src = '../image/logo/up-arrow.png'; // Show Up Arrow when at bottom
            } else {
                arrowImg.src = '../image/logo/down-arrow.png'; // Show Down Arrow when at top
            }
        });
    </script>
    </body>
    </html>";   
    } else {
    echo "<h1>No Cart Data Found</h1>";
}    
?>