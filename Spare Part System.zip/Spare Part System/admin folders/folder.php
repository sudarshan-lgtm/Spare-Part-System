<?php
session_start();
include '../db.php';

// Redirect if not authenticated
if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
    header("Location: upload_folder_excel.php");
    exit;
}
$folderPath = 'uploads/folders/';

// Function to delete all files in the folder
function deleteAllFiles($path) {
    if (is_dir($path)) {
        $files = glob($path . '/*'); // Get all files in the folder
        foreach ($files as $file) {
            if (is_file($file)) {
                unlink($file); // Delete file
            }
        }
        return true;
    }
    return false;
}

// Function to truncate tables
function truncateTable($conn, $tableName) {
    $query = "TRUNCATE TABLE $tableName";
    if ($conn->query($query) === TRUE) {
        return true;
    }
    return false;
}

// Handle Delete All Files button click
if (isset($_POST['delete_all'])) {
    if (deleteAllFiles($folderPath)) {
        echo "<script>alert('All files have been deleted successfully.'); window.location.href='folder.php';</script>";
    } else {
        echo "<script>alert('Failed to delete files. Please try again.');</script>";
    }
}

// Handle Delete Excel (Truncate `productinventory`)
if (isset($_POST['delete_excel'])) {
    if (truncateTable($conn, 'productinventory')) {
        echo "<script>alert('All product inventory data deleted successfully.'); window.location.href='folder.php';</script>";
    } else {
        echo "<script>alert('Failed to delete product inventory data.');</script>";
    }
}

// Handle Delete Solapur Excel (Truncate `solapurdata`)
if (isset($_POST['delete_solapur_excel'])) {
    if (truncateTable($conn, 'solapurdata')) {
        echo "<script>alert('Solapur data deleted successfully.'); window.location.href='folder.php';</script>";
    } else {
        echo "<script>alert('Failed to delete Solapur data.');</script>";
    }
}

// Handle Delete Kolhapur Excel (Truncate `kolhapurdata`)
if (isset($_POST['delete_kolhapur_excel'])) {
    if (truncateTable($conn, 'kolhapurdata')) {
        echo "<script>alert('Kolhapur data deleted successfully.'); window.location.href='folder.php';</script>";
    } else {
        echo "<script>alert('Failed to delete Kolhapur data.');</script>";
    }
}

// Fetch folders
$folders = array_filter(glob($folderPath . '*'), 'is_file');

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Uploaded Folders</title>
    <style>
        /* General Styles */
        body {
            font-family: 'Poppins', sans-serif;
            margin: 20px;
            background: linear-gradient(to right, #141e30, #243b55);
            color: #fff;
            text-align: center;
        }
        /* Header */
        h1 {
            text-align: center;
            color: #fff;
            font-size: 28px;
            margin-bottom: 20px;
        }
        /* Table Container */
        .table-container {
            width: 80%;
            max-width: 900px;
            margin: 20px auto;
            background: rgba(255, 255, 255, 0.1);
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.3);
        }
        /* Scrollable Table */
        .table-wrapper {
            max-height: 300px;
            overflow-y: auto;
            display: block;
            border-radius: 8px;
        }
        /* Table Styles */
        table {
            width: 100%;
            border-collapse: collapse;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
        }
        th, td {
            border: 1px solid rgba(255, 255, 255, 0.2);
            padding: 12px;
            text-align: left;
        }
        th {
            background: linear-gradient(45deg, #ff416c, #ff4b2b);
            color: white;
            position: sticky;
            top: 0;
            z-index: 2;
        }
        /* Form Styling */
        form {
            text-align: center;
            margin-top: 20px;
            background: rgba(255, 255, 255, 0.1);
            padding: 20px;
            border-radius: 10px;
            display: grid;
            grid-template-columns: repeat(2, 1fr); /* 3 cards in a row for medium screens */
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.3);
        }
        /* Delete Buttons */
        h4 {
            color: #ffeb3b;
            font-size: 20px;
            margin-top: 20px;
            text-align: left;
            margin-left: 50%;
            transition: color 0.3s ease-in-out;
        }
        h4:hover {
            color: #ff9800;
            cursor: pointer;
        }
        .delete-button {
            background: linear-gradient(45deg, #ff416c, #ff4b2b);
            color: white;
            padding: 12px 20px;
            border: none;
            width: 45%;
            height: 80%;
            text-align: center;
            cursor: pointer;
            font-size: 18px;
            border-radius: 25px;
            margin-top: 5px;
            transition: all 0.3s ease-in-out;
            box-shadow: 0px 4px 10px rgba(255, 75, 43, 0.5);
        }
        .delete-button:hover {
            background: linear-gradient(45deg, #ff4b2b, #ff416c);
            transform: scale(1.1);
        }
        .logout-container {
            position: absolute;
            top: 10px;
            left: 10px;
        }
        .logout-button {
            background: linear-gradient(45deg, #ff416c, #ff4b2b);
            padding: 10px;
            margin-top: 100%;
            border-radius: 25px;
            cursor: pointer;
            height: auto; 
            width:30px;
            transition: all 0.3s ease-in-out;
            box-shadow: 0px 4px 10px rgba(255, 75, 43, 0.5);
            animation: pulse 1.5s infinite;
        }
        .logout-button:hover {
            background: linear-gradient(45deg, #ff4b2b, #ff416c);
            transform: scale(1.1);
        }
        @keyframes pulse {
            0% { box-shadow: 0 0 15px rgba(255, 71, 87, 0.8); }
            50% { box-shadow: 0 0 25px rgba(255, 71, 87, 1); }
            100% { box-shadow: 0 0 15px rgba(255, 71, 87, 0.8); }
        }
        /* Responsive Design */
        @media screen and (max-width: 768px) {
            .table-container {
                width: 80%;
                margin-top: 20%;
            }
            th, td {
                padding: 10px;
            }
            .delete-button {
                width: 100%;
                font-size: 16px;
            }
        }
    </style>
</head>
<body>
    <?php include("preloader.html"); ?>
    <h1>Uploaded Folders</h1>
    <div class="table-container">
        <div class="table-wrapper">
            <table>
                <tbody>
                    <?php if (!empty($folders)): ?>
                            <?php foreach ($folders as $folder): ?>
                                <?php $folderName = basename($folder); ?>
                                <tr>
                                    <td><?php echo $folderName; ?></td>
                                    <td>
                                        <a href="display_files.php?folder=<?php echo $folderName; ?>">Nothing To Show</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="2">No folders uploaded.</td>
                            </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Delete All Button -->
    <form method="POST">
        <h4>Delete Image Folder</h4>
        <button type="submit" name="delete_all" class="delete-button">Delete All Images</button>

        <h4>Delete Solapur Excel</h4>
        <button type="submit" name="delete_excel" class="delete-button">Delete Solapur Excel</button>

        <!-- <h4>Delete Solapur Excel</h4>
        <button type="submit" name="delete_solapur_excel" class="delete-button">Delete Solapur Excel</button>-->

        <h4>Delete Kolhapur Excel</h4>
        <button type="submit" name="delete_kolhapur_excel" class="delete-button">Delete Kolhapur Excel</button>
    </form>
    <div class="logout-container">
    <a href='upload_logout.php' ><img src="../image/logo/logout.png" class="logout-button" alt="logout"></a>
    </div>

</body>
</html>
