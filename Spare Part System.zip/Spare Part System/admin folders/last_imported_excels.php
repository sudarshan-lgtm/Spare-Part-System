<?php
session_start();
include '../db.php';

// Prevent accessing this page after logout
if (!isset($_SESSION["user_id"])) {
    header("Location: admin_login.php");
    exit();
}

$tableName = isset($_GET['table']) ? $_GET['table'] : 'productinventory';

$query = "SELECT * FROM $tableName";
$result = $conn->query($query);
$serialNumber = 1;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uploaded Data</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background-color: #4dd0e1; /* Light teal */
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #4CAF50, #2E7D32);
            color: white;
            border-radius: 50%;
            text-decoration: none;
            font-size: 22px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
            position: fixed; /* Optional: fixed position */
            top: 10px;
            left: 20px;
            z-index: 999;
        }
        
        .back-button:hover {
            background: linear-gradient(135deg, #66BB6A, #388E3C);
            transform: scale(1.1);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.3);
            color: #fff;
        }
    </style>
</head>
<body>
    <?php include("preloader.html"); ?>
<a href='admin_dashboard.php' class='back-button'><i class="fa fa-home" aria-hidden="true"></i></a>
    <div class="container mt-4">
        <h2 class="text-center mb-4">View Uploaded Data</h2>
        
        <!-- Buttons to toggle between tables -->
        <div class="text-center mb-3">
            <button class="btn me-2 <?php echo ($tableName == 'productinventory') ? 'btn-primary active' : 'btn-secondary'; ?>" onclick="loadData('productinventory')">Solapur File</button>
            <button class="btn <?php echo ($tableName == 'kolhapurdata') ? 'btn-primary active' : 'btn-secondary'; ?>" onclick="loadData('kolhapurdata')">Kolhapur File</button>
        </div>

        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>Sr.No</th>
                        <th>Product Group</th>
                        <th>Product</th>
                        <th>Batch</th>
                        <th>Company</th>
                        <th>Part No</th>
                        <th>Purchase Rate</th>
                        <th>GST</th>
                        <th>Exp</th>
                        <th>Margin</th>
                        <th>Purchase Code</th>
                        <th>Sale Rate</th>
                        <th>Receipt Qty</th>
                        <th>Issue Qty</th>
                        <th>Closing Qty</th>
                        <th>Location</th>
                        <th>Image</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $serialNumber++; ?></td>
                        <td><?php echo $row['ProductGroup']; ?></td>
                        <td><?php echo $row['Product']; ?></td>
                        <td><?php echo $row['Batch']; ?></td>
                        <td><?php echo $row['Company']; ?></td>
                        <td><?php echo $row['PartNo']; ?></td>
                        <td><?php echo $row['PurchaseRate']; ?></td>
                        <td><?php echo $row['GST']; ?></td>
                        <td><?php echo $row['Exp']; ?></td>
                        <td><?php echo $row['Margin']; ?></td>
                        <td><?php echo $row['PurchaseCode']; ?></td>
                        <td><?php echo $row['SaleRate']; ?></td>
                        <td><?php echo $row['ReceiptQty']; ?></td>
                        <td><?php echo $row['IssueQty']; ?></td>
                        <td><?php echo $row['ClosingQty']; ?></td>
                        <td><?php echo $row['Location']; ?></td>
                        <td>
                            <?php if (!empty($row['imagePath'])) { ?>
                                <img src="<?php echo $row['imagePath']; ?>" alt="Product Image" width="50">
                            <?php } else { echo "No Image"; } ?>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        function loadData(tableName) {
            window.location.href = "last_imported_excels.php?table=" + tableName;
        }
    </script>

</body>
</html>
