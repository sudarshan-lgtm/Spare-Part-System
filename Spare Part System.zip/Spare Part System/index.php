<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
include 'db.php';

$stmt = $conn->query("SELECT text FROM slogans WHERE is_selected = 1 LIMIT 1");
$row = $stmt->fetch_assoc();
$selectedSlogan = $row['text'] ?? null;
$stmt->close();

// Get the list of images from the folder
$image_dir = "admin folders/uploads/folders/";
$images = array_diff(scandir($image_dir), array('.', '..'));

// Function to get cards from a table
function getCompanyCards($conn, $tableName, $images, $image_dir) {
    $cards = [];
    $sql = "SELECT DISTINCT company FROM $tableName";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $company_name = strtolower($row['company']);
            foreach ($images as $image) {
                $image_name = strtolower(pathinfo($image, PATHINFO_FILENAME));
                if ($image_name === $company_name) {
                    $cards[] = [
                        'image' => $image_dir . $image,
                        'company' => $row['company'],
                        'source' => $tableName
                    ];
                    break;
                }
            }
        }
        
    }
    return $cards;
}
$productInventoryCards = getCompanyCards($conn, 'productinventory', $images, $image_dir);
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <link rel="icon" href="../image/icon.png" type="image/png">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="preload" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&display=swap" as="style">
  <link rel="preload" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" as="style">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
  <link rel="stylesheet" href="./css/index.css">
  <title>Rj Autoheaven</title>
  <style>
    /* Basic Reset */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    /* Body Background */
    body {
        min-height: 100vh;
        font-family: 'Montserrat', sans-serif;
        background-color: #fff;
        /*background: linear-gradient(-45deg, #8e2de2, #4a00e0, #00c6ff, #0072ff);*/
        background-size: 400% 400%;
        animation: gradientBG 15s ease infinite;
        overflow-x: hidden;
    }
    /* Gradient Animation */
    @keyframes gradientBG {
        0% {background-position: 0% 50%;}
        50% {background-position: 100% 50%;}
        100% {background-position: 0% 50%;}
    }
    /* Navbar */
    .blur-navbar {
        backdrop-filter: blur(10px);
        background: rgba(0, 0, 0, 0.5);
        padding: 10px 0;
        position: fixed;
        top: 0;
        width: 100% !important;
        z-index: 1000;
    }
    .blur-navbar.scrolled {
      background-color: rgba(0, 0, 0, 0.8) !important;
      transition: background-color 0.3s ease;
    }
    .navbar-brand {
        font-weight: bold;
        font-size: 1.5rem;
        color: #fff;
    }
    .navbar-logo {
        width: 50px;
    }
    .nav-link {
        color: #eee !important;
        margin: 0 10px;
        position: relative;
    }
    .nav-link::after {
        content: '';
        position: absolute;
        width: 0%;
        height: 2px;
        background: #00c6ff;
        left: 0;
        bottom: 0;
        transition: 0.3s;
    }
    .nav-link:hover::after {
        width: 100%;
    }
    /* Signup Button */
    .btn-signup {
        background: transparent;
        border: 2px solid #00c6ff;
        color: #00c6ff;
        padding: 8px 16px;
        border-radius: 50px;
        transition: 0.3s;
    }
    .btn-signup:hover {
        background: #00c6ff;
        color: #fff;
    }
    .hero-section {
        position: relative;
        min-height: 70vh; /* Changed to min-height to allow content to expand */
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;
        padding-top: 70px; /* Adjust for navbar height */
    }
    
    /* Background Image */
    .background-image {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%; /* Full height of hero section */
        z-index: 1;
        overflow: hidden;
    }
    
    .background-image img {
        width: 100%;
        height: 100%;
        object-fit: cover; /* Maintains aspect ratio and covers the area */
        object-position: center top; /* Aligns image to the top */
    }
    
    /* Black overlay on top of image */
    .black-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        z-index: 2;
    }
    
    /* Text content */
    .hero-content {
        position: relative;
        z-index: 3;
        color: white;
    }
    .hero-content h3 {
        font-size: 2rem;
        margin-bottom: 20px;
    }
    .typing-container {
        font-size: 1.5rem;
        font-weight: 500;
        color: #fff;
        padding: 20px;
        font-family: 'Poppins', 'Segoe UI', sans-serif;
        white-space: pre-wrap;
        overflow: hidden;
        max-width: 900px;
        margin: auto;
        text-align: center;
    }
    .about_sec1 {
        padding: 40px 0;
    }
    
    .about_sec1 p {
        color: #333;
        text-align: center;
    }
    
    .about_sec1 img {
        width: 100%;
        height: auto;
        transition: transform 0.3s ease;
    }
    
    .about_sec1 img:hover {
        transform: scale(1.05);
    }
    /* Counter Section */
    .counter-section {
        padding: 80px 0;
        color: #fff;
        background-color: #B3DEEB;
        background-size: 400% 400%;
        animation: gradientBG 15s ease infinite;
        position: relative;
        z-index: 1;
    }
    
    /* Gradient Animation */
    @keyframes gradientBG {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }
    
    .counter {
        font-size: 3rem;
        font-weight: bold;
        color: #333;
    }
    
    .counter p {
        font-size: 1.2rem;
        color: #333;
    }
    /* Card styling */
    .custom-card {
        transition: transform 0.5s ease, box-shadow 0.5s ease;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        border-radius: 10px;
    }
    
    .custom-card:hover {
        transform: scale(1.05);
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.4);
    }
    
    /* Hidden initially for animation */
    .hidden {
        opacity: 0;
        transform: translateY(50px);
        transition: opacity 0.8s ease-out, transform 0.8s ease-out;
    }
    
    /* Show when in viewport */
    .show {
        opacity: 1;
        transform: translateY(0);
    }
    
    /* Heading styling */
    .brand {
        height: 100%;
        font-size: 2.5rem;
        font-weight: bold;
        text-transform: uppercase;
        letter-spacing: 2px;
        background-color: #C0C0C0;
    }
    .brands-container {
      overflow: hidden;
      position: relative;
      width: 100%;
      padding: 20px 0;
    }
    .brands-scroller {
      display: flex;
      white-space: nowrap;
      animation: scroll 20s linear infinite;
      will-change: transform;
    }
    .brands-scroller:hover {
      animation-play-state: paused;
    }
    .custom-card {
      flex: 0 0 auto;
      margin-right: 15px;
      width: 200px; /* Adjust card width as needed */
      background-color: #fff;
      transition: transform 0.3s ease;
    }
    .custom-card:hover {
      transform: scale(1.05);
    }
    @keyframes scroll {
      0% { transform: translateX(0); }
      100% { transform: translateX(-50%); }
    }
    .container-fluid .card {
        padding-top: 10px;
    }
    /* Services */
    .services {
        background-color: #C0C0C0;
        border-top: 1px solid rgba(255,255,255,1);
    }
    .service-box {
        background: rgba(255,255,255,0.1);
        padding: 20px;
        border-radius: 12px;
        text-align: center;
        backdrop-filter: blur(5px);
        transition: 0.5s;
    }
    .service-box:hover {
        transform: translateY(-10px);
        background: rgba(255,255,255,0.2);
    }
    /* Footer */
    footer {
        background: rgba(0,0,0,0.5);
    }
    .sudarshan{
        width: 2%;
        height: 1%;
        transition: transform 0.3s ease-in-out; /* Smooth transition for zoom effect */
    }
    
    .sudarshan:hover {
        transform: scale(1.5); /* Zoom in by 1.5 times */
    }
    /* For extra large screens (desktop, wide monitors) */
    @media (min-width: 1441px) {
        .container, .container-fluid {
            max-width: 1400px;
        }
        .hero-section {
            padding-top: 70px; /* Adjust for navbar height */
        }
    }
    
    /* For large screens (laptops/desktops) between 1025px and 1440px */
    @media (min-width: 1025px) and (max-width: 1440px) {
        .hero-section .lead {
            font-size: 1.8rem;
        }
        .hero-section {
            padding-top: 70px;
        }
    }
    
    /* For medium screens (tablets) */
    @media (max-width: 1024px) {
        .hero-section {
            padding-top: 60px; /* Adjust for smaller navbar */
            height: 70vh;
        }
        .typing-container {
            font-size: 1.3rem;
        }
        .counter {
            font-size: 2.5rem;
        }
        .counter p {
            font-size: 1rem;
        }
    }
    
    /* For small screens (phones) */
    @media (max-width: 768px) {
        .hero-content h3 {
            font-size: 1.3rem;
        }
        .typing-container {
            font-size: 1.1rem;
            display: block; /* Ensure it shows */
        }
        .hero-section {
            padding-top: 60px !important;
            height: 50vh !important; /* Reduced height for better fit */
        }
        .background-image {
            width: 100% !important;
            height: 50vh !important; /* Match hero-section height */
        }
        .background-image img {
            height: 100% !important; /* Ensure image fills the container */
            object-fit: cover !important;
        }
        .navbar-brand {
            font-size: 1.2rem; /* Smaller brand text */
        }
        .navbar-logo {
            width: 40px; /* Smaller logo */
        }
        .nav-link {
            margin: 0 5px; /* Reduced margin for nav links */
        }
        .btn-signup {
            padding: 6px 12px; /* Smaller button padding */
            font-size: 0.9rem;
        }
        .about-img {
            width: 100%;
            height: auto;
            margin-bottom: 20px;
        }
        .about_sec1 .row {
            flex-direction: column-reverse; /* Stack image below text */
        }
        .counter-section .row {
            flex-direction: column;
            align-items: center;
        }
        .counter {
            font-size: 2rem;
        }
        .counter p {
            font-size: 0.9rem;
        }
        .custom-card {
            width: 150px; /* Smaller card width */
            margin-right: 10px;
        }
        .service-box {
            margin-bottom: 20px; /* Space between service boxes */
        }
        .about-text {
            font-size: 0.95rem;
            text-align: justify;
        }
        .card-title {
            font-size: 1rem;
        }
        .btn {
            font-size: 0.9rem;
            padding: 8px 12px;
        }
        .ok {
            margin-bottom: 0; /* Remove negative margin */
        }
    }
    @media (max-width: 600px) {
        .hero-content h3 {
            font-size: 1.2rem;
        }
        .typing-container {
            font-size: 1rem;
        }
        .hero-section {
            padding-top: 50px !important;
            height: 40vh !important;
        }
        .background-image {
            width: 100% !important;
            height: 40vh !important;
        }
        .navbar-brand {
            font-size: 1rem;
        }
        .navbar-logo {
            width: 35px;
        }
        .custom-card {
            width: 120px;
        }
    }
    @media (max-width: 480px) {
        .hero-content h3 {
            font-size: 1rem;
            color: #333;
        }
        .typing-container {
            font-size: 0.9rem;
            display: block;
        }
        
        .hero-section {
            width: 100% !important;
            padding-top: 50px !important;
            height: 35vh !important;
        }
        .background-image {
            width: 100% !important;
            height: 35vh !important;
        }
        .counter {
            font-size: 1.5rem;
        }
        .counter p {
            font-size: 0.8rem;
        }
        .counter-section {
            text-align: center;
        }
        .service-box {
            text-align: center;
        }
        .about_sec1 {
            margin-top: 0 !important; /* Override negative margin */
        }
        .card-title {
            font-size: 0.9rem;
        }
        .about-text {
            font-size: 0.85rem;
            text-align: justify;
        }
        .about-top {
            margin-top: -50% !important;
        }
        .custom-card {
            width: 100px;
        }
        .btn {
            font-size: 0.8rem;
            padding: 6px 10px;
        }
        .sudarshan {
            width: 30px !important;
            height: auto !important;
        }
    }
  </style>
</head>
<body>
<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark fixed-top blur-navbar">
    <div class="container">
        <a class="navbar-brand" href="index.php">
            <img src="../image/122.png" alt="Logo" class="navbar-logo" loading="lazy"> RJ AutoHeaven
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse text-center justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="about_us.html">About</a></li>
                <li class="nav-item"><a class="nav-link" href="brand.php">Products</a></li>
                <li class="nav-item"><a class="nav-link" href="contact_main.php">Contact</a></li>
                <li class="nav-item">
                    <a href="signup.html" class="btn btn-signup">SignUp</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<!-- Hero Section -->
<header class="hero-section">
    <div class="background-image">
        <img src="../../image/s12.png" alt="Stylish Banner" loading="lazy" class="img-fluid styled-img">
        <div class="black-overlay"></div>
    </div>
    <div class="container text-center hero-content">
        <h3 class="lead text-white"><?= htmlspecialchars($selectedSlogan ?: 'No slogan selected') ?></h3>
        <div class="typing-container text-white d-none d-sm-block">
            <span id="typed-text"></span>
        </div>
    </div>
</header>

<section class="about_sec1">
    <div class="container">
        <div class="container">
            <div class="row align-items-center gy-4">
                <div class="col-12 col-md-6" data-aos="flip-right" data-aos-duration="3000">
                    <img src="../../image/12.jpg" alt="pk" class="img-fluid w-100 about-img" loading="lazy">
                </div>
                <div class="col-12 col-md-6 about-top" data-aos="flip-right" data-aos-duration="3000">
                    <p class="about-text">
                       <b>RJ AUTOHEAVEN</b> has evolved into one of Solapur’s most trusted and dynamic names in the automobile spare parts industry. We cater extensively to the demands of four-wheeler and heavy vehicle segments, providing high-quality solutions.
                    </p>
                    <p class="about-text">
                        Over the years, we have expanded our footprint, serving over 20,000+ customers across various automobile sectors including HCV, LCV, passenger vehicles, and agricultural machinery.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Counter Section for Wholesaler Services -->
<section class="counter-section">
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-4 mb-4 mb-md-0">
                <div class="counter fade-in-up" id="onTimeDelivery">0%</div>
                <p>ON-TIME DELIVERY</p>
            </div>
            <div class="col-12 col-md-4 mb-4 mb-md-0">
                <div class="counter fade-in-up" id="customerSatisfaction">0%</div>
                <p>CUSTOMER SATISFACTION</p>
            </div>
            <div class="col-12 col-md-4">
                <div class="counter fade-in-up" id="qualityAssurance">0%</div>
                <p>QUALITY ASSURANCE</p>
            </div>
        </div>
    </div>
</section>
<!-- Our Brands Section -->
<section id="our-brands-section" style="background-color: #C0C0C0;">
    <div class="container px-3" style="padding: 20px;">
        <h1 class="brand text-center my-4 hidden">OUR BRANDS</h1>
        <div class="brands-container">
            <div class="brands-scroller">
                <?php
                $limitedCards = array_slice($productInventoryCards, 0, 16);
                if (count($limitedCards) > 0):
                    // Duplicate cards to ensure seamless scrolling
                    $cards = array_merge($limitedCards, $limitedCards);
                    foreach ($cards as $card):
                ?>
                    <div class="card shadow-sm custom-card hidden">
                        <img src="<?= $card['image'] ?>" class="card-img-top" alt="Company Image" loading="lazy" style="height: auto; width: auto; object-fit: cover;">
                        <div class="card-body text-center">
                            <h5 class="card-title mb-0"><?= $card['company'] ?></h5>
                        </div>
                    </div>
                <?php
                    endforeach;
                else:
                ?>
                    <div class="col-12 text-center">
                        <p>No Products found.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="d-flex justify-content-center">
            <a href="brand.php" class="btn btn-danger mt-3 mb-4 w-auto w-sm-50 w-md-25 w-lg-14" style="border-radius: 8px;">Products</a>
        </div>
    </div>
</section>

<!-- Services Section -->
<section class="services py-5">
    <div class="container">
        <h2 class="text-center mb-5 text-black">Our Services</h2>
        <div class="row g-4 hidden">
            <div class="col-md-4 hidden">
                <div class="service-box ok">
                    <h4>Genuine Spare Parts</h4>
                    <p>High-quality, original spare parts for your vehicle.</p>
                </div>
            </div>
            <div class="col-md-4 hidden">
                <div class="service-box">
                    <h4>Expert Consultation</h4>
                    <p>Technical advice to get you the right parts easily.</p>
                </div>
            </div>
            <div class="col-md-4 hidden">
                <div class="service-box">
                    <h4>Fast Delivery</h4>
                    <p>Quick, safe and secure delivery to your doorstep.</p>
                </div>
            </div>
            <div class="col-md-4 hidden">
                <div class="service-box">
                    <h4>Wholesale & Bulk Orders</h4>
                    <p>Quick, safe and secure delivery to your doorstep.</p>
                </div>
            </div>
            <div class="col-md-4 hidden">
                <div class="service-box">
                    <h4>Easy Online Ordering</h4>
                    <p>Quick, safe and secure delivery to your doorstep.</p>
                </div>
            </div>
            <div class="col-md-4 hidden">
                <div class="service-box">
                    <h4>Wide Range of Products</h4>
                    <p>Quick, safe and secure delivery to your doorstep.</p>
                </div>
            </div>
            <div class="col-md-4 hidden">
                <div class="service-box">
                    <h4>Warranty & Replacement</h4>
                    <p>Quick, safe and secure delivery to your doorstep.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section style="background-color: #C0C0C0;">
    <div class="container px-4" style="background-color: #C0C0C0;">
        <div class="card shadow-sm p-4" style="background-color: #C0C0C0;">
            <h4 class="mb-4 text-center text-danger">RJ AUTOHEAVEN Policies</h4>
            <div class="d-flex flex-column flex-md-row justify-content-around align-items-center gap-3">
                <a href="Privacy_Policy.html" class="btn btn-outline-primary w-100 w-md-auto">Privacy Policy</a>
                <a href="terms_conditions.html" class="btn btn-outline-success w-100 w-md-auto">Terms & Conditions</a>
                <a href="return_refund_policy.html" class="btn btn-outline-danger w-100 w-md-auto">Return & Refund Policy</a>
            </div>
        </div>
    </div>
</section>

<!-- Footer -->
<footer class="text-center py-4 text-white p-3">
    <small>Developed by <a href="index.php" class="text-info"><img src="../image/sud2.png" class="sudarshan"></a> | © 2025 RJ AUTOHEAVEN. All Rights Reserved.</small>
</footer>

<!-- Bootstrap JS and jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // Counter animation for counter section to reach 100%
  function animatePercentageCounter(id, start, end, suffix = '%') {
      let current = start;
      const element = document.getElementById(id);
      const duration = 2000; // Animation duration: 2 seconds
      const stepTime = Math.abs(Math.floor(duration / (end - start)));
      
      let timer = setInterval(function () {
          current += 1;
          element.textContent = current + suffix;
          if (current >= end) {
              clearInterval(timer);
              element.textContent = end + suffix;
          }
      }, stepTime);
  }

  // Start counter when section is in view
  function startPercentageCounters() {
      animatePercentageCounter('onTimeDelivery', 0, 100, '%');
      animatePercentageCounter('customerSatisfaction', 0, 100, '%');
      animatePercentageCounter('qualityAssurance', 0, 100, '%');
  }

  // Use IntersectionObserver to trigger counters when section is visible
  const counterSection = document.querySelector('.counter-section');
  const counterObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
          if (entry.isIntersecting) {
              startPercentageCounters();
              counterObserver.unobserve(counterSection);
          }
      });
  }, {
      threshold: 0.5,
      // Trigger section when 50% of section is visible
  });

  // Observe the counter section
  if (counterSection) {
      counterObserver.observe(counterSection);
  }
</script>
<script>
  document.addEventListener("DOMContentLoaded", function() {
      const observer = new IntersectionObserver(entries => {
          entries.forEach(entry => {
              if (entry.isIntersecting) {
                  entry.target.classList.add('show');
                  observer.unobserve(entry.target);
              }
          });
      }, {
          threshold: 0.2
      });

      const hiddenElements = document.querySelectorAll('.hidden');
      hiddenElements.forEach(el => observer.observe(el));
  });
</script>
<script>
document.addEventListener("DOMContentLoaded", function () {
  const text = "We don’t just supply parts — we deliver performance, durability, and the trust that keeps your operations running smoothly.";
  const speed = 35;
  let index = 0;

  function typeCharacter() {
    if (index < text.length) {
      document.getElementById("typed-text").textContent += text.charAt(index);
      index++;
      setTimeout(typeCharacter, speed);
    }
  }

  typeCharacter();
});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
<script>
    gsap.from(".navbar", {
        duration: 1,
        y: -100,
        opacity: 0,
        ease: "bounce"
    });

    gsap.from(".hero-section h3", {
        duration: 1.5,
        x: 200,
        opacity: 0,
        delay: 0.5,
        ease: "power3"
    });

    gsap.from(".service-box", {
      scrollTrigger: {
        trigger: ".services",
        start: "top 80%",
        end: "bottom 20%",
        scrub: 1,
      },
      opacity: 1,
      y: 50,
      stagger: 0.3,
      duration: 1,
      ease: "power3.out"
    });
</script>
<script>
  if (!document.cookie.split('; ').find(row => row.startsWith('visited='))) {
    document.cookie = "visited=true; max-age=" + 60 * 60 * 24 * 7 + "; path=/";
    console.log("First-time visit: full content loading");
  } else {
    console.log("Returning visitor: optimized content if needed");
  }
</script>
<script>
    window.addEventListener('scroll', function () {
      const navbar = document.querySelector('.blur-navbar');
      if (window.scrollY > 10) {
        navbar.classList.add('scrolled');
      } else {
        navbar.classList.remove('scrolled');
      }
    });
</script>
<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init({
        disable: false,
        startEvent: 'DOMContentLoaded',
        initClassName: 'aos-init',
        animatedClassName: 'aos-animate',
        useClassNames: false,
        disableMutationObserver: false,
        debounceDelay: 50,
        throttleDelay: 99,
        offset: 120,
        delay: 0,
        duration: 400,
        easing: 'ease',
        once: false,
        mirror: false,
        anchorPlacement: 'top-bottom',
    });
</script>
</body>
</html>