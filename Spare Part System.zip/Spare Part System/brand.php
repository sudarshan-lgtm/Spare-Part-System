<?php
session_start();
include 'db.php';

// Get the list of images from the folder
$image_dir = "admin folders/uploads/folders/";
$images = array_diff(scandir($image_dir), array('.', '..'));

// Function to get cards from a table
function getCompanyCards($conn, $tableName, $images, $image_dir) {
    $cards = [];
    $sql = "SELECT DISTINCT company FROM $tableName";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $company_name = strtolower($row['company']);
            foreach ($images as $image) {
                $image_name = strtolower(pathinfo($image, PATHINFO_FILENAME));
                if ($image_name === $company_name) {
                    $cards[] = [
                        'image' => $image_dir . $image,
                        'company' => $row['company'],
                        'source' => $tableName
                    ];
                    break;
                }
            }
        }
    }
    return $cards;
}
$productInventoryCards = getCompanyCards($conn, 'productinventory', $images, $image_dir);
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Brands</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <!-- Bootstrap 5 CSS (using only Bootstrap 5 to avoid conflicts) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS for Styling and Animation -->
    <style>
        body {
            /* Multi-color gradient background */
            background-color: #EEF2FE;
            font-family: 'Arial', sans-serif;
            background-size: 400% 400%;
            animation: gradientBG 10s ease infinite;
        }
        /* Navbar */
        .blur-navbar {
            backdrop-filter: blur(10px);
            background: rgb(128, 128, 128);
            padding: 10px 0;
        }
        .navbar-brand {
            font-weight: bold;
            font-size: 1.5rem;
            color: #fff;
        }
        .navbar-logo {
            width: 50px;
        }
        .nav-link {
            color: #eee !important;
            margin: 0 10px;
            position: relative;
        }
        .nav-link::after {
            content: '';
            position: absolute;
            width: 0%;
            height: 2px;
            background: #00c6ff;
            left: 0;
            bottom: 0;
            transition: 0.3s;
        }
        .nav-link:hover::after {
            width: 100%;
        }
        /* Signup Button */
        .btn-signup {
            background: transparent;
            border: 2px solid #00c6ff;
            color: #00c6ff;
            padding: 8px 16px;
            border-radius: 50px;
            transition: 0.3s;
        }
        .btn-signup:hover {
            background: #00c6ff;
            color: #fff;
        }
        /* Styles for the modal list items */
        .modal-body {
            padding: 20px;
        }

        #pdfList li {
            background-color: #f0f0f0; /* Light gray background */
            border-radius: 10px; /* Border radius for rounded corners */
            padding: 15px;
            margin-bottom: 10px; /* Space between the items */
            font-size: 1rem;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            transition: background-color 0.3s ease;
        }

        #pdfList li:hover {
            background-color: #e0e0e0; /* Darker gray on hover */
        }

        #pdfList li a {
            color: #333;
            text-decoration: none;
            display: block;
        }

        #pdfList li a:hover {
            color: #007bff; /* Blue color on hover */
        }

        /* Make sure items appear in rows */
        .row {
            display: flex;
            flex-wrap: wrap;
        }
        .animated-close-button {
            background-color: #e74c3c;
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 30px;
            font-weight: bold;
            transition: all 0.3s ease;
            box-shadow: 0px 4px 10px rgba(0,0,0,0.2);
        }

        .animated-close-button:hover {
            background-color: #c0392b;
            transform: scale(1.1);
            box-shadow: 0px 6px 15px rgba(0,0,0,0.3);
            cursor: pointer;
        }
        h1 {
            font-family: 'Montserrat', sans-serif;
            color: #2c3e50;
            margin-top: 100px !important; /* Added margin-top here */
        }
        h2 {
            font-family: 'Montserrat', sans-serif;
            color: #2c3e50;
        }
        .card {
            border-radius: 10px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .card:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
        }
        .bg-info-custom {
            background: linear-gradient(45deg, #3498db, #2ecc71);
        }
        .card-body {
            background-color: #fff;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            padding: 20px;
        }
        .card-img-top {
            object-fit: cover;
            height: 150px;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
        }
        .card-title {
            font-size: 1.2rem;
            font-weight: bold;
        }
        .text-center {
            margin-bottom: 20px;
        }
        .section-title {
            padding: 10px 0;
            background: #16a085;
            color: white;
            font-size: 1.5rem;
            border-radius: 5px;
            margin-top: 20px;
        }
        /* Animation */
        .fadeInUp {
            animation: fadeInUp 1s ease-out;
        }
        .sudarshan{
            width: 2%;
            height: 1%;
            transition: transform 0.3s ease-in-out; /* Smooth transition for zoom effect */
        }
        
        .sudarshan:hover {
            transform: scale(1.5); /* Zoom in by 1.5 times */
        }
        @keyframes fadeInUp {
            0% {
                opacity: 0;
                transform: translateY(20px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }
        /* Multi-color gradient animation */
        @keyframes gradientBG {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
    </style>
</head>
<body>
    <?php include("preloader.html"); ?>
<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark fixed-top blur-navbar">
    <div class="container">
        <a class="navbar-brand" href="index.php">
            <img src="../image/122.png" alt="Logo" class="navbar-logo"> RJ AutoHeaven
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse text-center justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="about_us.html">About</a></li>
                <li class="nav-item"><a class="nav-link" href="brand.php">Products</a></li>
                <li class="nav-item"><a class="nav-link" href="contact_main.php">Contact</a></li>
                <li class="nav-item">
                    <a href="signup.html" class="btn btn-signup">SignUp</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div class="container my-5">
    <!-- Display Cards -->
    <h1 class="text-center">OUR BRANDS</h1>
    <div class="row">
        <?php foreach (array_merge($productInventoryCards) as $card): ?>
            <div class="col-6 col-sm-6 col-md-4 col-lg-3 mb-4"> <!-- Changed col-12 to col-6 for smartphone mode -->
                <div class="card text-center shadow-sm" style="cursor: pointer;" onclick="openModal('<?= $card['company'] ?>')">
                    <img src="<?= $card['image'] ?>" class="card-img-top" alt="Company Image" loading="lazy" style="height: 150px; object-fit: cover;">
                    <div class="card-body">
                        <h5 class="card-title"><?= $card['company'] ?></h5>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="companyModal" tabindex="-1" aria-labelledby="companyModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="companyModalLabel">Company Catalog</h5>
            <button type="button" class="btn animated-close-button" data-bs-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span> Close</button>
        </div>
        <div class="modal-body">
            <ul id="pdfList" class="list-unstyled"></ul>
        </div>
    </div>
  </div>
</div>
<footer class="text-center py-2 text-white bg-dark mb-0">
    <small>Developed by <a href="brand.php" class="text-info"><img src="../image/sud2.png" class="sudarshan"></a> | © 2025 RJ AUTOHEAVEN. All Rights Reserved.</small>
</footer>
<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
function openModal(companyName) {
    const modal = new bootstrap.Modal(document.getElementById('companyModal'));
    modal.show();
    document.getElementById('companyModalLabel').textContent = companyName + " - Catalog";

    fetch('fetch_pdfs.php?company=' + encodeURIComponent(companyName))
        .then(response => response.json())
        .then(data => {
            let list = document.getElementById('pdfList');
            list.innerHTML = '';
            if (data.length > 0) {
                data.forEach(file => {
                    let li = document.createElement('li');
                    li.classList.add('col-12', 'col-md-4', 'mb-3'); // Added grid classes for better row display
                    let link = document.createElement('a');
                    link.href = `admin folders/uploads/zip/${companyName}/${file}`;
                    link.target = "_blank";
                    link.textContent = file;
                    li.appendChild(link);
                    list.appendChild(li);
                });
            } else {
                list.innerHTML = '<li class="col-12">No PDFs available for this company.</li>';
            }

            // Add event listener for Enter key to open PDF
            list.querySelectorAll('a').forEach(link => {
                link.addEventListener('keydown', (event) => {
                    if (event.key === 'Enter') {
                        window.open(link.href, '_blank');
                        event.preventDefault();
                    }
                });
            });
        });
}

// Close modal with Esc key
document.addEventListener('keydown', (event) => {
    const modal = document.getElementById('companyModal');
    if (event.key === 'Escape' && modal.classList.contains('show')) {
        const modalInstance = bootstrap.Modal.getInstance(modal);
        modalInstance.hide();
    }
});
</script>
<!-- GSAP Animation -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
<!-- Custom JS -->
<script>
    // GSAP Animations
    gsap.from(".navbar", {
        duration: 1,
        y: -100,
        opacity: 0,
        ease: "bounce"
    });
</script>
<script>
  // Check if the cookie exists
  if (!document.cookie.split('; ').find(row => row.startsWith('visited='))) {
    // Set cookie for 7 days
    document.cookie = "visited=true; max-age=" + 60 * 60 * 24 * 7 + "; path=/";
    console.log("First-time visit: full content loading");
  } else {
    console.log("Returning visitor: use optimized content if needed");
    // तुम्ही इथे placeholder images किंवा low-res images लावू शकता
  }
</script>
</body>
</html>