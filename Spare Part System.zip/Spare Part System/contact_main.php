<?php
session_start();
require_once ("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = $_POST["fullname"];
    $email = $_POST["email"];
    $subject = $_POST["subject"];
    $message = $_POST["message"];
    $account_type = $_POST["account_type"]; // Get account type from form
    
    // Insert user data into the database
    $sql = "INSERT INTO contact (fullname, email, subject, message, account_type) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $fullname, $email, $subject, $message, $account_type);
    
    if($stmt->execute()) {
        $stmt->close(); // ✅ Close statement
        $conn->close();
        echo "<script>
                alert('Data submitted successfully!');
                window.location.href = 'contact_main.php';
            </script>";
        exit();
    }else {
        $stmt->close(); // ✅ Close statement
        $conn->close();
        echo 
        "<script>alert('Data submission failed! Please try again.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../image/icon.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/contact.css">
    <!-- Icon Font Stylesheet -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&display=swap" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playwrite+AU+SA:wght@100..400&display=swap" rel="stylesheet">
    <title>Contact Us</title>
    <style>
        body {
            font-family: 'Playwrite AU SA', sans-serif;
            background-color: #EEF2FE;
            background-size: 400% 400%;
            animation: gradientBG 15s ease infinite;
            color: #fff;
            margin: 0;
            padding: 0;
        }

        /* Navbar */
        .blur-navbar {
            backdrop-filter: blur(10px);
            background: rgb(128, 128, 128, 0.8);
            padding: 10px 0;
        }

        .navbar-brand {
            font-weight: bold;
            font-size: 1.5rem;
            color: #fff;
        }

        .navbar-logo {
            width: 50px;
        }

        .nav-link {
            color: #eee !important;
            margin: 0 10px;
            position: relative;
            text-align: center !important;
        }

        .nav-link::after {
            content: '';
            position: absolute;
            width: 0%;
            height: 2px;
            background: #00c6ff;
            left: 0;
            bottom: 0;
            transition: 0.3s;
        }

        .nav-link:hover::after {
            width: 100%;
        }

        /* Signup Button */
        .btn-signup {
            background: transparent;
            border: 2px solid #00c6ff;
            color: #00c6ff;
            padding: 8px 16px;
            border-radius: 50px;
            transition: 0.3s;
        }

        .btn-signup:hover {
            background: #00c6ff;
            color: #fff;
        }

        /* Main Heading */
        h1 {
            text-align: center;
            margin-top: 80px;
            font-size: 3rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            color: #333;
            animation: fadeIn 2s ease-in-out;
        }

        h3 {
            text-align: center;
            font-size: 1.2rem;
            color: #333;
            margin-top: 10px;
            animation: fadeIn 3s ease-in-out;
        }

        p {
            font-size: 1.1rem;
            color: #333;
            text-align: center;
            animation: fadeIn 4s ease-in-out;
        }

        p strong {
            color: #FF6F61;
        }

        p a {
            color: #FF6F61;
            text-decoration: none;
            font-weight: bold;
        }

        .contact-container {
            width: 80%;
            margin: 50px auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .contact-title {
            text-align: center;
            font-size: 2rem;
            color: #333;
            margin-bottom: 20px;
            animation: fadeIn 5s ease-in-out;
        }

        .contact-content iframe {
            width: 100%;
            height: 300px;
            border: none;
            border-radius: 10px;
            margin-bottom: 30px;
        }

        .contact-form input,
        .contact-form textarea,
        .contact-form button {
            width: 100%;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            border: 1px solid #ddd;
            font-size: 1rem;
            color: #333;
        }

        .contact-form button {
            background-color: #FF6F61;
            color: #fff;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .contact-form button:hover {
            background-color: #FF4D4D;
        }

        .contact-form input:focus,
        .contact-form textarea:focus {
            outline: none;
            border: 1px solid #FF6F61;
        }
        .sudarshan{
            width: 2%;
            height: 1%;
            transition: transform 0.3s ease-in-out; /* Smooth transition for zoom effect */
        }
        
        .sudarshan:hover {
            transform: scale(1.5); /* Zoom in by 1.5 times */
        }
        /* Animations */
        @keyframes fadeIn {
            0% {
                opacity: 0;
                transform: translateY(20px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes gradientBG {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        @media (max-width: 600px) {
            .navbar-brand {
                font-size: 1.2rem;
            }
        
            .navbar-logo {
                width: 40px;
            }
        
            .btn-signup {
                padding: 6px 12px;
                font-size: 0.9rem;
            }
        
            .nav-link {
                margin: 5px 0;
                text-align: left;
            }
        
            .navbar-nav {
                text-align: center;
            }
        
            .navbar-collapse {
                background-color: rgba(0, 0, 0, 0.6);
                border-radius: 10px;
                padding: 10px;
            }
        }
        
        @media (max-width: 480px) {
            .navbar-brand {
                font-size: 1rem;
            }
        
            .navbar-logo {
                width: 35px;
            }
        
            .btn-signup {
                font-size: 0.8rem;
                padding: 5px 10px;
            }
        
            .navbar-toggler {
                padding: 0.25rem 0.5rem;
            }
        }
    </style>
</head>
<body> 
<?php include("preloader.html"); ?>
<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark fixed-top blur-navbar">
    <div class="container">
        <a class="navbar-brand" href="index.php">
            <img src="../image/122.png" alt="Logo" class="navbar-logo" loading="lazy"> RJ AutoHeaven
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse text-center justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="about_us.html">About</a></li>
                <li class="nav-item"><a class="nav-link" href="brand.php">Products</a></li>
                <li class="nav-item"><a class="nav-link" href="contact_main.php">Contact</a></li>
                <li class="nav-item">
                    <a href="signup.html" class="btn btn-signup">SignUp</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
    <h1>RJ AUTO HEAVEN</h1>
    <p style="margin-top:50px;">Customer Care <strong>:<a href="tel:9834530051"> 9834530051</a></strong></p>
    <p>E-mail <strong>:<a href="mailto:rjautoheaven@gmail.com"> rjautoheaven@gmail.com</a></strong></p>
    <p>Website <strong>:<a href="https://rjautoheaven.com/"> rjautoheaven.com</a></strong></p>
    
    <div class="contact-container">
        <h2 class="contact-title">Contact For Any Query</h2>
        <div class="contact-content">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3798.6478102433166!2d75.63898125368104!3d17.80824179157626!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc435ba5d852121%3A0xca1a95cdf38e213f!2sDALAVE%20PATIL%20SPARES%20%26%20ACCESSORIES!5e0!3m2!1sen!2sin!4v1741495407806!5m2!1sen!2sin" loading="lazy"></iframe>
            <form action="" method="POST" class="contact-form">
                <input type="text" name="fullname" placeholder="Enter Your Full Name" required oninput="validateLetters(this)" maxlength="40">
                <input type="email" name="email" placeholder="Enter Your Email" required>
                <input type="text" name="mobile" placeholder="Enter Your Mobile Number" required oninput="validateNumbers(this)" maxlength="10">
                <input type="text" name="subject" placeholder="Subject" required>
                <textarea name="message" placeholder="Message" rows="7" required></textarea>
                <input type="hidden" name="account_type" value="admin">  
                <button type="submit">Send Message</button> 
            </form>
        </div>
    </div>
    <footer class="text-center py-2 text-white bg-dark mb-0">
    <small>Developed by <a href="contact_main.php" class="text-info"><img src="../image/sud2.png" class="sudarshan"></a> | © 2025 RJ AUTOHEAVEN. All Rights Reserved.</small>
    </footer>
    <script>
        // Function to allow only letters
        function validateLetters(input) {
            input.value = input.value.replace(/[^a-zA-Z\s]/g, '');
        }

        // Function to allow only numbers
        function validateNumbers(input) {
            input.value = input.value.replace(/[^0-9]/g, '').substring(0, 10);
        }

        // Shortcut Key to go back when backspace is pressed
        document.addEventListener("keydown", function(event) {
            const activeElement = document.activeElement;
            if (event.key === "Backspace" && (activeElement.tagName !== "INPUT" && activeElement.tagName !== "TEXTAREA")) {
                event.preventDefault();
                window.history.back();
            }
        });
    </script>
    <!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- GSAP Animation -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
<!-- Custom JS -->
<script>
    // GSAP Animations
    gsap.from(".navbar", {
        duration: 1,
        y: -100,
        opacity: 0,
        ease: "bounce"
    });
</script>
<script>
  // Check if the cookie exists
  if (!document.cookie.split('; ').find(row => row.startsWith('visited='))) {
    // Set cookie for 7 days
    document.cookie = "visited=true; max-age=" + 60 * 60 * 24 * 7 + "; path=/";
    console.log("First-time visit: full content loading");
  } else {
    console.log("Returning visitor: use optimized content if needed");
    // तुम्ही इथे placeholder images किंवा low-res images लावू शकता
  }
</script>

</body>
</html>
