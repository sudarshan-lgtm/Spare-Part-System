<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name    = htmlspecialchars(trim($_POST["name"]));
    $email   = htmlspecialchars(trim($_POST["email"]));
    $project = htmlspecialchars(trim($_POST["project"]));

    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'sudarshan12shinde@gmail.com';         // ✅ your Gmail
        $mail->Password   = 'tigh optn beym jrta';           // ✅ Gmail App Password
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;

        // Recipients
        $mail->setFrom($email, $name);
        $mail->addAddress('sudarshan12shinde@gmail.com');  // ✅ Receiver email

        // Content
        $mail->isHTML(false);
        $mail->Subject = "New Project Inquiry from $name";
        $mail->Body    = "
You have received a new inquiry.

Name: $name
Email: $email

Project Details:
$project
        ";

        $mail->send();
        echo "<script>
          alert('Thank you! Your inquiry was sent successfully via SMTP.');
          window.location.href = 'mydetails.html';
        </script>";
    } catch (Exception $e) {
        echo "<script>
          alert('Email could not be sent. Mailer Error: {$mail->ErrorInfo}');
          history.back();
        </script>";
    }
} else {
    echo "<script>
      alert('Invalid request.');
      history.back();
    </script>";
}
?>
